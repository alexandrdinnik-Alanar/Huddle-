# Huddle Source-of-Truth Audit & Canonical Product Map v1.0

**Дата:** 2026-07-04  
**Статус:** рабочий baseline-аудит перед Developer Implementation Bible  
**Область:** `Site.zip` + Sprint 0 Codex Execution Pack + фактическое состояние GitHub `alexandrdinnik-Alanar/Huddle-`.

## 1. Executive decision

Материала достаточно для перехода к инженерной спецификации, но **нельзя** трактовать все изображения как готовые production screens. Корпус содержит несколько классов артефактов, несколько поколений одних и тех же доменов и критические противоречия между visual source и Sprint 0 pack. Поэтому разработку feature-слоя следует начинать только после фиксации конфликтов C-002/C-003/C-010/C-011/C-014/C-015.

Фактический GitHub следует считать **pre-Sprint-0 repository**: доступный initial commit содержит только `README.md` с двумя строками `# Huddle-` и `Platfom`; кодовая foundation из Sprint 0 pack ещё не является реальностью репозитория.

## 2. Проверенный состав корпуса

| Метрика | Значение |
|---|---:|
| Image occurrences | 638 |
| Уникальные бинарные артефакты SHA-256 | 628 |
| Точные duplicate occurrences | 10 |
| Наборы set1–set63 | 63 |
| Вложенные ZIP | 62 |
| Markdown documents | 8 |
| JSON manifests | 1 |
| Semantic-overlap groups (heuristic) | 50 |
| Artifacts inside overlap groups | 111 |

**Точный duplicate result:** 10 дублей — весь set54 бинарно дублирует соответствующие 10 файлов set51. Рекомендация: set51 сохранить, set54 архивировать.

**Traceability note:** номера `221–230` отсутствуют. Их нельзя автоматически «восстанавливать» или перенумеровывать; диапазон следует зарезервировать до выяснения происхождения.

## 3. Классификация 628 уникальных артефактов

| Класс | Кол-во | Правило использования |
|---|---:|---|
| Пользовательские продуктовые экраны | 341 | Входит в screen reconciliation; не автоматически production. |
| Supply/business surfaces | 61 | Ролевые кабинеты и supply-side flows; отдельные permission scopes. |
| Admin/operations/governance | 103 | Admin/ops/governance; не строить UI без backend capability. |
| Public web/SEO/legal | 51 | Public/SEO/legal; legal copy требует отдельного approval. |
| System/negative states | 20 | Обязательные states/edge cases; привязать к canonical screens. |
| Design system/components | 20 | Источник компонентов/tokens; конфликт токенов unresolved. |
| Flow maps/architecture | 10 | Архитектурная reference, не UI screen. |
| Email/push templates | 11 | Шаблоны коммуникаций; требуют delivery architecture. |
| Responsive variants | 11 | Reference для adaptive behavior; breakpoints нужно зафиксировать. |

## 4. Field-specific source-of-truth policy

Глобальная формула «последний файл всегда главный» здесь опасна. Использовать field-specific precedence:

1. **Owner-approved ADR/decision** — абсолютный приоритет для спорного поля.
2. **Technical stack / engineering foundation** — Sprint 0 pack, пока не заменён ADR.
3. **Actual implementation reality** — GitHub; документация не считается реализованной.
4. **Business flow** — set55 flow maps + domain screens.
5. **UI composition** — domain-specific canonical candidate sets из раздела 7.
6. **Visual tokens/brand** — unresolved до закрытия C-002/C-003.
7. **Legal/compliance content** — только отдельно утверждённый legal source; дизайн не является юридической истиной.

## 5. GitHub reality audit

- Repository: `alexandrdinnik-Alanar/Huddle-`.
- Доступный initial commit: `c4f7002a8589cfe4d3c15bd21a8628ba5bbbb37c`.
- Commit diff добавляет только `README.md` с двумя строками.
- Следовательно, отсутствуют подтверждённые `package.json`, Next.js app, route groups, Prisma schema, migrations, Supabase auth skeleton, design tokens, CI gates и product code.
- Sprint 0 pack следует считать **execution plan**, не состоянием codebase.

**Engineering consequence:** feature development до Sprint 0 foundation запрещается. Сначала S0-001…S0-018, но задачи brand/tokens нельзя выполнять до разрешения C-002/C-003.

## 6. Sprint 0 pack audit

### 6.1 Documented technical decisions

| Area | Decision | Reality |
|---|---|---|
| Architecture | Modular monolith | Not implemented |
| Framework | Next.js + TypeScript | Not implemented |
| Database | PostgreSQL | Not implemented |
| ORM | Prisma | Not implemented |
| Auth | Supabase Auth | Not implemented; phone OTP decision missing |
| DB hosting | Supabase Postgres | Not implemented |
| Storage | Supabase Storage | Not implemented |
| Hosting | Vercel | Not implemented |
| Email | Resend later | Not implemented |
| Monitoring | Sentry later | Not implemented |
| Styling | Token-based / Tailwind-compatible | Token conflict unresolved |
| Roles | Database-backed Role/UserRole | Not implemented |
| Permissions | Static code map in Sprint 0 | Needs operational capability expansion |

### 6.2 Execution scope

- 18 tasks: `S0-001`…`S0-018`.
- 6 batches, strict order.
- 31 placeholder routes in Sprint 0.
- Identity base: `User`, `Role`, `UserRole`; multi-role model.
- Role keys: `PARENT`, `SELLER`, `ORGANIZER`, `EXPERT`, `PARTNER`, `MUNICIPALITY_USER`, `MODERATOR`, `ADMIN`, `SUPER_ADMIN`, `SYSTEM`.
- Sprint 0 explicitly excludes real marketplace/events/payments/community/native-mobile/AI feature implementation.

### 6.3 Main limitation

31 routes are adequate as Sprint 0 placeholders but not as canonical product sitemap. The visual corpus requires expanded app, role-workspace and admin route families. See `Huddle_Candidate_Route_Map_v1.0.csv`.

## 7. Canonical domain selection v1.0

| Domain | Canonical candidate | Reference/supplement |
|---|---|---|
| Identity & onboarding | set35 | set11 |
| App shell & navigation | set39 | set34, set61 |
| Marketplace discovery & listing | set36 | set2, set6, set10, set13 |
| Commerce & orders | set49 + set43 | set12 |
| Events discovery & registration | set37 | set3, set16, set24 |
| Organizer event operations | set17 + set57 | set3, set16 |
| Activities | set18 | set3, set37 |
| Community social core | set38 | set5, set6, set10, set45 |
| Groups | set53 | set9, set19, set20, set45 |
| Messaging & notifications | set44 | set6, set10, set16, set21, set38 |
| Profiles, family, connections | set46 | set2, set5, set7 |
| Services & bookings | set47 + set40 | set7, set10, set21 |
| Trust & safety user | set52 | set6, set8 |
| Trust & safety admin | set56 | set22, set25 |
| Admin backoffice | set25 | set26-29, set31, set62, set63 |
| Design tokens | set50 | Sprint 0 Batch 2 |
| Component library | set51 | set54 |
| Product flows | set55 |  |
| SEO public pages | set41 + set42 + set59 | set1 |
| Accessibility/localization/consent | set60 |  |
| Responsive behavior | set61 |  |
| Notifications templates | set58 |  |
| Finance operations | set62 | set31 |
| Data governance | set63 | set23, set60 |

**Важно:** это baseline-аудит, а не утверждение владельца. Для design tokens статус специально оставлен `UNRESOLVED`.

## 8. Critical conflict register

Всего конфликтов: **26**; CRITICAL: **5**, HIGH: **16**, MEDIUM: **4**, LOW: **1**.

| ID | Severity | Area | Decision required |
|---|---|---|---|
| C-001 | CRITICAL | Repository reality | Treat repository as pre-Sprint-0; execute foundation first and gate every batch with build/typecheck/lint. |
| C-002 | HIGH | Design tokens | Owner/design decision required; publish one canonical token JSON and deprecate the other values. |
| C-003 | CRITICAL | Brand logo rules | Resolve before S0-003; approved asset package and BrandLogo variants must be authoritative. |
| C-004 | HIGH | Route architecture | Adopt expanded canonical route map before product sprints; keep Sprint 0 routes as minimum subset only. |
| C-005 | HIGH | Screen supersession | Create per-domain canonical set policy and mark older artifacts reference/archive. |
| C-006 | LOW | Exact duplication | Archive set54; keep set51 as canonical component-library copy. |
| C-007 | MEDIUM | Semantic overlap | Perform screen-level supersession review for each overlap group before implementation. |
| C-008 | MEDIUM | Artifact typing | Use artifact classes from inventory; only product-screen classes enter implementation backlog directly. |
| C-009 | HIGH | Typography | Choose approved production font stack and document fallbacks before token implementation. |
| C-010 | HIGH | Mobile strategy | Declare each mobile set as responsive web target or future native target; recommended: web-first P0, native backlog separate. |
| C-011 | CRITICAL | Marketplace domain | Split bounded contexts: Listings, Catalog Products, Orders/Fulfillment, Partner Feed, Affiliate Tracking. |
| C-012 | HIGH | Payments scope | Create payment ADR before transaction implementation; define platform merchant-of-record assumptions and provider boundaries. |
| C-013 | HIGH | Events vs activities | Decide unified Experience aggregate with type, or two explicit bounded contexts with shared registration primitives. |
| C-014 | CRITICAL | Family matching privacy | Define privacy-by-default matching policy, consent, coarse location, visibility and abuse controls before build. |
| C-015 | CRITICAL | Municipality analytics privacy | Mandate aggregation thresholds, de-identification rules and scoped access before municipality analytics. |
| C-016 | HIGH | Messaging architecture | Use one Conversation/Participant/Message core with context type, policy hooks and channel-specific permissions. |
| C-017 | HIGH | Role vs permission model | Keep coarse RoleKey; add permission/capability map and scoped grants for operational functions. |
| C-018 | HIGH | Phone verification | Add auth ADR for email/phone identity, OTP, recovery and account linking. |
| C-019 | HIGH | Localization and SEO routing | Choose locale routing and canonical/hreflang policy before SEO template implementation. |
| C-020 | HIGH | Notification delivery | Create Notification + Delivery + Preference model and channel adapter architecture before set58 implementation. |
| C-021 | MEDIUM | Responsive breakpoints | Publish semantic breakpoint tokens and component behavior matrix. |
| C-022 | HIGH | Trust & safety generations | Prefer set56 as operations candidate; retain unique set22 capabilities only after reconciliation. |
| C-023 | HIGH | Operational scope | Mark as P2/P3 unless backend capability exists; no placeholder should imply functioning controls. |
| C-024 | MEDIUM | Numbering traceability | Reserve numbers 221-230; do not renumber existing files; document the gap. |
| C-025 | HIGH | Legal authority | Treat set30 as UX template only; require approved legal content before production. |
| C-026 | HIGH | Repository assets | Do not start feature work; execute S0-001 through S0-018 in order after conflict resolutions C-002/C-003. |

Полные evidence/impact-поля находятся в `Huddle_Conflict_Register_v1.0.csv`.

## 9. Most important concrete conflicts

### 9.1 Token conflict

| Token | Sprint 0 starter | set50 board |
|---|---|---|
| Copper | `#B8734A` | `#C6683D` |
| Deep Green | `#173F35` | `#163A2F` |
| Ivory | `#F7F1E8` | `#FAF7F2` |
| Sage | `#DDE7D8` | `#A8BFAE` |
| Sand | `#E8D8C3` | `#F1E9D8` |

set50 дополнительно фиксирует Stone `#D9D5CC`, Charcoal `#1F1F1F`, Success `#2E7D4F`, Warning `#E2A23B`, Error `#D64545`, Info `#4A7BD3`. До owner decision нельзя генерировать production token file.

### 9.2 Logo conflict

Sprint 0 запрещает объединять icon и wordmark в новый lockup. set50/510 показывает именно primary logo `Huddle + icon`. Это blocker для `S0-003` и должно быть решено одним утверждённым asset package.

### 9.3 Marketplace architecture conflict

Нельзя создавать одну таблицу `MarketplaceItem`. Корпус явно содержит минимум пять разных capabilities: peer-to-peer Listing, partner Product catalog, native Order/Fulfillment, outbound AffiliateClick, Commission/Partner settlement. Эти контексты должны быть разведены.

### 9.4 Mobile target conflict

Next.js web зафиксирован; native mobile исключён из Sprint 0, но есть крупные mobile sets. До roadmap freeze каждый mobile artifact должен получить `target = responsive_web | future_native | both`.

## 10. Candidate route architecture

Рекомендуемый URL-принцип: public routes отдельно; весь authenticated multi-role product под `/app`; privileged operations под `/admin`. Role switcher из set39 поддерживает единый authenticated shell.

```text
/
├── marketplace/
│   ├── listings/[listingId]
│   └── products/[productId]
├── events/[eventId]
├── activities/[activityId]
├── services/[serviceId]
├── experts/[expertId]
├── family-guides/[stage]
├── seasonal-guides/[slug]
├── cities/[citySlug]/...
├── safety
├── privacy
├── terms
├── signup | login | forgot-password | verify
├── onboarding/...
├── app/
│   ├── search | saved | notifications
│   ├── messages/[conversationId]
│   ├── family | connections | matching
│   ├── community | groups/[groupId]
│   ├── marketplace | orders
│   ├── events | activities
│   ├── services | bookings
│   ├── wallet | privacy | safety | support
│   ├── seller/...
│   ├── organizer/...
│   ├── expert/...
│   ├── partner/...
│   └── municipality/...
└── admin/
    ├── users | listings | events | reports | audit-log
    ├── moderation/...
    ├── finance/...
    ├── support
    ├── settings
    ├── system
    ├── analytics
    └── privacy
```

Полная candidate map содержит **105 route rows** и находится в `Huddle_Candidate_Route_Map_v1.0.csv`.

## 11. Candidate bounded contexts

1. **Identity & Access** — User, Role, UserRole, permissions, auth identities, sessions.
2. **Family** — FamilyProfile, FamilyMember/ChildProfile, interests, age stage, visibility.
3. **Connections & Matching** — ConnectionRequest, Connection, MatchPreference; score computation separate from stored sensitive data.
4. **Community** — Group, Membership, Post, Comment, Reaction, Poll, media.
5. **Messaging** — Conversation, Participant, Message, Attachment, Mention, moderation hooks.
6. **Listings** — P2P Listing lifecycle, media, category, inquiry, reservation.
7. **Catalog & Partner Feed** — Partner, Store, Product, Feed, SyncRun, approval.
8. **Orders & Fulfillment** — Cart, Order, OrderItem, Shipment, Pickup, Return.
9. **Payments & Settlement** — Payment, Refund, Dispute, Payout, Commission, Invoice.
10. **Events & Activities** — unresolved aggregate boundary; shared registration/ticket/check-in primitives.
11. **Services & Experts** — ExpertProfile, ServiceOffering, Availability, Booking, Review.
12. **Advertising** — Campaign, Creative, Targeting, Placement, Budget.
13. **Municipality** — PublicProgram, district scope, aggregated reports.
14. **Trust & Safety** — Report, ModerationCase, EnforcementAction, Appeal, block/mute.
15. **Notifications** — Notification, Delivery, Template, Preference, channel adapters.
16. **Support** — Ticket, TicketReply, KnowledgeBaseArticle.
17. **Analytics & Reporting** — event collection, metrics, report definitions; privacy-aware.
18. **Privacy & Governance** — ConsentRecord, DataRequest, RetentionPolicy, AnonymizationRule, PrivacyIncident.
19. **Platform Operations** — feature flags, jobs, integrations, system status; mostly P2/P3.

## 12. Provisional priority result

| Priority | Unique artifacts | Meaning |
|---|---:|---|
| P0 | 274 | Foundation, identity, shell, safety/privacy, core launch candidates |
| P1 | 253 | Core growth/transaction/user flows |
| P2 | 91 | Commercial, reporting, supply/admin expansion |
| P3 | 10 | Advanced system operations |

Эта приоритизация **provisional set-level heuristic**. Она не заменяет business roadmap и не должна автоматически превращаться в sprint backlog.

## 13. Recommended execution sequence

### Gate A — Decisions before code
Закрыть: C-002 token source, C-003 logo lockup, C-010 mobile target, C-011 marketplace contexts, C-012 payment boundary, C-013 event/activity model, C-014 matching privacy, C-015 municipality aggregation.

### Gate B — Sprint 0 actual implementation
Выполнить `S0-001`…`S0-018` в исходном порядке; для каждого batch: build, typecheck, lint, review. Не добавлять feature code.

### Gate C — Canonical maps
Зафиксировать: route map, domain model, role-permission matrix, design tokens, screen supersession register, mobile target matrix.

### Gate D — Developer Implementation Bible
После Gate A–C собрать screen-by-screen specification с API/data/permissions/states/analytics/acceptance criteria.

### Gate E — Codex execution backlog
Декомпозировать Bible на EPIC/TASK packs; один task — один ограниченный scope, explicit files, contracts, tests and DoD.

## 14. Deliverables created by this audit

- `Huddle_Source_of_Truth_Audit_Canonical_Product_Map_v1.0.md` — этот документ.
- `Huddle_Visual_Artifact_Inventory_v1.0.csv` — 638 occurrences.
- `Huddle_Unique_Artifact_Inventory_v1.0.csv` — 628 unique binaries.
- `Huddle_Set_Matrix_v1.0.csv` — 63 sets.
- `Huddle_Exact_Duplicate_Register_v1.0.csv` — 10 exact duplicates.
- `Huddle_Semantic_Overlap_Register_v1.0.csv` — 50 heuristic overlap groups.
- `Huddle_Conflict_Register_v1.0.csv` — 26 conflicts.
- `Huddle_Canonical_Domain_Selection_v1.0.csv` — domain supersession candidates.
- `Huddle_Candidate_Route_Map_v1.0.csv` — expanded route candidates.
- `Huddle_Technical_Decision_Matrix_v1.0.csv` — locked/open/implementation status.

## Appendix A — 63-set matrix

| Set | Purpose | Class | Unique | Candidate status | Priority |
|---:|---|---|---:|---|---|
| 1 | Public marketing concepts | public_web | 10 | reference_candidate | P0 |
| 2 | Parent account, listings, family matching | end_user_product | 10 | production_candidate | P0 |
| 3 | Activities, events and organizer | end_user_product | 10 | production_candidate | P1 |
| 4 | Partner, campaigns and municipality dashboards | supply_business | 10 | production_candidate | P2 |
| 5 | Family, community, content and settings | end_user_product | 10 | production_candidate | P0 |
| 6 | Messaging, social, calendar, marketplace and privacy | end_user_product | 10 | production_candidate | P0 |
| 7 | Services, bookings and family connections | end_user_product | 10 | production_candidate | P1 |
| 8 | Wallet, payments, privacy and support | end_user_product | 10 | production_candidate | P1 |
| 9 | Search, groups, events and media | end_user_product | 10 | production_candidate | P1 |
| 10 | Feed, messaging, events, marketplace and profile | end_user_product | 10 | production_candidate | P1 |
| 11 | Auth and parent onboarding v1 | end_user_product | 10 | reference_candidate | P0 |
| 12 | Orders, fulfillment, returns and disputes | end_user_product | 10 | production_candidate | P1 |
| 13 | Seller listing lifecycle | end_user_product | 10 | production_candidate | P1 |
| 14 | Partner onboarding and product feed | supply_business | 10 | production_candidate | P2 |
| 15 | Sponsored campaign lifecycle | supply_business | 10 | production_candidate | P2 |
| 16 | Ticketing, check-in and event operations | end_user_product | 10 | production_candidate | P1 |
| 17 | Organizer event creation and management | end_user_product | 10 | production_candidate | P1 |
| 18 | Activity creation and management | end_user_product | 10 | production_candidate | P1 |
| 19 | Group creation and management | end_user_product | 10 | production_candidate | P1 |
| 20 | Group post lifecycle | end_user_product | 10 | production_candidate | P1 |
| 21 | Expert onboarding and booking operations | supply_business | 10 | production_candidate | P1 |
| 22 | Trust & safety moderation v1 | admin_ops | 10 | reference_candidate | P0 |
| 23 | Municipality onboarding and reporting | supply_business | 10 | production_candidate | P2 |
| 24 | Community events flow | end_user_product | 10 | production_candidate | P1 |
| 25 | Admin backoffice | admin_ops | 10 | production_candidate | P0 |
| 26 | Platform settings | admin_ops | 10 | production_candidate | P2 |
| 27 | Analytics and reports | admin_ops | 10 | production_candidate | P2 |
| 28 | Support helpdesk | admin_ops | 10 | production_candidate | P2 |
| 29 | System operations | admin_ops | 10 | production_candidate | P3 |
| 30 | Legal, trust and commercial documents | public_web | 10 | production_candidate | P0 |
| 31 | Admin commercial, finance and CMS | admin_ops | 10 | production_candidate | P2 |
| 32 | System and edge states | system_state | 10 | required_state | P0 |
| 33 | Negative, rejected and failed states | system_state | 10 | required_state | P0 |
| 34 | Mobile core v3 | end_user_product | 10 | reference_candidate | P0 |
| 35 | Onboarding and auth canonical flow candidate | end_user_product | 10 | production_candidate | P0 |
| 36 | Marketplace listings canonical flow candidate | end_user_product | 10 | production_candidate | P0 |
| 37 | Events and activities canonical flow candidate | end_user_product | 10 | production_candidate | P0 |
| 38 | Community and social canonical flow candidate | end_user_product | 10 | production_candidate | P0 |
| 39 | MVP app shell and navigation foundation | end_user_product | 10 | production_baseline_candidate | P0 |
| 40 | Services and recommendations | end_user_product | 10 | production_candidate | P1 |
| 41 | SEO public city pages | public_web | 10 | production_candidate | P1 |
| 42 | Public category, age and season pages | public_web | 10 | production_candidate | P1 |
| 43 | Mobile orders, checkout and delivery | end_user_product | 10 | production_candidate | P1 |
| 44 | Messaging, chat and notifications | end_user_product | 10 | production_candidate | P0 |
| 45 | Community, groups and events | end_user_product | 10 | production_candidate | P0 |
| 46 | Profiles, family and connections | end_user_product | 10 | production_candidate | P0 |
| 47 | Services, professionals and bookings | end_user_product | 10 | production_candidate | P1 |
| 48 | Content, posts and media | end_user_product | 10 | production_candidate | P1 |
| 49 | Marketplace products and orders | end_user_product | 10 | production_candidate | P1 |
| 50 | Design system foundation | design_system | 10 | reference | P0 |
| 51 | Component library canonical copy | design_system | 10 | reference | P0 |
| 52 | Mobile trust and safety | end_user_product | 10 | production_candidate | P0 |
| 53 | Community groups canonical candidate | end_user_product | 10 | production_candidate | P1 |
| 54 | Component library duplicate copy | design_system | 0 | archive_duplicate | P3 |
| 55 | Flow maps and product architecture | architecture_flow | 10 | reference | P0 |
| 56 | Admin trust and safety operations | admin_ops | 11 | production_candidate | P0 |
| 57 | Mobile supply-side tools | supply_business | 11 | production_candidate | P1 |
| 58 | Notification, email and push templates | comm_template | 11 | reference | P1 |
| 59 | SEO template system | public_web | 11 | reference | P1 |
| 60 | Accessibility, localization and consent | end_user_product | 11 | production_candidate | P0 |
| 61 | Responsive web variants | responsive_variant | 11 | reference | P0 |
| 62 | Admin finance and commercial operations | admin_ops | 11 | production_candidate | P2 |
| 63 | Data privacy and governance | admin_ops | 11 | production_candidate | P0 |

## Appendix B — Method and confidence

- ZIP files were extracted recursively.
- Binary uniqueness is SHA-256 exact equality.
- Semantic overlap is filename-normalization heuristic only; it does **not** prove visual duplication.
- Route candidates are set-/filename-based audit mappings and require screen-level validation against flow maps before implementation.
- Selected visual QA included public marketing, app shell, design system, flow maps and representative domain/admin sets.
- No OCR pipeline was used; the inventory relies on filenames, archive structure, image metadata and selected visual review.
- The audit does not claim legal approval, production readiness or completed implementation.
