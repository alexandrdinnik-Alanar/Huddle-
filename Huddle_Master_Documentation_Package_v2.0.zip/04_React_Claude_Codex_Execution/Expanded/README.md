# Huddle React Claude/Codex Execution Pack v2.0

**Date:** 2026-07-04  
**Status:** executable engineering baseline  
**Tasks:** 81 atomic roadmap tasks  
**Framework:** React 19.2 baseline + Next.js 16.2.x App Router + TypeScript strict  
**Agents:** Claude Code and/or Codex, one shared codebase

## What changed from v1

1. React is explicit and non-negotiable.
2. Next.js is defined as the React framework layer, not a substitute for React.
3. The pack is agent-neutral: every task can run through Claude Code or Codex.
4. Root `AGENTS.md` and `CLAUDE.md` are thin adapters to shared `.ai/HUDDLE_RULES.md`.
5. All 81 roadmap tasks have atomic task contracts.
6. Dependency waves are computed for controlled parallelism.
7. Cross-agent independent review is built into Definition of Done.
8. Old Sprint 0 brand conflicts are superseded by current ADRs/set50 rules.

## Start

Read in order:

1. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
2. `agent/HUDDLE_RULES.md` — copy into repository as `.ai/HUDDLE_RULES.md`
3. `AGENTS.md` and/or `CLAUDE.md` — copy to repository root
4. `NEXT_TASK.md`
5. `tasks/phase-0/S0-001.md`

## Package structure

```text
AGENTS.md
CLAUDE.md
NEXT_TASK.md
Huddle_React_Claude_Codex_Execution_Pack_FULL.md
architecture/
agent/
tasks/
  phase-0/ ... phase-8/
manifests/
prompts/
checklists/
handoff-templates/
references/
```

## Execution rule

```text
one task ID
→ one branch
→ one implementation agent
→ quality gates
→ HANDOFF.md
→ independent review
→ merge
```

Prefer cross-agent review:

```text
Codex implementation → Claude review
Claude implementation → Codex review
```

This is preferred, not mandatory. A separate independent session is acceptable when only one agent is available.

## Important

The original Sprint 0 pack is preserved under `references/original_sprint_0_pack_v1.0/` for traceability. Where it conflicts with accepted ADRs or this v2 pack, the newer accepted rules win.
