# Huddle React Runtime Stack Lock

- **UI library:** React 19.2 baseline
- **Framework:** Next.js 16.2.x App Router (React framework layer)
- **Language:** TypeScript strict mode
- **Package manager:** pnpm with committed lockfile
- **Architecture:** Modular monolith
- **Database:** PostgreSQL
- **ORM:** Prisma
- **Auth:** Supabase Auth
- **DB hosting:** Supabase Postgres initial target
- **Storage:** Supabase Storage behind MediaStorage adapter
- **Hosting:** Vercel initial target
- **Validation:** Schema-first validated DTO boundary
- **Authorization:** RBAC + Capability + ScopedGrant + object policy
- **Testing:** Vitest-compatible unit/integration + Playwright E2E; exact dependency versions locked in S0-001
- **Styling:** CSS variables from canonical Huddle tokens; Tailwind-compatible, no arbitrary brand values
- **Agent execution:** Claude Code or Codex against one codebase and one task contract

## Framework rule

The application is React-first. Next.js supplies routing, rendering, server boundaries and production framework capabilities. Do not treat Next.js route files as the domain layer.

## Dependency changes

A feature task may not add a production dependency unless:

1. the task explicitly requires it or the user approves it;
2. existing platform capabilities are insufficient;
3. security/license/maintenance impact is recorded;
4. lockfile changes are committed;
5. build, typecheck and tests pass.

## Patch upgrades

Patch/minor upgrades require a dedicated maintenance change when they alter lockfile materially. Major upgrades require an ADR.
