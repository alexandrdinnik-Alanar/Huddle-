# Huddle React + Dual-Agent Architecture Addendum v1.1

**Date:** 2026-07-04  
**Status:** Accepted implementation addendum  
**Applies to:** Huddle Developer Implementation Bible v1.0 and Execution Pack v2.0

## 1. React requirement

Huddle web product is explicitly a **React application**. The framework layer is **Next.js App Router**, so the architecture is:

```text
React 19.2 UI/component model
        ↓
Next.js 16.2.x App Router framework layer
        ↓
TypeScript strict application code
        ↓
Modular monolith domain modules
        ↓
PostgreSQL / Prisma / Supabase adapters
```

This supersedes any ambiguous wording that could be read as framework-first rather than React-first.

## 2. Version policy

- Baseline verified for this pack: React 19.2; Next.js 16.2.x.
- `S0-001` resolves exact patch versions and commits `pnpm-lock.yaml`.
- After repository initialization, `package.json` plus lockfile are the runtime source of truth.
- No unreviewed major-version upgrades inside feature tasks.

## 3. Rendering policy

- React Server Components by default.
- Client Components only when required for browser interactivity/state/effects.
- Route handlers and server-side module services own trusted mutation boundaries.
- Business logic does not live in React components.

## 4. Dual-agent policy

Claude Code and Codex work on **one codebase, one backlog, one task format**.

```text
Developer Bible + ADRs + Matrices
            ↓
.ai/HUDDLE_RULES.md
       ↙             ↘
  AGENTS.md         CLAUDE.md
    Codex           Claude Code
       ↘             ↙
       same task contract
              ↓
       same React codebase
```

Recommended review pattern:

- Codex implements → Claude reviews; or
- Claude implements → Codex reviews.

A different agent is preferred for review, but a separate independent review session is acceptable when only one tool is available.

## 5. Concurrency policy

Parallel execution is allowed only when:

1. all dependencies are complete;
2. allowed file sets do not overlap materially;
3. no shared Prisma migration sequence conflict exists;
4. no shared route/layout or design-system lock exists;
5. one integration owner resolves final merge order.

The dependency wave manifest is an optimization aid, not authorization to ignore file locks.
