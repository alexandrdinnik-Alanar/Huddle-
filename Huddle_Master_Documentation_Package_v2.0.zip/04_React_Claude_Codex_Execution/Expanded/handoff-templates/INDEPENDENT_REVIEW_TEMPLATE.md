# <TASK-ID> Independent Review

## Verdict

- [ ] APPROVE
- [ ] CHANGES REQUIRED

## Contract coverage

## Blocking findings

## High findings

## Medium findings

## Security/privacy review

## Authorization review

## Data integrity / concurrency review

## Test evidence

## Scope creep check

## Final recommendation
