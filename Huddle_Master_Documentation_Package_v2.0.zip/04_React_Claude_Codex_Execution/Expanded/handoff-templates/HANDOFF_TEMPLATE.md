# <TASK-ID> Handoff

## Summary

## Changed files

## Data model / migrations

## API contract changes

## Authorization / capability changes

## UI states implemented

## Audit / outbox / realtime impact

## Tests and commands run

| Command | Result |
|---|---|
| `pnpm lint` | |
| `pnpm typecheck` | |
| `pnpm test` | |
| `pnpm build` | |

## Known limitations

## Risks / follow-up

## Commit / PR

