# Huddle Repository Bootstrap for AI-Assisted Development

The current repository baseline is pre-Sprint-0. Do not manually build feature code first.

## Step 1 — copy execution rules into the repository

From this pack, copy:

```text
AGENTS.md             -> repository root
CLAUDE.md              -> repository root
.ai/HUDDLE_RULES.md    -> repository .ai/HUDDLE_RULES.md
```

Keep the rest of the pack under a stable repository path, recommended:

```text
docs/execution-pack/v2/
```

## Step 2 — create the first branch

```text
ai/s0-001-initialize-project-repository
```

## Step 3 — run exactly S0-001

Task file:

```text
tasks/phase-0/S0-001.md
```

## Step 4 — independent review

Prefer the other agent:

```text
Codex implements -> Claude reviews
Claude implements -> Codex reviews
```

Do not start S0-002 until S0-001 is merged and all gates pass.
