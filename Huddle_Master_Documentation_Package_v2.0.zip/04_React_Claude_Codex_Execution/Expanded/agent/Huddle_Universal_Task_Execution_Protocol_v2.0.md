# Huddle Universal Task Execution Protocol v2.0

## Before editing

1. Confirm task ID.
2. Confirm all dependency task IDs are merged.
3. Read `.ai/HUDDLE_RULES.md`.
4. Read the task file completely.
5. Inspect actual repository state and relevant module tests.
6. Record any contradiction with the task contract before implementation.

## During implementation

- Keep scope inside allowed files.
- Use owning module public interfaces for cross-domain calls.
- Add server authorization to every mutation.
- Add validation at external boundaries.
- Preserve loading/empty/error/forbidden states for UI tasks.
- Add audit/outbox behavior where the task says so.
- Do not add fake data paths to production code.

## Before handoff

1. Run all task commands.
2. Inspect `git diff` for unrelated changes.
3. Confirm no secrets.
4. Confirm migration impact.
5. Confirm new API/capability behavior.
6. Write handoff.
7. Stop; do not start next task.

## Review severity

- **BLOCKER:** auth bypass, privacy breach, data corruption, migration risk, broken build, task scope violation.
- **HIGH:** incorrect state transition, missing idempotency/audit, major accessibility/security regression.
- **MEDIUM:** incomplete edge state, maintainability issue, insufficient test coverage.
- **LOW:** non-blocking clarity or polish.
