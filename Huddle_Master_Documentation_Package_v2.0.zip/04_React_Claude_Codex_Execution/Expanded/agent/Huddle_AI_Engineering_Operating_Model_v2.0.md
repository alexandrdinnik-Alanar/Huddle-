# Huddle AI Engineering Operating Model v2.0

## Objective

Use Claude Code and/or Codex as implementation agents without allowing either tool to redefine product architecture.

## Roles

### 1. Task Owner
Chooses the next dependency-ready task and supplies the task file.

### 2. Implementation Agent
Claude Code or Codex. Implements one task on one branch.

### 3. Review Agent
Preferably the other agent. Reviews diff against task contract, ADRs, security/privacy rules and tests.

### 4. Integration Owner
Human or explicitly assigned integration session. Resolves merge order, schema migration order and cross-task conflicts.

## Branch naming

```text
ai/<task-id-lower>-<short-slug>
```

Example:

```text
ai/s0-001-init-react-repo
```

## Mandatory cycle

```text
Select dependency-ready task
        ↓
Create branch
        ↓
Implementation agent reads rules + task
        ↓
Implement only task scope
        ↓
Run task gates
        ↓
Write HANDOFF.md
        ↓
Independent review
        ↓
Fix blocking findings
        ↓
Merge
        ↓
Mark task complete
```

## Agent switching

A task may move from one agent to another only through a written handoff. The receiving agent must inspect the actual diff and test state; it must not trust narrative alone.

## Parallel work

Use `manifests/Huddle_Execution_Waves_v2.0.csv` for dependency-ready waves. Before parallel start, compare allowed file patterns. Shared schema, root layout, design system, package files and instruction files are serialization points.
