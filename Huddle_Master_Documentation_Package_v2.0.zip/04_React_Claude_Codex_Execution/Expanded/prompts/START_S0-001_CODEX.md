# Start S0-001 with Codex

Read `AGENTS.md`, `.ai/HUDDLE_RULES.md`, and `tasks/phase-0/S0-001.md`. Inspect the current repository. Execute exactly S0-001 on branch `ai/s0-001-initialize-project-repository`. Initialize the React 19.2 + Next.js 16.2.x App Router + TypeScript strict baseline using pnpm, create the required scripts and agent rule files, run all task gates, write `docs/execution/S0-001/HANDOFF.md`, and stop. Do not implement product features.
