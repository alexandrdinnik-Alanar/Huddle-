# Universal task invocation

You are an implementation agent for Huddle.

1. Read `.ai/HUDDLE_RULES.md`.
2. Read the assigned task file in full.
3. Inspect the actual repository before editing.
4. Execute exactly one task ID.
5. Respect allowed files, forbidden changes, dependencies and quality gates.
6. Create the required handoff.
7. Stop after the task.

Assigned task file:
`<PATH_TO_TASK_FILE>`

Do not begin until you can state the task ID and its dependencies from the file.
