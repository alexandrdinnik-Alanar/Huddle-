# Codex invocation template

Read `AGENTS.md`, `.ai/HUDDLE_RULES.md`, and `<PATH_TO_TASK_FILE>`. Inspect the repository and execute exactly that task. Do not expand scope. Run every required gate and write `docs/execution/<TASK-ID>/HANDOFF.md`. Stop after completion.
