# Independent Review Gate

## BLOCKER checks

- [ ] No auth bypass
- [ ] No object-scope bypass
- [ ] No child/family sensitive data leak
- [ ] No municipality row-level/raw personal data exposure
- [ ] No payment live-mode bypass of provider/legal gate
- [ ] No unsafe migration/data loss
- [ ] No secrets committed
- [ ] Build and required tests pass

## Architecture checks

- [ ] Correct owning module
- [ ] No duplicated bounded context infrastructure
- [ ] React components do not own business rules
- [ ] RSC/client boundary justified
- [ ] API matches canonical contract or documented approved change
- [ ] Capability checks match matrix
- [ ] Audit/idempotency/realtime semantics correct

## Product checks

- [ ] Canonical visual references used appropriately
- [ ] Loading/empty/error/forbidden states present
- [ ] Accessibility baseline satisfied
- [ ] No fake controls
- [ ] No scope creep
