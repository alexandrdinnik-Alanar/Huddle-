# Implementation Gate

- [ ] Correct task ID and dependency state confirmed
- [ ] Actual repository inspected
- [ ] Allowed file scope respected
- [ ] No unrelated dependency changes
- [ ] React/Next.js boundaries respected
- [ ] External input validated
- [ ] Server authorization enforced
- [ ] Object scope enforced
- [ ] Audit/outbox/idempotency handled where required
- [ ] Privacy-sensitive DTOs reviewed
- [ ] Loading/empty/error/forbidden states covered where applicable
- [ ] Unit/integration/UI/E2E tests added as applicable
- [ ] lint passes
- [ ] typecheck passes
- [ ] tests pass
- [ ] build passes
- [ ] HANDOFF.md written
- [ ] Agent stopped after task
