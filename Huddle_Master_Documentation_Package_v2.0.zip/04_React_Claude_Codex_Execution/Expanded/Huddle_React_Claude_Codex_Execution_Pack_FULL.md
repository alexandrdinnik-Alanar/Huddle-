# Huddle React Claude/Codex Execution Pack v2.0 — FULL TASKS

# S0-001 — Initialize project repository

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-001` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 1 |
| Dependencies | None |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Initialize project repository** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **None**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-001-initialize-project-repository`.

## Required implementation

1. Initialize a React 19.2 baseline application using Next.js 16.2.x App Router and TypeScript strict mode.
2. Use pnpm and commit the lockfile; record exact resolved dependency versions in docs/architecture/runtime-baseline.md.
3. Create scripts: dev, build, lint, typecheck, test, test:e2e, format:check.
4. Create src/app, src/components, src/modules, src/lib, prisma, tests, docs and .ai directories.
5. Add .env.example with placeholders only; no secrets.
6. Add root AGENTS.md, CLAUDE.md and .ai/HUDDLE_RULES.md from this execution pack.
7. Do not implement product features, auth, schema or business routes beyond the default health shell.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `package.json`
- `pnpm-lock.yaml`
- `tsconfig.json`
- `next.config.*`
- `eslint.config.*`
- `src/**`
- `tests/**`
- `docs/**`
- `.ai/**`
- `AGENTS.md`
- `CLAUDE.md`
- `.env.example`
- `.gitignore`
- `README.md`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `references/**`
- `unapproved generated brand assets`
- `committed secrets or production credentials`
- `prisma/schema.prisma and prisma/migrations/**`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-001/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-001/HANDOFF.md. Stop after the task.
```


---

# S0-002 — Create route group architecture

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-002` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 2 |
| Dependencies | S0-001 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create route group architecture** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-002-create-route-group-architecture`.

## Required implementation

1. Create Next.js App Router groups: (public), (auth), (app), (admin), plus api.
2. Use src/app; do not create Pages Router.
3. Create route ownership documentation and placeholder-only route files for canonical P0 shell routes.
4. No business data loading or feature implementation.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-002/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-002/HANDOFF.md. Stop after the task.
```


---

# S0-003 — Add approved brand assets and logo components

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-003` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 3 |
| Dependencies | S0-002 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Add approved brand assets and logo components** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-003-add-approved-brand-assets-and-logo-components`.

## Required implementation

1. Integrate only approved supplied Huddle brand assets.
2. Implement PrimaryLogo and approved icon components without geometry recreation.
3. Follow ADR-009: set50/510 supersedes old Sprint 0 lockup prohibition.
4. Add accessible names and dark/light background usage tests where applicable.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-003/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-003/HANDOFF.md. Stop after the task.
```


---

# S0-004 — Implement design token foundation

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-004` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 4 |
| Dependencies | S0-003 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement design token foundation** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-003**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-004-implement-design-token-foundation`.

## Required implementation

1. Implement canonical set50 tokens as CSS custom properties and typed token references.
2. Canonical colors: Copper #C6683D; Deep Green #163A2F; Ivory #FAF7F2; Sage #A8BFAE; Sand #F1E9D8; Stone #D9D5CC; Charcoal #1F1F1F; Success #2E7D4F; Warning #E2A23B; Error #D64545; Info #4A7BD3.
3. Implement spacing scale 4, 8, 16, 24, 32, 64 and semantic compact/medium/wide breakpoints.
4. Do not use deprecated Sprint 0 token values.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-004/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-004/HANDOFF.md. Stop after the task.
```


---

# S0-005 — Create primitive UI components

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-005` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 5 |
| Dependencies | S0-004 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create primitive UI components** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-004**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-005-create-primitive-ui-components`.

## Required implementation

1. Create minimal React primitives required by foundation: Button, Input, Textarea, Select, Checkbox, Radio, Switch, Badge, Card, Dialog shell, Drawer shell, Spinner, EmptyState, ErrorState.
2. Use accessible semantics and ref-safe component APIs.
3. No domain-specific components and no copied page mockups.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-005/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-005/HANDOFF.md. Stop after the task.
```


---

# S0-006 — Configure database and Prisma

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-006` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 6 |
| Dependencies | S0-005 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Configure database and Prisma** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-006-configure-database-and-prisma`.

## Required implementation

1. Configure PostgreSQL datasource and Prisma.
2. Create schema/migration workflow and safe environment documentation.
3. Do not invent feature domain entities yet.
4. Add prisma validate/generate scripts and CI gate.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`
- `prisma/seed.*`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-006/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-006/HANDOFF.md. Stop after the task.
```


---

# S0-007 — Implement User / Role / UserRole models

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-007` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 7 |
| Dependencies | S0-006 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement User / Role / UserRole models** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-006**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-007-implement-user-role-userrole-models`.

## Required implementation

1. Implement canonical User, Role and UserRole identity foundation only.
2. Use stable ids and timestamps; preserve separation from Supabase identity subject.
3. Add migration and tests for uniqueness/invariants.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`
- `prisma/seed.*`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-007/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-007/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-007. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-007/HANDOFF.md. Stop after the task.
```


---

# S0-008 — Seed roles

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-008` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 8 |
| Dependencies | S0-007 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Seed roles** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-007**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-008-seed-roles`.

## Required implementation

1. Seed stable coarse roles: PARENT, SELLER, ORGANIZER, EXPERT, PARTNER, MUNICIPALITY_USER, MODERATOR, ADMIN, SUPER_ADMIN, SYSTEM.
2. Make seed idempotent.
3. Do not encode every permission as a new role.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`
- `prisma/seed.*`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-008/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-008/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-008. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-008/HANDOFF.md. Stop after the task.
```


---

# S0-009 — Create Supabase Auth skeleton

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-009` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 9 |
| Dependencies | S0-008 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create Supabase Auth skeleton** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-008**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-009-create-supabase-auth-skeleton`.

## Required implementation

1. Create Supabase Auth client/server adapters and session resolution skeleton.
2. No custom password store.
3. Do not complete signup UI in Sprint 0.
4. Keep provider access behind lib/identity adapter boundaries.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-009/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-009/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-009. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-009/HANDOFF.md. Stop after the task.
```


---

# S0-010 — Create permission helpers

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-010` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 10 |
| Dependencies | S0-009 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create permission helpers** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-009**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-010-create-permission-helpers`.

## Required implementation

1. Create server-only authorization helpers with deny-by-default behavior.
2. Prepare role/capability/object-scope interface without implementing all feature capabilities.
3. Add negative tests.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-010/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-010/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-010. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-010/HANDOFF.md. Stop after the task.
```


---

# S0-011 — Create route guards

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-011` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 11 |
| Dependencies | S0-010 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create route guards** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-010**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-011-create-route-guards`.

## Required implementation

1. Protect /app and /admin patterns server-side.
2. Preserve safe redirect intent.
3. Admin requires explicit privileged authorization; do not rely on route naming alone.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-011/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-011/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-011. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-011/HANDOFF.md. Stop after the task.
```


---

# S0-012 — Create API response and error helpers

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-012` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 12 |
| Dependencies | S0-011 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create API response and error helpers** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-011**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-012-create-api-response-and-error-helpers`.

## Required implementation

1. Create consistent success/error envelopes for route handlers.
2. Map validation, auth, forbidden, not-found, conflict and internal errors without leaking internals.
3. Add correlation/request id support.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-012/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-012/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-012. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-012/HANDOFF.md. Stop after the task.
```


---

# S0-013 — Create validation pattern

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-013` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 13 |
| Dependencies | S0-012 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create validation pattern** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-012**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-013-create-validation-pattern`.

## Required implementation

1. Create schema-first validation helper and DTO boundary pattern.
2. Reject unknown/invalid input intentionally.
3. Demonstrate with a non-feature example only.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-013/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-013/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-013. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-013/HANDOFF.md. Stop after the task.
```


---

# S0-014 — Create audit helper and AuditLog base

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-014` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 14 |
| Dependencies | S0-013 |
| Owning module | `src/modules/foundation` |
| Risk | HIGH |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create audit helper and AuditLog base** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-013**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-014-create-audit-helper-and-auditlog-base`.

## Required implementation

1. Implement append-only AuditLog base and audit writer helper.
2. Exclude secrets and unnecessary sensitive free text.
3. Support actor, action, target, scope, request correlation and metadata allowlist.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`
- `prisma/seed.*`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-014/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-014/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-014. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-014/HANDOFF.md. Stop after the task.
```


---

# S0-015 — Create base layouts

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-015` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 15 |
| Dependencies | S0-014 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create base layouts** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-014**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-015-create-base-layouts`.

## Required implementation

1. Create public, auth, app and admin React layout shells.
2. Use set39/set61 behavior references without implementing features.
3. Add loading/error/not-found boundaries.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-015/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-015/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-015. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-015/HANDOFF.md. Stop after the task.
```


---

# S0-016 — Create canonical placeholder pages

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-016` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 16 |
| Dependencies | S0-015 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create canonical placeholder pages** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-015**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-016-create-canonical-placeholder-pages`.

## Required implementation

1. Create canonical placeholder pages only for approved routes.
2. Every placeholder clearly states not implemented in non-production development context.
3. Do not add fake production controls or fabricated data.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-016/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-016/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-016. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-016/HANDOFF.md. Stop after the task.
```


---

# S0-017 — Create Sprint 0 QA checklist

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-017` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 17 |
| Dependencies | S0-016 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create Sprint 0 QA checklist** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-016**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-017-create-sprint-0-qa-checklist`.

## Required implementation

1. Create executable Sprint 0 QA checklist covering build, typecheck, lint, tests, route protection, secrets, migrations, brand tokens and scope.
2. Make checklist suitable for both Claude Code and Codex review sessions.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-017/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-017/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-017. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-017/HANDOFF.md. Stop after the task.
```


---

# S0-018 — Create developer README

## Metadata

| Field | Value |
|---|---|
| Task ID | `S0-018` |
| Phase | Phase 0 |
| Epic | Foundation |
| Priority | P0 |
| Dependency wave | 18 |
| Dependencies | S0-017 |
| Owning module | `src/modules/foundation` |
| Risk | LOW_MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Create developer README** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-017**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/s0-018-create-developer-readme`.

## Required implementation

1. Create developer README with exact pnpm setup, environment, database, migrations, tests and agent workflow.
2. Document AGENTS.md/CLAUDE.md relationship and one-task-per-branch rule.
3. Document current limitations and next task P1-001.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- No direct visual artifact is required. Follow canonical shared system references.

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/**`
- `tests/**`
- `docs/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Complete the updated Sprint 0 task contract above.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/S0-018/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/S0-018/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly S0-018. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/S0-018/HANDOFF.md. Stop after the task.
```


---

# P1-001 — Implement User/AuthIdentity reconciliation

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-001` |
| Phase | Phase 1 |
| Epic | Identity |
| Priority | P0 |
| Dependency wave | 19 |
| Dependencies | S0-018 |
| Owning module | `src/modules/identity` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement User/AuthIdentity reconciliation** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **S0-018**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-001-implement-user-authidentity-reconciliation`.

## Required implementation

1. Canonical business identity linked to Supabase subjects.
2. Keep Supabase subject mapping separate from canonical business User identity.
3. Make reconciliation idempotent and safe for linked email/phone identities.
4. Never store custom passwords.
5. Create AuthIdentity mapping with provider, providerSubject and verified identity metadata; reconciliation must be idempotent.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.

## Related API contracts

- `GET /api/v1/me` — capability `profile.read_self`; request `-`; response `CurrentUserDTO`; events `-`
- `PATCH /api/v1/me` — capability `profile.update_self`; request `UpdateProfileInput`; response `CurrentUserDTO`; events `user.profile_updated`
- `POST /api/v1/auth/link-phone` — capability `profile.update_self`; request `LinkPhoneInput`; response `VerificationChallengeDTO`; events `auth.phone_challenge_created`
- `POST /api/v1/auth/verify-phone` — capability `profile.update_self`; request `VerifyPhoneInput`; response `CurrentUserDTO`; events `auth.phone_verified`
- `GET /api/v1/roles` — capability `profile.read_self`; request `-`; response `RoleDTO[]`; events `-`
- `POST /api/v1/role-context` — capability `profile.read_self`; request `SwitchRoleContextInput`; response `RoleContextDTO`; events `user.role_context_changed`

## Related capabilities

- `profile.read_self` — Read own profile
- `profile.update_self` — Update own profile
- `admin.user.manage` — Manage user status/roles
- `admin.role.grant` — Grant coarse role/scoped capability

## Related routes

- `/verify` — Identity verification / owner `Identity` / P0

## Visual acceptance references

- `HUD-VIS-351` — set 35, `351_welcome_splash.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-352` — set 35, `352_choose_role.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-353` — set 35, `353_create_account.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/signup`
- `HUD-VIS-354` — set 35, `354_verify_phone.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-355` — set 35, `355_create_family_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-356` — set 35, `356_add_children.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-357` — set 35, `357_set_interests.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-358` — set 35, `358_location_access.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-359` — set 35, `359_community_guidelines.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-360` — set 35, `360_onboarding_complete.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-101` — set 11, `101_sign_up.png`, disposition `REFERENCE_ONLY`, route candidate `/signup`
- `HUD-VIS-102` — set 11, `102_login.png`, disposition `REFERENCE_ONLY`, route candidate `/login`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/identity/**`
- `tests/identity/**`
- `docs/execution/P1-001/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Canonical business identity linked to Supabase subjects.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-001/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-001/HANDOFF.md. Stop after the task.
```


---

# P1-002 — Implement Capability and ScopedGrant model

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-002` |
| Phase | Phase 1 |
| Epic | Authorization |
| Priority | P0 |
| Dependency wave | 20 |
| Dependencies | P1-001 |
| Owning module | `src/modules/identity` |
| Risk | HIGH |
| React UI expected | no / not primary |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement Capability and ScopedGrant model** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-002-implement-capability-and-scopedgrant-model`.

## Required implementation

1. RBAC + scoped authorization service.
2. Evaluate coarse role, capability, scoped grant and object policy on the server.
3. Deny by default; client-side hiding is not authorization.
4. Add negative authorization tests.
5. Implement Capability and ScopedGrant persistence plus authorization service; migrate from Sprint 0 static permission skeleton without breaking deny-by-default.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.

## Related API contracts

- `GET /api/v1/me` — capability `profile.read_self`; request `-`; response `CurrentUserDTO`; events `-`
- `PATCH /api/v1/me` — capability `profile.update_self`; request `UpdateProfileInput`; response `CurrentUserDTO`; events `user.profile_updated`
- `POST /api/v1/auth/link-phone` — capability `profile.update_self`; request `LinkPhoneInput`; response `VerificationChallengeDTO`; events `auth.phone_challenge_created`
- `POST /api/v1/auth/verify-phone` — capability `profile.update_self`; request `VerifyPhoneInput`; response `CurrentUserDTO`; events `auth.phone_verified`
- `GET /api/v1/roles` — capability `profile.read_self`; request `-`; response `RoleDTO[]`; events `-`
- `POST /api/v1/role-context` — capability `profile.read_self`; request `SwitchRoleContextInput`; response `RoleContextDTO`; events `user.role_context_changed`

## Related capabilities

- `profile.read_self` — Read own profile
- `profile.update_self` — Update own profile
- `group.manage` — Manage group where owner/admin
- `experience.admin` — Administer any experience
- `admin.user.manage` — Manage user status/roles
- `admin.role.grant` — Grant coarse role/scoped capability
- `admin.audit.read` — Read audit log

## Related routes

- `/verify` — Identity verification / owner `Identity` / P0

## Visual acceptance references

- `HUD-VIS-351` — set 35, `351_welcome_splash.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-352` — set 35, `352_choose_role.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-353` — set 35, `353_create_account.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/signup`
- `HUD-VIS-354` — set 35, `354_verify_phone.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-355` — set 35, `355_create_family_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-356` — set 35, `356_add_children.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-357` — set 35, `357_set_interests.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-358` — set 35, `358_location_access.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-359` — set 35, `359_community_guidelines.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-360` — set 35, `360_onboarding_complete.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-101` — set 11, `101_sign_up.png`, disposition `REFERENCE_ONLY`, route candidate `/signup`
- `HUD-VIS-102` — set 11, `102_login.png`, disposition `REFERENCE_ONLY`, route candidate `/login`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/identity/**`
- `tests/identity/**`
- `docs/execution/P1-002/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: RBAC + scoped authorization service.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-002/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-002/HANDOFF.md. Stop after the task.
```


---

# P1-003 — Implement signup/login/recovery UI

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-003` |
| Phase | Phase 1 |
| Epic | Auth |
| Priority | P0 |
| Dependency wave | 20 |
| Dependencies | P1-001 |
| Owning module | `src/modules/identity` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement signup/login/recovery UI** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-003-implement-signup-login-recovery-ui`.

## Required implementation

1. set35 auth surfaces.
2. Use React forms with validated server boundaries and explicit loading/error/success states.
3. Preserve redirect intent safely.
4. Avoid leaking whether an account exists in recovery flows.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.

## Related API contracts

- `GET /api/v1/me` — capability `profile.read_self`; request `-`; response `CurrentUserDTO`; events `-`
- `PATCH /api/v1/me` — capability `profile.update_self`; request `UpdateProfileInput`; response `CurrentUserDTO`; events `user.profile_updated`
- `POST /api/v1/auth/link-phone` — capability `profile.update_self`; request `LinkPhoneInput`; response `VerificationChallengeDTO`; events `auth.phone_challenge_created`
- `POST /api/v1/auth/verify-phone` — capability `profile.update_self`; request `VerifyPhoneInput`; response `CurrentUserDTO`; events `auth.phone_verified`
- `GET /api/v1/roles` — capability `profile.read_self`; request `-`; response `RoleDTO[]`; events `-`
- `POST /api/v1/role-context` — capability `profile.read_self`; request `SwitchRoleContextInput`; response `RoleContextDTO`; events `user.role_context_changed`

## Related capabilities

- `profile.read_self` — Read own profile
- `profile.update_self` — Update own profile

## Related routes

- `/verify` — Identity verification / owner `Identity` / P0

## Visual acceptance references

- `HUD-VIS-351` — set 35, `351_welcome_splash.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-352` — set 35, `352_choose_role.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-353` — set 35, `353_create_account.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/signup`
- `HUD-VIS-354` — set 35, `354_verify_phone.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-355` — set 35, `355_create_family_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-356` — set 35, `356_add_children.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-357` — set 35, `357_set_interests.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-358` — set 35, `358_location_access.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-359` — set 35, `359_community_guidelines.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-360` — set 35, `360_onboarding_complete.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-101` — set 11, `101_sign_up.png`, disposition `REFERENCE_ONLY`, route candidate `/signup`
- `HUD-VIS-102` — set 11, `102_login.png`, disposition `REFERENCE_ONLY`, route candidate `/login`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/identity/**`
- `tests/identity/**`
- `docs/execution/P1-003/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set35 auth surfaces.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-003/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-003/HANDOFF.md. Stop after the task.
```


---

# P1-004 — Implement phone verification and account linking

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-004` |
| Phase | Phase 1 |
| Epic | Auth |
| Priority | P0 |
| Dependency wave | 21 |
| Dependencies | P1-003 |
| Owning module | `src/modules/identity` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement phone verification and account linking** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-003**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-004-implement-phone-verification-and-account-linking`.

## Required implementation

1. verified phone identity flow.
2. Use React forms with validated server boundaries and explicit loading/error/success states.
3. Preserve redirect intent safely.
4. Avoid leaking whether an account exists in recovery flows.
5. Treat phone verification as linked identity; do not overwrite canonical User based solely on phone input.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.

## Related API contracts

- `GET /api/v1/me` — capability `profile.read_self`; request `-`; response `CurrentUserDTO`; events `-`
- `PATCH /api/v1/me` — capability `profile.update_self`; request `UpdateProfileInput`; response `CurrentUserDTO`; events `user.profile_updated`
- `POST /api/v1/auth/link-phone` — capability `profile.update_self`; request `LinkPhoneInput`; response `VerificationChallengeDTO`; events `auth.phone_challenge_created`
- `POST /api/v1/auth/verify-phone` — capability `profile.update_self`; request `VerifyPhoneInput`; response `CurrentUserDTO`; events `auth.phone_verified`
- `GET /api/v1/roles` — capability `profile.read_self`; request `-`; response `RoleDTO[]`; events `-`
- `POST /api/v1/role-context` — capability `profile.read_self`; request `SwitchRoleContextInput`; response `RoleContextDTO`; events `user.role_context_changed`

## Related capabilities

- `profile.read_self` — Read own profile
- `profile.update_self` — Update own profile

## Related routes

- `/verify` — Identity verification / owner `Identity` / P0

## Visual acceptance references

- `HUD-VIS-351` — set 35, `351_welcome_splash.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-352` — set 35, `352_choose_role.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-353` — set 35, `353_create_account.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/signup`
- `HUD-VIS-354` — set 35, `354_verify_phone.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-355` — set 35, `355_create_family_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-356` — set 35, `356_add_children.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-357` — set 35, `357_set_interests.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-358` — set 35, `358_location_access.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-359` — set 35, `359_community_guidelines.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-360` — set 35, `360_onboarding_complete.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-101` — set 11, `101_sign_up.png`, disposition `REFERENCE_ONLY`, route candidate `/signup`
- `HUD-VIS-102` — set 11, `102_login.png`, disposition `REFERENCE_ONLY`, route candidate `/login`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/identity/**`
- `tests/identity/**`
- `docs/execution/P1-004/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: verified phone identity flow.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-004/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-004/HANDOFF.md. Stop after the task.
```


---

# P1-005 — Implement resumable onboarding state machine

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-005` |
| Phase | Phase 1 |
| Epic | Onboarding |
| Priority | P0 |
| Dependency wave | 21 |
| Dependencies | P1-003 |
| Owning module | `src/modules/onboarding` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement resumable onboarding state machine** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-003**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-005-implement-resumable-onboarding-state-machine`.

## Required implementation

1. set35 steps and persistence.
2. Implement a resumable state machine, not route-local booleans.
3. Persist progress server-side and support safe resume after interruption.
4. Track policy/consent versions where required.
5. Define explicit onboarding states and transition table; resume from server state.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.
- `FamilyProfile` — aggregate_root; sensitivity: RESTRICTED; Parent-owned family unit.
- `FamilyMember` — entity; sensitivity: HIGHLY_RESTRICTED; Child/member data minimized; age stage preferred over birthdate in discovery.
- `Interest` — reference; sensitivity: PUBLIC; Controlled taxonomy.
- `FamilyInterest` — association; sensitivity: CONFIDENTIAL; Matching/discovery preference input.
- `FamilyVisibilityRule` — entity; sensitivity: RESTRICTED; Field-level audience policy.

## Related API contracts

- `GET /api/v1/onboarding` — capability `profile.read_self`; request `-`; response `OnboardingStateDTO`; events `-`
- `PATCH /api/v1/onboarding` — capability `profile.update_self`; request `OnboardingStepInput`; response `OnboardingStateDTO`; events `onboarding.step_completed`
- `POST /api/v1/onboarding/complete` — capability `profile.update_self`; request `CompleteOnboardingInput`; response `OnboardingStateDTO`; events `onboarding.completed`

## Related capabilities

- `profile.read_self` — Read own profile
- `profile.update_self` — Update own profile
- `family.manage_self` — Manage own family profile/members
- `family.view_connected` — View visibility-filtered connected family
- `matching.view_candidates` — View privacy-filtered candidates
- `experience.register` — Register self/family for experience
- `privacy.consent.manage_self` — Manage own consent records
- `privacy.request.create` — Create own data request
- `privacy.request.process` — Process privacy request
- `privacy.policy.manage` — Manage retention/anonymization rules
- `privacy.export.approve` — Approve governed export

## Related routes

- `/verify` — Identity verification / owner `Identity` / P0
- `/onboarding/family` — Family profile / owner `Family` / P0
- `/app/family` — Family profile / owner `Family` / P0
- `/app/family/members` — Family members / owner `Family` / P0
- `/app/matching` — Family matching / owner `Family` / P1
- `/app/calendar` — Family calendar / owner `Family` / P1

## Visual acceptance references

- `HUD-VIS-351` — set 35, `351_welcome_splash.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-352` — set 35, `352_choose_role.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-353` — set 35, `353_create_account.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/signup`
- `HUD-VIS-354` — set 35, `354_verify_phone.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-355` — set 35, `355_create_family_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-356` — set 35, `356_add_children.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-357` — set 35, `357_set_interests.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-358` — set 35, `358_location_access.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-359` — set 35, `359_community_guidelines.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding`
- `HUD-VIS-360` — set 35, `360_onboarding_complete.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-101` — set 11, `101_sign_up.png`, disposition `REFERENCE_ONLY`, route candidate `/signup`
- `HUD-VIS-102` — set 11, `102_login.png`, disposition `REFERENCE_ONLY`, route candidate `/login`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/onboarding/**`
- `tests/onboarding/**`
- `docs/execution/P1-005/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set35 steps and persistence.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-005/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-005/HANDOFF.md. Stop after the task.
```


---

# P1-006 — Implement FamilyProfile/FamilyMember

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-006` |
| Phase | Phase 1 |
| Epic | Family |
| Priority | P0 |
| Dependency wave | 22 |
| Dependencies | P1-005 |
| Owning module | `src/modules/family` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement FamilyProfile/FamilyMember** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-006-implement-familyprofile-familymember`.

## Required implementation

1. family core and privacy-safe DTOs.
2. Minimize child-related data in public and discovery DTOs.
3. Separate private profile data from discovery-safe projections.
4. Enforce family ownership/object scope.

## Related canonical entities

- `FamilyProfile` — aggregate_root; sensitivity: RESTRICTED; Parent-owned family unit.
- `FamilyMember` — entity; sensitivity: HIGHLY_RESTRICTED; Child/member data minimized; age stage preferred over birthdate in discovery.
- `Interest` — reference; sensitivity: PUBLIC; Controlled taxonomy.
- `FamilyInterest` — association; sensitivity: CONFIDENTIAL; Matching/discovery preference input.
- `FamilyVisibilityRule` — entity; sensitivity: RESTRICTED; Field-level audience policy.

## Related API contracts

- `GET /api/v1/family` — capability `family.manage_self`; request `-`; response `FamilyProfileDTO`; events `-`
- `PUT /api/v1/family` — capability `family.manage_self`; request `UpsertFamilyProfileInput`; response `FamilyProfileDTO`; events `family.updated`
- `POST /api/v1/family/members` — capability `family.manage_self`; request `CreateFamilyMemberInput`; response `FamilyMemberDTO`; events `family.member_added`
- `PATCH /api/v1/family/members/{memberId}` — capability `family.manage_self`; request `UpdateFamilyMemberInput`; response `FamilyMemberDTO`; events `family.member_updated`
- `DELETE /api/v1/family/members/{memberId}` — capability `family.manage_self`; request `-`; response `204`; events `family.member_removed`

## Related capabilities

- `family.manage_self` — Manage own family profile/members
- `family.view_connected` — View visibility-filtered connected family
- `experience.register` — Register self/family for experience

## Related routes

- `/onboarding/family` — Family profile / owner `Family` / P0
- `/app/family` — Family profile / owner `Family` / P0
- `/app/family/members` — Family members / owner `Family` / P0
- `/app/matching` — Family matching / owner `Family` / P1
- `/app/calendar` — Family calendar / owner `Family` / P1

## Visual acceptance references

- `HUD-VIS-461` — set 46, `461_my_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-462` — set 46, `462_family_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-463` — set 46, `463_connections.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-464` — set 46, `464_add_connection.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-465` — set 46, `465_connection_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-466` — set 46, `466_member_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-467` — set 46, `467_family_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family`
- `HUD-VIS-468` — set 46, `468_privacy_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-469` — set 46, `469_account_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family`
- `HUD-VIS-470` — set 46, `470_edit_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-011` — set 2, `11_parent_account_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-012` — set 2, `12_saved_items_activities_events.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/saved`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/family/**`
- `tests/family/**`
- `docs/execution/P1-006/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: family core and privacy-safe DTOs.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-006/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-006/HANDOFF.md. Stop after the task.
```


---

# P1-007 — Implement consent records and policy versions

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-007` |
| Phase | Phase 1 |
| Epic | Consent |
| Priority | P0 |
| Dependency wave | 22 |
| Dependencies | P1-005 |
| Owning module | `src/modules/privacy` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement consent records and policy versions** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-007-implement-consent-records-and-policy-versions`.

## Required implementation

1. set60 consent management foundation.
2. Version policy text references and record consent provenance.
3. Consent withdrawal must have explicit downstream behavior.
4. Do not infer consent from UI navigation.
5. Store PolicyVersion references and ConsentRecord provenance.

## Related canonical entities

- `ConsentRecord` — append_only; sensitivity: RESTRICTED; Purpose, source, timestamp, evidence.
- `PolicyVersion` — versioned_reference; sensitivity: PUBLIC; Legal source reference.
- `DataRequest` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Access/export/delete/correct.
- `RetentionPolicy` — versioned_reference; sensitivity: RESTRICTED; Cannot be silently disabled.
- `AnonymizationRule` — versioned_reference; sensitivity: RESTRICTED; Audited transform definition.
- `ExportApproval` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Four-eyes policy for sensitive exports.
- `PrivacyIncident` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Restricted access and timeline.

## Related API contracts

- `GET /api/v1/consents` — capability `privacy.consent.manage_self`; request `-`; response `ConsentSummaryDTO`; events `-`
- `POST /api/v1/consents` — capability `privacy.consent.manage_self`; request `ConsentDecisionInput`; response `ConsentRecordDTO`; events `consent.changed`
- `POST /api/v1/privacy/requests` — capability `privacy.request.create`; request `CreateDataRequestInput`; response `DataRequestDTO`; events `privacy.request_submitted`
- `GET /api/v1/privacy/requests` — capability `privacy.request.create`; request `-`; response `DataRequestDTO[]`; events `-`
- `GET /api/v1/admin/privacy/governance` — capability `privacy.policy.manage`; request `-`; response `GovernanceDashboardDTO`; events `-`
- `POST /api/v1/admin/privacy/exports/{id}/approve` — capability `privacy.export.approve`; request `ExportApprovalInput`; response `ExportApprovalDTO`; events `privacy.export_approved`

## Related capabilities

- `matching.view_candidates` — View privacy-filtered candidates
- `privacy.consent.manage_self` — Manage own consent records
- `privacy.request.create` — Create own data request
- `privacy.request.process` — Process privacy request
- `privacy.policy.manage` — Manage retention/anonymization rules
- `privacy.export.approve` — Approve governed export

## Related routes

- `/privacy` — Privacy / owner `Privacy` / P0
- `/app/privacy` — Privacy center / owner `Privacy` / P0
- `/admin/privacy` — Privacy governance / owner `Privacy` / P0

## Visual acceptance references

- `HUD-OVR-S60` — set 60, `huddle_set60_accessibility_localization_consent_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-OVR-S63` — set 63, `huddle_set63_data_privacy_governance_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-601` — set 60, `601_accessibility_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-602` — set 60, `602_high_contrast_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-603` — set 60, `603_large_text_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-604` — set 60, `604_language_selector_en_no.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-605` — set 60, `605_consent_management.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-606` — set 60, `606_cookie_preferences.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-607` — set 60, `607_data_download_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-608` — set 60, `608_delete_account_flow.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-609` — set 60, `609_parent_consent_update.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-610` — set 60, `610_privacy_request_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/privacy/**`
- `tests/privacy/**`
- `docs/execution/P1-007/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set60 consent management foundation.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-007/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-007/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-007. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-007/HANDOFF.md. Stop after the task.
```


---

# P1-008 — Implement canonical /app shell and role context

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-008` |
| Phase | Phase 1 |
| Epic | App Shell |
| Priority | P0 |
| Dependency wave | 21 |
| Dependencies | P1-002 |
| Owning module | `src/modules/shell` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement canonical /app shell and role context** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-008-implement-canonical-app-shell-and-role-context`.

## Required implementation

1. set39 shell.
2. Use React Server Components by default; add Client Components only for actual interactivity.
3. Resolve current user and role context on the server.
4. Provide loading, empty, forbidden and error boundaries.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- `profile.read_self` — Read own profile
- `profile.update_self` — Update own profile

## Related routes

- `/verify` — Identity verification / owner `Identity` / P0

## Visual acceptance references

- `HUD-VIS-391` — set 39, `391_app_home_shell.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-392` — set 39, `392_mobile_bottom_navigation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-393` — set 39, `393_web_app_header.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-394` — set 39, `394_global_search_entry.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-395` — set 39, `395_saved_hub.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-396` — set 39, `396_notifications_center.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-397` — set 39, `397_account_menu.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-398` — set 39, `398_safety_entry_point.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-399` — set 39, `399_location_switcher.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-400` — set 39, `400_role_switcher.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/shell/**`
- `tests/shell/**`
- `docs/execution/P1-008/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set39 shell.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-008/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-008/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-008. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-008/HANDOFF.md. Stop after the task.
```


---

# P1-009 — Implement responsive navigation contract

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-009` |
| Phase | Phase 1 |
| Epic | Responsive |
| Priority | P0 |
| Dependency wave | 22 |
| Dependencies | P1-008 |
| Owning module | `src/modules/shell` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement responsive navigation contract** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-008**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-009-implement-responsive-navigation-contract`.

## Required implementation

1. set61 + set39 behavior.
2. Implement semantic compact/medium/wide behavior from canonical references.
3. Do not create page-specific arbitrary breakpoints.
4. Verify keyboard and touch target behavior.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- `/verify` — Identity verification / owner `Identity` / P0

## Visual acceptance references

- `HUD-VIS-341` — set 34, `341_mobile_home_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app`
- `HUD-VIS-342` — set 34, `342_mobile_marketplace_catalog_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app`
- `HUD-VIS-343` — set 34, `343_mobile_product_detail_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app`
- `HUD-VIS-344` — set 34, `344_mobile_create_listing_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app`
- `HUD-VIS-345` — set 34, `345_mobile_messages_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app`
- `HUD-VIS-346` — set 34, `346_mobile_event_detail_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app/events/*`
- `HUD-VIS-347` — set 34, `347_mobile_event_registration_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app`
- `HUD-VIS-348` — set 34, `348_mobile_qr_ticket_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app/events/*`
- `HUD-VIS-349` — set 34, `349_mobile_family_match_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app/connections/*`
- `HUD-VIS-350` — set 34, `350_mobile_parent_dashboard_v3.png`, disposition `REFERENCE_ONLY`, route candidate `/app`
- `HUD-OVR-S61` — set 61, `huddle_set61_responsive_web_variants_overview.png`, disposition `RESPONSIVE_REFERENCE`, route candidate `N/A`
- `HUD-VIS-611` — set 61, `611_desktop_home_variant.png`, disposition `RESPONSIVE_REFERENCE`, route candidate `N/A`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/shell/**`
- `tests/shell/**`
- `docs/execution/P1-009/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set61 + set39 behavior.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-009/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-009/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-009. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-009/HANDOFF.md. Stop after the task.
```


---

# P1-010 — Implement secure media upload pipeline

## Metadata

| Field | Value |
|---|---|
| Task ID | `P1-010` |
| Phase | Phase 1 |
| Epic | Media |
| Priority | P0 |
| Dependency wave | 23 |
| Dependencies | P1-006 |
| Owning module | `src/modules/media` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement secure media upload pipeline** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-006**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p1-010-implement-secure-media-upload-pipeline`.

## Required implementation

1. signed upload, scan/quarantine hooks.
2. Use signed uploads, ownership checks, MIME/size allowlists and quarantine state.
3. Keep storage provider behind MediaStorage adapter.
4. Strip sensitive image metadata where applicable.
5. Include signed upload intent, finalize endpoint, quarantine status, scan hook and metadata stripping path.

## Related canonical entities

- `FeatureFlag` — aggregate_root; sensitivity: INTERNAL; P2/P3 admin only.
- `BackgroundJob` — entity; sensitivity: INTERNAL; Operational record, not queue implementation itself.
- `OutboxEvent` — append_only; sensitivity: INTERNAL; Transactional domain event.
- `MediaAsset` — aggregate_root; sensitivity: RESTRICTED; Storage key, MIME, size, checksum, variants.
- `IdempotencyKey` — entity; sensitivity: INTERNAL; Mutation result replay protection.

## Related API contracts

- `POST /api/v1/media/uploads` — capability `profile.update_self`; request `CreateUploadInput`; response `SignedUploadDTO`; events `media.upload_created`
- `POST /api/v1/media/{mediaId}/complete` — capability `profile.update_self`; request `CompleteUploadInput`; response `MediaAssetDTO`; events `media.upload_completed`

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- `HUD-VIS-081` — set 9, `81_search_results.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-082` — set 9, `82_filter_sort.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-083` — set 9, `83_group_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-084` — set 9, `84_event_details.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-085` — set 9, `85_rsvp_guests.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-086` — set 9, `86_create_group.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-087` — set 9, `87_media_gallery.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-088` — set 9, `88_file_document_viewer.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-089` — set 9, `89_member_list.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-090` — set 9, `90_group_settings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-481` — set 48, `481_feed_home.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/content`
- `HUD-VIS-482` — set 48, `482_create_post.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/content`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/media/**`
- `tests/media/**`
- `docs/execution/P1-010/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: signed upload, scan/quarantine hooks.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P1-010/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P1-010/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P1-010. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P1-010/HANDOFF.md. Stop after the task.
```


---

# P2-001 — Implement global search provider and endpoint

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-001` |
| Phase | Phase 2 |
| Epic | Discovery |
| Priority | P0 |
| Dependency wave | 22 |
| Dependencies | P1-008 |
| Owning module | `src/modules/search` |
| Risk | MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement global search provider and endpoint** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-008**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-001-implement-global-search-provider-and-endpoint`.

## Required implementation

1. Postgres FTS/trigram adapter.
2. Filter authorization-sensitive records before serialization.
3. Keep provider abstraction around search implementation.
4. Add deterministic relevance and pagination tests.
5. Initial adapter uses PostgreSQL full-text/trigram; keep SearchProvider interface provider-neutral.

## Related canonical entities

- `AnalyticsEvent` — append_only; sensitivity: PSEUDONYMOUS; Versioned schema; no prohibited sensitive payload.
- `MetricDefinition` — versioned_reference; sensitivity: INTERNAL; Owner, formula, dimensions.
- `ReportDefinition` — versioned_reference; sensitivity: INTERNAL; Access and privacy policy.

## Related API contracts

- `GET /api/v1/search` — capability `public.read`; request `GlobalSearchQuery`; response `GlobalSearchDTO`; events `search.performed`

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- `/app/search` — Global search / owner `Search` / P0

## Visual acceptance references

- `HUD-VIS-401` — set 40, `401_services_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-402` — set 40, `402_service_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-403` — set 40, `403_service_search_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-404` — set 40, `404_service_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-405` — set 40, `405_provider_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-406` — set 40, `406_book_service.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services`
- `HUD-VIS-407` — set 40, `407_booking_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-408` — set 40, `408_my_bookings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-409` — set 40, `409_service_reviews.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-410` — set 40, `410_recommendations.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services`
- `HUD-VIS-081` — set 9, `81_search_results.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-082` — set 9, `82_filter_sort.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/search/**`
- `tests/search/**`
- `docs/execution/P2-001/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: Postgres FTS/trigram adapter.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-001/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-001/HANDOFF.md. Stop after the task.
```


---

# P2-002 — Implement Experience/Occurrence model

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-002` |
| Phase | Phase 2 |
| Epic | Experiences |
| Priority | P0 |
| Dependency wave | 24 |
| Dependencies | P1-010 |
| Owning module | `src/modules/experiences` |
| Risk | MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement Experience/Occurrence model** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-010**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-002-implement-experience-occurrence-model`.

## Required implementation

1. event/activity shared core.
2. Use Experience + Occurrence shared core with EVENT/ACTIVITY kind.
3. Enforce capacity and registration invariants transactionally.
4. Do not duplicate event and activity infrastructure.
5. Implement ExperienceKind EVENT|ACTIVITY plus occurrence model and detail extensions; avoid duplicate event/activity tables for shared primitives.

## Related canonical entities

- `Experience` — aggregate_root; sensitivity: CONFIDENTIAL; Kind EVENT|ACTIVITY; common discovery fields.
- `EventDetails` — entity; sensitivity: CONFIDENTIAL; Ticketing/host/event specifics.
- `ActivityDetails` — entity; sensitivity: CONFIDENTIAL; Age range/recurrence/activity specifics.
- `ExperienceOccurrence` — aggregate_root; sensitivity: CONFIDENTIAL; Timezone-aware start/end/capacity.
- `Registration` — aggregate_root; sensitivity: RESTRICTED; Family member data minimized.
- `Ticket` — entity; sensitivity: RESTRICTED; Opaque QR token; rotate/revoke.
- `CheckIn` — append_only; sensitivity: RESTRICTED; Auditable operator/time/device.

## Related API contracts

- `GET /api/v1/experiences` — capability `public.read`; request `ExperienceQuery`; response `Paginated<ExperienceCardDTO>`; events `experience.search_viewed`
- `GET /api/v1/experiences/{experienceId}` — capability `public.read`; request `-`; response `ExperienceDTO`; events `experience.viewed`
- `POST /api/v1/experiences` — capability `experience.create`; request `CreateExperienceInput`; response `ExperienceDTO`; events `experience.created`
- `PATCH /api/v1/experiences/{experienceId}` — capability `experience.manage_own`; request `UpdateExperienceInput`; response `ExperienceDTO`; events `experience.updated`
- `POST /api/v1/experiences/{experienceId}/publish` — capability `experience.manage_own`; request `PublishExperienceInput`; response `ExperienceDTO`; events `experience.published`
- `POST /api/v1/occurrences/{occurrenceId}/registrations` — capability `experience.register`; request `CreateRegistrationInput`; response `RegistrationDTO`; events `registration.created`
- `DELETE /api/v1/registrations/{registrationId}` — capability `experience.register`; request `CancelRegistrationInput`; response `204`; events `registration.cancelled`
- `POST /api/v1/checkins` — capability `experience.checkin`; request `CheckInInput`; response `CheckInDTO`; events `registration.checked_in`

## Related capabilities

- `experience.register` — Register self/family for experience
- `experience.create` — Create organizer-owned event/activity
- `experience.manage_own` — Manage own experience
- `experience.checkin` — Check in registered participant
- `experience.admin` — Administer any experience

## Related routes

- `/events` — Events discovery / owner `Experiences` / P0
- `/events/[eventId]` — Event detail / owner `Experiences` / P0
- `/activities` — Activities discovery / owner `Experiences` / P0
- `/activities/[activityId]` — Activity detail / owner `Experiences` / P1
- `/app/events` — Events / owner `Experiences` / P0
- `/app/activities` — Activities / owner `Experiences` / P0

## Visual acceptance references

- `HUD-VIS-371` — set 37, `371_events_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-372` — set 37, `372_events_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-373` — set 37, `373_events_search_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-374` — set 37, `374_event_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-375` — set 37, `375_event_host_organizer.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-376` — set 37, `376_register_for_event.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-377` — set 37, `377_registration_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-378` — set 37, `378_my_events.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-379` — set 37, `379_event_reminder.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-380` — set 37, `380_check_in_qr_code.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-021` — set 3, `21_activity_detail_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/activities/*`
- `HUD-VIS-022` — set 3, `22_event_detail_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/experiences/**`
- `tests/experiences/**`
- `docs/execution/P2-002/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: event/activity shared core.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-002/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-002/HANDOFF.md. Stop after the task.
```


---

# P2-003 — Implement public/app discovery

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-003` |
| Phase | Phase 2 |
| Epic | Experiences |
| Priority | P0 |
| Dependency wave | 25 |
| Dependencies | P2-002 |
| Owning module | `src/modules/experiences` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement public/app discovery** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-003-implement-public-app-discovery`.

## Required implementation

1. set37 discovery.
2. Use Experience + Occurrence shared core with EVENT/ACTIVITY kind.
3. Enforce capacity and registration invariants transactionally.
4. Do not duplicate event and activity infrastructure.

## Related canonical entities

- `Experience` — aggregate_root; sensitivity: CONFIDENTIAL; Kind EVENT|ACTIVITY; common discovery fields.
- `EventDetails` — entity; sensitivity: CONFIDENTIAL; Ticketing/host/event specifics.
- `ActivityDetails` — entity; sensitivity: CONFIDENTIAL; Age range/recurrence/activity specifics.
- `ExperienceOccurrence` — aggregate_root; sensitivity: CONFIDENTIAL; Timezone-aware start/end/capacity.
- `Registration` — aggregate_root; sensitivity: RESTRICTED; Family member data minimized.
- `Ticket` — entity; sensitivity: RESTRICTED; Opaque QR token; rotate/revoke.
- `CheckIn` — append_only; sensitivity: RESTRICTED; Auditable operator/time/device.

## Related API contracts

- `GET /api/v1/experiences` — capability `public.read`; request `ExperienceQuery`; response `Paginated<ExperienceCardDTO>`; events `experience.search_viewed`
- `GET /api/v1/experiences/{experienceId}` — capability `public.read`; request `-`; response `ExperienceDTO`; events `experience.viewed`
- `POST /api/v1/experiences` — capability `experience.create`; request `CreateExperienceInput`; response `ExperienceDTO`; events `experience.created`
- `PATCH /api/v1/experiences/{experienceId}` — capability `experience.manage_own`; request `UpdateExperienceInput`; response `ExperienceDTO`; events `experience.updated`
- `POST /api/v1/experiences/{experienceId}/publish` — capability `experience.manage_own`; request `PublishExperienceInput`; response `ExperienceDTO`; events `experience.published`
- `POST /api/v1/occurrences/{occurrenceId}/registrations` — capability `experience.register`; request `CreateRegistrationInput`; response `RegistrationDTO`; events `registration.created`
- `DELETE /api/v1/registrations/{registrationId}` — capability `experience.register`; request `CancelRegistrationInput`; response `204`; events `registration.cancelled`
- `POST /api/v1/checkins` — capability `experience.checkin`; request `CheckInInput`; response `CheckInDTO`; events `registration.checked_in`

## Related capabilities

- `experience.register` — Register self/family for experience
- `experience.create` — Create organizer-owned event/activity
- `experience.manage_own` — Manage own experience
- `experience.checkin` — Check in registered participant
- `experience.admin` — Administer any experience

## Related routes

- `/events` — Events discovery / owner `Experiences` / P0
- `/events/[eventId]` — Event detail / owner `Experiences` / P0
- `/activities` — Activities discovery / owner `Experiences` / P0
- `/activities/[activityId]` — Activity detail / owner `Experiences` / P1
- `/app/events` — Events / owner `Experiences` / P0
- `/app/activities` — Activities / owner `Experiences` / P0

## Visual acceptance references

- `HUD-VIS-371` — set 37, `371_events_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-372` — set 37, `372_events_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-373` — set 37, `373_events_search_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-374` — set 37, `374_event_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-375` — set 37, `375_event_host_organizer.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-376` — set 37, `376_register_for_event.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-377` — set 37, `377_registration_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-378` — set 37, `378_my_events.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-379` — set 37, `379_event_reminder.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-380` — set 37, `380_check_in_qr_code.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-021` — set 3, `21_activity_detail_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/activities/*`
- `HUD-VIS-022` — set 3, `22_event_detail_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/experiences/**`
- `tests/experiences/**`
- `docs/execution/P2-003/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set37 discovery.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-003/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-003/HANDOFF.md. Stop after the task.
```


---

# P2-004 — Implement registration/cancellation

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-004` |
| Phase | Phase 2 |
| Epic | Experiences |
| Priority | P0 |
| Dependency wave | 25 |
| Dependencies | P2-002 |
| Owning module | `src/modules/experiences` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement registration/cancellation** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-004-implement-registration-cancellation`.

## Required implementation

1. registration invariants.
2. Use Experience + Occurrence shared core with EVENT/ACTIVITY kind.
3. Enforce capacity and registration invariants transactionally.
4. Do not duplicate event and activity infrastructure.
5. Capacity changes and registration/cancellation must be transaction-safe and concurrency-tested.

## Related canonical entities

- `Experience` — aggregate_root; sensitivity: CONFIDENTIAL; Kind EVENT|ACTIVITY; common discovery fields.
- `EventDetails` — entity; sensitivity: CONFIDENTIAL; Ticketing/host/event specifics.
- `ActivityDetails` — entity; sensitivity: CONFIDENTIAL; Age range/recurrence/activity specifics.
- `ExperienceOccurrence` — aggregate_root; sensitivity: CONFIDENTIAL; Timezone-aware start/end/capacity.
- `Registration` — aggregate_root; sensitivity: RESTRICTED; Family member data minimized.
- `Ticket` — entity; sensitivity: RESTRICTED; Opaque QR token; rotate/revoke.
- `CheckIn` — append_only; sensitivity: RESTRICTED; Auditable operator/time/device.

## Related API contracts

- `GET /api/v1/experiences` — capability `public.read`; request `ExperienceQuery`; response `Paginated<ExperienceCardDTO>`; events `experience.search_viewed`
- `GET /api/v1/experiences/{experienceId}` — capability `public.read`; request `-`; response `ExperienceDTO`; events `experience.viewed`
- `POST /api/v1/experiences` — capability `experience.create`; request `CreateExperienceInput`; response `ExperienceDTO`; events `experience.created`
- `PATCH /api/v1/experiences/{experienceId}` — capability `experience.manage_own`; request `UpdateExperienceInput`; response `ExperienceDTO`; events `experience.updated`
- `POST /api/v1/experiences/{experienceId}/publish` — capability `experience.manage_own`; request `PublishExperienceInput`; response `ExperienceDTO`; events `experience.published`
- `POST /api/v1/occurrences/{occurrenceId}/registrations` — capability `experience.register`; request `CreateRegistrationInput`; response `RegistrationDTO`; events `registration.created`
- `DELETE /api/v1/registrations/{registrationId}` — capability `experience.register`; request `CancelRegistrationInput`; response `204`; events `registration.cancelled`
- `POST /api/v1/checkins` — capability `experience.checkin`; request `CheckInInput`; response `CheckInDTO`; events `registration.checked_in`

## Related capabilities

- `experience.register` — Register self/family for experience
- `experience.create` — Create organizer-owned event/activity
- `experience.manage_own` — Manage own experience
- `experience.checkin` — Check in registered participant
- `experience.admin` — Administer any experience

## Related routes

- `/events` — Events discovery / owner `Experiences` / P0
- `/events/[eventId]` — Event detail / owner `Experiences` / P0
- `/activities` — Activities discovery / owner `Experiences` / P0
- `/activities/[activityId]` — Activity detail / owner `Experiences` / P1
- `/app/events` — Events / owner `Experiences` / P0
- `/app/activities` — Activities / owner `Experiences` / P0

## Visual acceptance references

- `HUD-VIS-371` — set 37, `371_events_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-372` — set 37, `372_events_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-373` — set 37, `373_events_search_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-374` — set 37, `374_event_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-375` — set 37, `375_event_host_organizer.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-376` — set 37, `376_register_for_event.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-377` — set 37, `377_registration_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-378` — set 37, `378_my_events.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-379` — set 37, `379_event_reminder.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events`
- `HUD-VIS-380` — set 37, `380_check_in_qr_code.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-021` — set 3, `21_activity_detail_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/activities/*`
- `HUD-VIS-022` — set 3, `22_event_detail_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/experiences/**`
- `tests/experiences/**`
- `docs/execution/P2-004/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: registration invariants.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-004/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-004/HANDOFF.md. Stop after the task.
```


---

# P2-005 — Implement Listing draft lifecycle

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-005` |
| Phase | Phase 2 |
| Epic | Listings |
| Priority | P0 |
| Dependency wave | 24 |
| Dependencies | P1-010 |
| Owning module | `src/modules/listings` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement Listing draft lifecycle** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-010**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-005-implement-listing-draft-lifecycle`.

## Required implementation

1. set36 create flow.
2. Keep P2P Listing bounded context separate from Product catalog and Order.
3. Use explicit draft/published/reserved/closed lifecycle.
4. Apply ownership and moderation policy server-side.

## Related canonical entities

- `Listing` — aggregate_root; sensitivity: CONFIDENTIAL; P2P listing only.
- `ListingMedia` — association; sensitivity: CONFIDENTIAL; Ordered media.
- `ListingInquiry` — aggregate_root; sensitivity: CONFIDENTIAL; Creates contextual conversation after policy checks.
- `ListingReservation` — aggregate_root; sensitivity: CONFIDENTIAL; Concurrency-safe reservation.

## Related API contracts

- `GET /api/v1/listings` — capability `public.read`; request `ListingQuery`; response `Paginated<ListingCardDTO>`; events `listing.search_viewed`
- `POST /api/v1/listings` — capability `listing.create`; request `CreateListingInput`; response `ListingDTO`; events `listing.created`
- `GET /api/v1/listings/{listingId}` — capability `public.read`; request `-`; response `ListingDTO`; events `listing.viewed`
- `PATCH /api/v1/listings/{listingId}` — capability `listing.manage_own`; request `UpdateListingInput`; response `ListingDTO`; events `listing.updated`
- `POST /api/v1/listings/{listingId}/publish` — capability `listing.manage_own`; request `PublishListingInput`; response `ListingDTO`; events `listing.published`
- `POST /api/v1/listings/{listingId}/reserve` — capability `order.create`; request `ReserveListingInput`; response `ListingReservationDTO`; events `listing.reserved`
- `POST /api/v1/listings/{listingId}/inquiries` — capability `message.send`; request `CreateInquiryInput`; response `ConversationDTO`; events `listing.inquiry_created`

## Related capabilities

- `listing.create` — Create own P2P listing
- `listing.manage_own` — Manage own listing
- `listing.moderate` — Approve/remove listing

## Related routes

- `/marketplace/listings/[listingId]` — P2P listing / owner `Listings` / P0

## Visual acceptance references

- `HUD-VIS-361` — set 36, `361_marketplace_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-362` — set 36, `362_categories_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-363` — set 36, `363_search_results.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-364` — set 36, `364_listing_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-365` — set 36, `365_seller_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-366` — set 36, `366_create_listing_add_photos.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-367` — set 36, `367_create_listing_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-368` — set 36, `368_create_listing_price_location.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-369` — set 36, `369_review_publish.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-370` — set 36, `370_listing_published.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-121` — set 13, `121_listing_review_before_publish.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/seller/listings`
- `HUD-VIS-122` — set 13, `122_listing_published_success.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/seller/listings`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/listings/**`
- `tests/listings/**`
- `docs/execution/P2-005/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set36 create flow.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-005/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-005/HANDOFF.md. Stop after the task.
```


---

# P2-006 — Implement listing discovery/detail

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-006` |
| Phase | Phase 2 |
| Epic | Listings |
| Priority | P0 |
| Dependency wave | 25 |
| Dependencies | P2-005 |
| Owning module | `src/modules/listings` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement listing discovery/detail** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-006-implement-listing-discovery-detail`.

## Required implementation

1. set36 discovery/detail.
2. Keep P2P Listing bounded context separate from Product catalog and Order.
3. Use explicit draft/published/reserved/closed lifecycle.
4. Apply ownership and moderation policy server-side.

## Related canonical entities

- `Listing` — aggregate_root; sensitivity: CONFIDENTIAL; P2P listing only.
- `ListingMedia` — association; sensitivity: CONFIDENTIAL; Ordered media.
- `ListingInquiry` — aggregate_root; sensitivity: CONFIDENTIAL; Creates contextual conversation after policy checks.
- `ListingReservation` — aggregate_root; sensitivity: CONFIDENTIAL; Concurrency-safe reservation.

## Related API contracts

- `GET /api/v1/listings` — capability `public.read`; request `ListingQuery`; response `Paginated<ListingCardDTO>`; events `listing.search_viewed`
- `POST /api/v1/listings` — capability `listing.create`; request `CreateListingInput`; response `ListingDTO`; events `listing.created`
- `GET /api/v1/listings/{listingId}` — capability `public.read`; request `-`; response `ListingDTO`; events `listing.viewed`
- `PATCH /api/v1/listings/{listingId}` — capability `listing.manage_own`; request `UpdateListingInput`; response `ListingDTO`; events `listing.updated`
- `POST /api/v1/listings/{listingId}/publish` — capability `listing.manage_own`; request `PublishListingInput`; response `ListingDTO`; events `listing.published`
- `POST /api/v1/listings/{listingId}/reserve` — capability `order.create`; request `ReserveListingInput`; response `ListingReservationDTO`; events `listing.reserved`
- `POST /api/v1/listings/{listingId}/inquiries` — capability `message.send`; request `CreateInquiryInput`; response `ConversationDTO`; events `listing.inquiry_created`

## Related capabilities

- `listing.create` — Create own P2P listing
- `listing.manage_own` — Manage own listing
- `listing.moderate` — Approve/remove listing

## Related routes

- `/marketplace/listings/[listingId]` — P2P listing / owner `Listings` / P0

## Visual acceptance references

- `HUD-VIS-361` — set 36, `361_marketplace_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-362` — set 36, `362_categories_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-363` — set 36, `363_search_results.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-364` — set 36, `364_listing_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-365` — set 36, `365_seller_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-366` — set 36, `366_create_listing_add_photos.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-367` — set 36, `367_create_listing_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-368` — set 36, `368_create_listing_price_location.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-369` — set 36, `369_review_publish.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-370` — set 36, `370_listing_published.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-121` — set 13, `121_listing_review_before_publish.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/seller/listings`
- `HUD-VIS-122` — set 13, `122_listing_published_success.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/seller/listings`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/listings/**`
- `tests/listings/**`
- `docs/execution/P2-006/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set36 discovery/detail.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-006/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-006/HANDOFF.md. Stop after the task.
```


---

# P2-007 — Implement feed/post/comment/reaction core

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-007` |
| Phase | Phase 2 |
| Epic | Community |
| Priority | P0 |
| Dependency wave | 22 |
| Dependencies | P1-008 |
| Owning module | `src/modules/community` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement feed/post/comment/reaction core** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-008**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-007-implement-feed-post-comment-reaction-core`.

## Required implementation

1. set38 core.
2. Treat posts/comments/reactions as audited/moderatable domain actions.
3. Prevent blocked relationships from leaking interaction paths.
4. Paginate feeds with stable cursors.

## Related canonical entities

- `Group` — aggregate_root; sensitivity: CONFIDENTIAL; Visibility PUBLIC|PRIVATE|SECRET.
- `GroupMembership` — association; sensitivity: CONFIDENTIAL; Group-level roles OWNER|ADMIN|MODERATOR|MEMBER.
- `Post` — aggregate_root; sensitivity: CONFIDENTIAL; Author/context visibility enforced server-side.
- `Comment` — entity; sensitivity: CONFIDENTIAL; Thread parent optional.
- `Reaction` — association; sensitivity: CONFIDENTIAL; Unique actor+target+type.
- `Poll` — entity; sensitivity: CONFIDENTIAL; Vote privacy explicit.

## Related API contracts

- `GET /api/v1/feed` — capability `public.read`; request `FeedQuery`; response `Paginated<FeedItemDTO>`; events `feed.viewed`
- `POST /api/v1/posts` — capability `community.post.create`; request `CreatePostInput`; response `PostDTO`; events `post.created`
- `PATCH /api/v1/posts/{postId}` — capability `community.post.create`; request `UpdatePostInput`; response `PostDTO`; events `post.updated`
- `DELETE /api/v1/posts/{postId}` — capability `community.post.create`; request `-`; response `204`; events `post.deleted`
- `POST /api/v1/posts/{postId}/comments` — capability `community.post.create`; request `CreateCommentInput`; response `CommentDTO`; events `comment.created`
- `POST /api/v1/reactions` — capability `community.post.create`; request `ReactionInput`; response `ReactionDTO`; events `reaction.changed`

## Related capabilities

- `community.post.create` — Create community post
- `community.post.moderate` — Moderate community content

## Related routes

- `/app/community` — Community home / owner `Community` / P0

## Visual acceptance references

- `HUD-VIS-381` — set 38, `381_community_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/community`
- `HUD-VIS-382` — set 38, `382_groups.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-383` — set 38, `383_group_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-384` — set 38, `384_create_post.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/community`
- `HUD-VIS-385` — set 38, `385_messages_conversations.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-386` — set 38, `386_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-387` — set 38, `387_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-388` — set 38, `388_following_connections.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-389` — set 38, `389_share_post.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/community`
- `HUD-VIS-390` — set 38, `390_community_guidelines.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/community`
- `HUD-VIS-041` — set 5, `41_family_profile_page.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-042` — set 5, `42_notifications_center.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/notifications`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/community/**`
- `tests/community/**`
- `docs/execution/P2-007/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set38 core.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-007/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-007/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-007. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-007/HANDOFF.md. Stop after the task.
```


---

# P2-008 — Implement connection request/block core

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-008` |
| Phase | Phase 2 |
| Epic | Connections |
| Priority | P0 |
| Dependency wave | 23 |
| Dependencies | P1-006 |
| Owning module | `src/modules/connections` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement connection request/block core** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-006**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-008-implement-connection-request-block-core`.

## Required implementation

1. set46.
2. Apply block checks before candidate visibility and interaction.
3. Use explicit request/accepted/declined lifecycle.
4. Do not create unrestricted conversation eligibility before policy allows it.

## Related canonical entities

- `MatchPreference` — aggregate_root; sensitivity: RESTRICTED; Explicit opt-in; coarse geography.
- `MatchCandidateSnapshot` — derived; sensitivity: RESTRICTED; Derived score explanation; no sensitive raw feature dump.
- `ConnectionRequest` — aggregate_root; sensitivity: CONFIDENTIAL; Rate-limited and reportable.
- `Connection` — aggregate_root; sensitivity: CONFIDENTIAL; Mutual relationship; messaging eligibility policy.
- `BlockRelation` — entity; sensitivity: RESTRICTED; Always checked by search/matching/messaging.

## Related API contracts

- `POST /api/v1/connections/requests` — capability `connection.request`; request `CreateConnectionRequestInput`; response `ConnectionRequestDTO`; events `connection.requested`
- `POST /api/v1/connections/requests/{id}/accept` — capability `connection.request`; request `-`; response `ConnectionDTO`; events `connection.accepted`
- `POST /api/v1/connections/requests/{id}/decline` — capability `connection.request`; request `-`; response `ConnectionRequestDTO`; events `connection.declined`
- `POST /api/v1/users/{userId}/block` — capability `connection.block`; request `BlockUserInput`; response `BlockRelationDTO`; events `user.blocked`

## Related capabilities

- `connection.request` — Send connection request
- `connection.block` — Block/mute a user

## Related routes

- `/app/connections` — Connections / owner `Connections` / P0

## Visual acceptance references

- `HUD-VIS-461` — set 46, `461_my_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-462` — set 46, `462_family_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-463` — set 46, `463_connections.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-464` — set 46, `464_add_connection.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-465` — set 46, `465_connection_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-466` — set 46, `466_member_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-467` — set 46, `467_family_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family`
- `HUD-VIS-468` — set 46, `468_privacy_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-469` — set 46, `469_account_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family`
- `HUD-VIS-470` — set 46, `470_edit_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/family/*`
- `HUD-VIS-061` — set 7, `61_service_directory.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-062` — set 7, `62_service_provider_profile.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/services/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/connections/**`
- `tests/connections/**`
- `docs/execution/P2-008/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set46.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-008/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-008/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-008. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-008/HANDOFF.md. Stop after the task.
```


---

# P2-009 — Implement in-app notification core

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-009` |
| Phase | Phase 2 |
| Epic | Notifications |
| Priority | P0 |
| Dependency wave | 22 |
| Dependencies | P1-008 |
| Owning module | `src/modules/notifications` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement in-app notification core** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-008**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-009-implement-in-app-notification-core`.

## Required implementation

1. notification/preferences models.
2. Separate notification intent from per-channel delivery attempts.
3. Use idempotent retries and user preferences.
4. Persist before realtime broadcast.

## Related canonical entities

- `Notification` — aggregate_root; sensitivity: CONFIDENTIAL; Semantic intent and deep link.
- `NotificationDelivery` — entity; sensitivity: RESTRICTED; Channel attempt with idempotency.
- `NotificationPreference` — aggregate_root; sensitivity: CONFIDENTIAL; Per event/channel quiet hours.
- `NotificationTemplate` — versioned_reference; sensitivity: INTERNAL; Locale/channel/version.

## Related API contracts

- `GET /api/v1/notifications` — capability `profile.read_self`; request `NotificationQuery`; response `Paginated<NotificationDTO>`; events `-`
- `POST /api/v1/notifications/read` — capability `profile.read_self`; request `MarkNotificationsReadInput`; response `204`; events `notification.read`
- `GET /api/v1/notification-preferences` — capability `notification.preference.manage`; request `-`; response `NotificationPreferenceDTO`; events `-`
- `PUT /api/v1/notification-preferences` — capability `notification.preference.manage`; request `NotificationPreferenceInput`; response `NotificationPreferenceDTO`; events `notification.preferences_updated`

## Related capabilities

- `notification.preference.manage` — Manage own notification preferences

## Related routes

- `/app/notifications` — Notifications / owner `Notifications` / P0

## Visual acceptance references

- `HUD-VIS-441` — set 44, `441_messages_inbox.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-442` — set 44, `442_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-443` — set 44, `443_group_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-444` — set 44, `444_voice_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-445` — set 44, `445_media_sharing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-446` — set 44, `446_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-447` — set 44, `447_mentions_replies.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-448` — set 44, `448_saved_messages.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-449` — set 44, `449_message_search.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-450` — set 44, `450_chat_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-OVR-S58` — set 58, `huddle_set58_notification_email_push_templates_overview.png`, disposition `COMMUNICATION_TEMPLATE_REFERENCE`, route candidate `N/A`
- `HUD-VIS-581` — set 58, `581_welcome_email.png`, disposition `COMMUNICATION_TEMPLATE_REFERENCE`, route candidate `N/A`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/notifications/**`
- `tests/notifications/**`
- `docs/execution/P2-009/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: notification/preferences models.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-009/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-009/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-009. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-009/HANDOFF.md. Stop after the task.
```


---

# P2-010 — Implement user report/block surfaces

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-010` |
| Phase | Phase 2 |
| Epic | Safety |
| Priority | P0 |
| Dependency wave | 26 |
| Dependencies | P2-006, P2-007, P2-008 |
| Owning module | `src/modules/trust-safety` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement user report/block surfaces** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-006, P2-007, P2-008**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-010-implement-user-report-block-surfaces`.

## Required implementation

1. set52.
2. Every report path must support block/report controls, evidence references and anti-abuse handling.
3. Sensitive enforcement mutations require audit logs.
4. Do not expose reporter identity by default.
5. Report and block affordances must exist on applicable listing/community/connection surfaces.

## Related canonical entities

- `SafetyReport` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Reporter identity protected.
- `ModerationCase` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Case access is capability/scoped.
- `EnforcementAction` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Warning, restriction, suspension, removal.
- `Appeal` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Independent reviewer policy.

## Related API contracts

- `POST /api/v1/reports` — capability `safety.report.create`; request `CreateSafetyReportInput`; response `SafetyReportDTO`; events `safety.report_submitted`
- `GET /api/v1/admin/moderation/cases` — capability `safety.case.read`; request `CaseQuery`; response `Paginated<ModerationCaseDTO>`; events `-`
- `GET /api/v1/admin/moderation/cases/{caseId}` — capability `safety.case.read`; request `-`; response `ModerationCaseDTO`; events `-`
- `POST /api/v1/admin/moderation/cases/{caseId}/decisions` — capability `safety.case.decide`; request `ModerationDecisionInput`; response `ModerationCaseDTO`; events `moderation.decision_issued`
- `POST /api/v1/appeals` — capability `safety.report.create`; request `CreateAppealInput`; response `AppealDTO`; events `appeal.submitted`

## Related capabilities

- `safety.report.create` — Create safety report
- `safety.case.read` — Read assigned moderation case
- `safety.case.decide` — Issue moderation decision
- `safety.enforcement.manage` — Manage enforcement action
- `safety.appeal.review` — Review appeal

## Related routes

- `/safety` — Safety / owner `TrustSafety` / P0

## Visual acceptance references

- `HUD-OVR-S56` — set 56, `huddle_set56_admin_trust_safety_operations_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-521` — set 52, `521_mobile_safety_center.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-522` — set 52, `522_report_listing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-523` — set 52, `523_report_user.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-524` — set 52, `524_report_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-525` — set 52, `525_block_mute_user.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-526` — set 52, `526_child_privacy_controls.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-527` — set 52, `527_parent_consent_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-528` — set 52, `528_appeal_decision.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-529` — set 52, `529_suspicious_behavior_warning.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety`
- `HUD-VIS-530` — set 52, `530_safety_support_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-561` — set 56, `561_safety_dashboard.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/trust-safety/**`
- `tests/trust-safety/**`
- `docs/execution/P2-010/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set52.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-010/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-010/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-010. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-010/HANDOFF.md. Stop after the task.
```


---

# P2-011 — Implement moderation case workflow

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-011` |
| Phase | Phase 2 |
| Epic | Admin Safety |
| Priority | P0 |
| Dependency wave | 27 |
| Dependencies | P2-010, P1-002 |
| Owning module | `src/modules/trust-safety` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement moderation case workflow** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-010, P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-011-implement-moderation-case-workflow`.

## Required implementation

1. set56.
2. Use set56 as canonical operations UI.
3. Case decisions and enforcement are explicit state transitions with audit.
4. Appeal path cannot mutate original evidence.
5. ModerationCase, EnforcementAction and Appeal boundaries must be explicit and audited.

## Related canonical entities

- `SafetyReport` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Reporter identity protected.
- `ModerationCase` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Case access is capability/scoped.
- `EnforcementAction` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Warning, restriction, suspension, removal.
- `Appeal` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Independent reviewer policy.

## Related API contracts

- `POST /api/v1/reports` — capability `safety.report.create`; request `CreateSafetyReportInput`; response `SafetyReportDTO`; events `safety.report_submitted`
- `GET /api/v1/admin/moderation/cases` — capability `safety.case.read`; request `CaseQuery`; response `Paginated<ModerationCaseDTO>`; events `-`
- `GET /api/v1/admin/moderation/cases/{caseId}` — capability `safety.case.read`; request `-`; response `ModerationCaseDTO`; events `-`
- `POST /api/v1/admin/moderation/cases/{caseId}/decisions` — capability `safety.case.decide`; request `ModerationDecisionInput`; response `ModerationCaseDTO`; events `moderation.decision_issued`
- `POST /api/v1/appeals` — capability `safety.report.create`; request `CreateAppealInput`; response `AppealDTO`; events `appeal.submitted`
- `GET /api/v1/admin/users` — capability `admin.user.manage`; request `AdminUserQuery`; response `Paginated<AdminUserDTO>`; events `-`
- `PATCH /api/v1/admin/users/{userId}/status` — capability `admin.user.manage`; request `UpdateUserStatusInput`; response `AdminUserDTO`; events `admin.user_status_changed`
- `POST /api/v1/admin/users/{userId}/grants` — capability `admin.role.grant`; request `CreateScopedGrantInput`; response `ScopedGrantDTO`; events `admin.grant_created`
- `GET /api/v1/admin/audit-log` — capability `admin.audit.read`; request `AuditLogQuery`; response `Paginated<AuditLogDTO>`; events `-`

## Related capabilities

- `safety.report.create` — Create safety report
- `safety.case.read` — Read assigned moderation case
- `safety.case.decide` — Issue moderation decision
- `safety.enforcement.manage` — Manage enforcement action
- `safety.appeal.review` — Review appeal

## Related routes

- `/safety` — Safety / owner `TrustSafety` / P0

## Visual acceptance references

- `HUD-OVR-S56` — set 56, `huddle_set56_admin_trust_safety_operations_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-561` — set 56, `561_safety_dashboard.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-562` — set 56, `562_reported_listing_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-563` — set 56, `563_reported_user_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/moderation`
- `HUD-VIS-564` — set 56, `564_reported_message_thread.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-565` — set 56, `565_child_safety_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-566` — set 56, `566_suspicious_behavior_queue.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/moderation`
- `HUD-VIS-567` — set 56, `567_moderator_decision_panel.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/moderation`
- `HUD-VIS-568` — set 56, `568_appeal_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-569` — set 56, `569_enforcement_history.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/moderation`
- `HUD-VIS-570` — set 56, `570_safety_audit_log.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/safety/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/trust-safety/**`
- `tests/trust-safety/**`
- `docs/execution/P2-011/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set56.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-011/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-011/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-011. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-011/HANDOFF.md. Stop after the task.
```


---

# P2-012 — Enforce privileged mutation audit coverage

## Metadata

| Field | Value |
|---|---|
| Task ID | `P2-012` |
| Phase | Phase 2 |
| Epic | Audit |
| Priority | P0 |
| Dependency wave | 28 |
| Dependencies | P2-011 |
| Owning module | `src/modules/audit` |
| Risk | HIGH |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Enforce privileged mutation audit coverage** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-011**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p2-012-enforce-privileged-mutation-audit-coverage`.

## Required implementation

1. audit coverage gate.
2. Privileged/security-sensitive mutations must write append-only audit records.
3. Never put message content, secrets or unnecessary sensitive free text in logs.
4. Add coverage tests that fail when audited endpoints omit audit behavior.
5. Create a coverage test/gate that enumerates privileged mutations and fails when required audit behavior is absent.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.

## Related API contracts

- `GET /api/v1/admin/users` — capability `admin.user.manage`; request `AdminUserQuery`; response `Paginated<AdminUserDTO>`; events `-`
- `PATCH /api/v1/admin/users/{userId}/status` — capability `admin.user.manage`; request `UpdateUserStatusInput`; response `AdminUserDTO`; events `admin.user_status_changed`
- `POST /api/v1/admin/users/{userId}/grants` — capability `admin.role.grant`; request `CreateScopedGrantInput`; response `ScopedGrantDTO`; events `admin.grant_created`
- `GET /api/v1/admin/audit-log` — capability `admin.audit.read`; request `AuditLogQuery`; response `Paginated<AuditLogDTO>`; events `-`

## Related capabilities

- `group.manage` — Manage group where owner/admin
- `experience.admin` — Administer any experience
- `admin.user.manage` — Manage user status/roles
- `admin.role.grant` — Grant coarse role/scoped capability
- `admin.audit.read` — Read audit log

## Related routes

- `/admin` — Admin dashboard / owner `Admin` / P0

## Visual acceptance references

- `HUD-VIS-251` — set 25, `251_admin_dashboard.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-252` — set 25, `252_user_management.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-253` — set 25, `253_user_detail.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-254` — set 25, `254_family_account_review.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-255` — set 25, `255_listing_moderation_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-256` — set 25, `256_product_listing_moderation_detail.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-257` — set 25, `257_organizer_verification_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-258` — set 25, `258_partner_store_approval.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-259` — set 25, `259_expert_verification_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-260` — set 25, `260_reports_safety_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/safety/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/audit/**`
- `tests/audit/**`
- `docs/execution/P2-012/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: audit coverage gate.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P2-012/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P2-012/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P2-012. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P2-012/HANDOFF.md. Stop after the task.
```


---

# P3-001 — Implement Conversation/Participant core

## Metadata

| Field | Value |
|---|---|
| Task ID | `P3-001` |
| Phase | Phase 3 |
| Epic | Messaging |
| Priority | P0 |
| Dependency wave | 24 |
| Dependencies | P2-008, P1-002 |
| Owning module | `src/modules/messaging` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement Conversation/Participant core** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-008, P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p3-001-implement-conversation-participant-core`.

## Required implementation

1. shared context-aware conversations.
2. Use one Conversation/Participant/Message core with context policy.
3. Persist before broadcast and deduplicate by event/message id.
4. Enforce membership, block and context checks on every send/read path.

## Related canonical entities

- `Conversation` — aggregate_root; sensitivity: RESTRICTED; ContextType DIRECT|GROUP|LISTING|BOOKING|EVENT|SUPPORT.
- `ConversationParticipant` — association; sensitivity: RESTRICTED; lastReadMessageId, notification state.
- `Message` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Text encrypted at rest by platform storage; excluded from analytics.
- `MessageMention` — association; sensitivity: RESTRICTED; Mention permission and notification.
- `MessageReceipt` — entity; sensitivity: RESTRICTED; Optional; avoid unnecessary retention.

## Related API contracts

- `GET /api/v1/conversations` — capability `message.send`; request `ConversationQuery`; response `Paginated<ConversationSummaryDTO>`; events `-`
- `POST /api/v1/conversations` — capability `message.send`; request `CreateConversationInput`; response `ConversationDTO`; events `conversation.created`
- `GET /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `MessageQuery`; response `Paginated<MessageDTO>`; events `-`
- `POST /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `CreateMessageInput`; response `MessageDTO`; events `message.created`
- `PATCH /api/v1/messages/{messageId}` — capability `message.send`; request `EditMessageInput`; response `MessageDTO`; events `message.updated`
- `DELETE /api/v1/messages/{messageId}` — capability `message.send`; request `-`; response `204`; events `message.deleted`
- `POST /api/v1/conversations/{conversationId}/read` — capability `message.send`; request `MarkReadInput`; response `204`; events `conversation.read_updated`
- `GET /api/v1/messages/search` — capability `message.send`; request `MessageSearchQuery`; response `Paginated<MessageSearchResultDTO>`; events `-`

## Related capabilities

- `message.send` — Send message in authorized conversation
- `message.moderate` — Review reported message content

## Related routes

- `/app/messages` — Messaging inbox / owner `Messaging` / P0

## Visual acceptance references

- `HUD-VIS-441` — set 44, `441_messages_inbox.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-442` — set 44, `442_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-443` — set 44, `443_group_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-444` — set 44, `444_voice_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-445` — set 44, `445_media_sharing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-446` — set 44, `446_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-447` — set 44, `447_mentions_replies.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-448` — set 44, `448_saved_messages.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-449` — set 44, `449_message_search.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-450` — set 44, `450_chat_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-051` — set 6, `51_messages_conversations.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-052` — set 6, `52_message_thread.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/messages/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/messaging/**`
- `tests/messaging/**`
- `docs/execution/P3-001/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: shared context-aware conversations.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P3-001/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P3-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P3-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P3-001/HANDOFF.md. Stop after the task.
```


---

# P3-002 — Implement message send/read/pagination

## Metadata

| Field | Value |
|---|---|
| Task ID | `P3-002` |
| Phase | Phase 3 |
| Epic | Messaging |
| Priority | P0 |
| Dependency wave | 25 |
| Dependencies | P3-001 |
| Owning module | `src/modules/messaging` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement message send/read/pagination** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P3-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p3-002-implement-message-send-read-pagination`.

## Required implementation

1. set44 inbox/chat.
2. Use one Conversation/Participant/Message core with context policy.
3. Persist before broadcast and deduplicate by event/message id.
4. Enforce membership, block and context checks on every send/read path.

## Related canonical entities

- `Conversation` — aggregate_root; sensitivity: RESTRICTED; ContextType DIRECT|GROUP|LISTING|BOOKING|EVENT|SUPPORT.
- `ConversationParticipant` — association; sensitivity: RESTRICTED; lastReadMessageId, notification state.
- `Message` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Text encrypted at rest by platform storage; excluded from analytics.
- `MessageMention` — association; sensitivity: RESTRICTED; Mention permission and notification.
- `MessageReceipt` — entity; sensitivity: RESTRICTED; Optional; avoid unnecessary retention.

## Related API contracts

- `GET /api/v1/conversations` — capability `message.send`; request `ConversationQuery`; response `Paginated<ConversationSummaryDTO>`; events `-`
- `POST /api/v1/conversations` — capability `message.send`; request `CreateConversationInput`; response `ConversationDTO`; events `conversation.created`
- `GET /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `MessageQuery`; response `Paginated<MessageDTO>`; events `-`
- `POST /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `CreateMessageInput`; response `MessageDTO`; events `message.created`
- `PATCH /api/v1/messages/{messageId}` — capability `message.send`; request `EditMessageInput`; response `MessageDTO`; events `message.updated`
- `DELETE /api/v1/messages/{messageId}` — capability `message.send`; request `-`; response `204`; events `message.deleted`
- `POST /api/v1/conversations/{conversationId}/read` — capability `message.send`; request `MarkReadInput`; response `204`; events `conversation.read_updated`
- `GET /api/v1/messages/search` — capability `message.send`; request `MessageSearchQuery`; response `Paginated<MessageSearchResultDTO>`; events `-`

## Related capabilities

- `message.send` — Send message in authorized conversation
- `message.moderate` — Review reported message content

## Related routes

- `/app/messages` — Messaging inbox / owner `Messaging` / P0

## Visual acceptance references

- `HUD-VIS-441` — set 44, `441_messages_inbox.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-442` — set 44, `442_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-443` — set 44, `443_group_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-444` — set 44, `444_voice_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-445` — set 44, `445_media_sharing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-446` — set 44, `446_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-447` — set 44, `447_mentions_replies.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-448` — set 44, `448_saved_messages.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-449` — set 44, `449_message_search.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-450` — set 44, `450_chat_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-051` — set 6, `51_messages_conversations.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-052` — set 6, `52_message_thread.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/messages/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/messaging/**`
- `tests/messaging/**`
- `docs/execution/P3-002/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set44 inbox/chat.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P3-002/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P3-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P3-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P3-002/HANDOFF.md. Stop after the task.
```


---

# P3-003 — Implement RealtimeGateway adapter

## Metadata

| Field | Value |
|---|---|
| Task ID | `P3-003` |
| Phase | Phase 3 |
| Epic | Realtime |
| Priority | P0 |
| Dependency wave | 26 |
| Dependencies | P3-002 |
| Owning module | `src/modules/realtime` |
| Risk | MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement RealtimeGateway adapter** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P3-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p3-003-implement-realtimegateway-adapter`.

## Required implementation

1. persist-then-broadcast.
2. Keep provider behind RealtimeGateway.
3. Implement reconnect, deduplication and gap recovery.
4. Realtime is a projection of persisted state, never the source of truth.
5. Use transactional outbox/domain events as the source for realtime publication where cross-process delivery is required.

## Related canonical entities

- `Conversation` — aggregate_root; sensitivity: RESTRICTED; ContextType DIRECT|GROUP|LISTING|BOOKING|EVENT|SUPPORT.
- `ConversationParticipant` — association; sensitivity: RESTRICTED; lastReadMessageId, notification state.
- `Message` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Text encrypted at rest by platform storage; excluded from analytics.
- `MessageMention` — association; sensitivity: RESTRICTED; Mention permission and notification.
- `MessageReceipt` — entity; sensitivity: RESTRICTED; Optional; avoid unnecessary retention.
- `Notification` — aggregate_root; sensitivity: CONFIDENTIAL; Semantic intent and deep link.
- `NotificationDelivery` — entity; sensitivity: RESTRICTED; Channel attempt with idempotency.
- `NotificationPreference` — aggregate_root; sensitivity: CONFIDENTIAL; Per event/channel quiet hours.
- `NotificationTemplate` — versioned_reference; sensitivity: INTERNAL; Locale/channel/version.

## Related API contracts

- `GET /api/v1/conversations` — capability `message.send`; request `ConversationQuery`; response `Paginated<ConversationSummaryDTO>`; events `-`
- `POST /api/v1/conversations` — capability `message.send`; request `CreateConversationInput`; response `ConversationDTO`; events `conversation.created`
- `GET /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `MessageQuery`; response `Paginated<MessageDTO>`; events `-`
- `POST /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `CreateMessageInput`; response `MessageDTO`; events `message.created`
- `PATCH /api/v1/messages/{messageId}` — capability `message.send`; request `EditMessageInput`; response `MessageDTO`; events `message.updated`
- `DELETE /api/v1/messages/{messageId}` — capability `message.send`; request `-`; response `204`; events `message.deleted`
- `POST /api/v1/conversations/{conversationId}/read` — capability `message.send`; request `MarkReadInput`; response `204`; events `conversation.read_updated`
- `GET /api/v1/messages/search` — capability `message.send`; request `MessageSearchQuery`; response `Paginated<MessageSearchResultDTO>`; events `-`

## Related capabilities

- `message.send` — Send message in authorized conversation
- `message.moderate` — Review reported message content
- `notification.preference.manage` — Manage own notification preferences

## Related routes

- `/app/messages` — Messaging inbox / owner `Messaging` / P0

## Visual acceptance references

- `HUD-VIS-441` — set 44, `441_messages_inbox.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-442` — set 44, `442_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-443` — set 44, `443_group_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-444` — set 44, `444_voice_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-445` — set 44, `445_media_sharing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-446` — set 44, `446_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-447` — set 44, `447_mentions_replies.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-448` — set 44, `448_saved_messages.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-449` — set 44, `449_message_search.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-450` — set 44, `450_chat_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/realtime/**`
- `tests/realtime/**`
- `docs/execution/P3-003/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: persist-then-broadcast.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P3-003/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P3-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P3-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P3-003/HANDOFF.md. Stop after the task.
```


---

# P3-004 — Implement attachments/mentions/search/settings

## Metadata

| Field | Value |
|---|---|
| Task ID | `P3-004` |
| Phase | Phase 3 |
| Epic | Messaging |
| Priority | P1 |
| Dependency wave | 27 |
| Dependencies | P3-003, P1-010 |
| Owning module | `src/modules/messaging` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement attachments/mentions/search/settings** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P3-003, P1-010**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p3-004-implement-attachments-mentions-search-settings`.

## Required implementation

1. set44 extended.
2. Use one Conversation/Participant/Message core with context policy.
3. Persist before broadcast and deduplicate by event/message id.
4. Enforce membership, block and context checks on every send/read path.

## Related canonical entities

- `Conversation` — aggregate_root; sensitivity: RESTRICTED; ContextType DIRECT|GROUP|LISTING|BOOKING|EVENT|SUPPORT.
- `ConversationParticipant` — association; sensitivity: RESTRICTED; lastReadMessageId, notification state.
- `Message` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Text encrypted at rest by platform storage; excluded from analytics.
- `MessageMention` — association; sensitivity: RESTRICTED; Mention permission and notification.
- `MessageReceipt` — entity; sensitivity: RESTRICTED; Optional; avoid unnecessary retention.

## Related API contracts

- `GET /api/v1/conversations` — capability `message.send`; request `ConversationQuery`; response `Paginated<ConversationSummaryDTO>`; events `-`
- `POST /api/v1/conversations` — capability `message.send`; request `CreateConversationInput`; response `ConversationDTO`; events `conversation.created`
- `GET /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `MessageQuery`; response `Paginated<MessageDTO>`; events `-`
- `POST /api/v1/conversations/{conversationId}/messages` — capability `message.send`; request `CreateMessageInput`; response `MessageDTO`; events `message.created`
- `PATCH /api/v1/messages/{messageId}` — capability `message.send`; request `EditMessageInput`; response `MessageDTO`; events `message.updated`
- `DELETE /api/v1/messages/{messageId}` — capability `message.send`; request `-`; response `204`; events `message.deleted`
- `POST /api/v1/conversations/{conversationId}/read` — capability `message.send`; request `MarkReadInput`; response `204`; events `conversation.read_updated`
- `GET /api/v1/messages/search` — capability `message.send`; request `MessageSearchQuery`; response `Paginated<MessageSearchResultDTO>`; events `-`

## Related capabilities

- `message.send` — Send message in authorized conversation
- `message.moderate` — Review reported message content

## Related routes

- `/app/messages` — Messaging inbox / owner `Messaging` / P0

## Visual acceptance references

- `HUD-VIS-441` — set 44, `441_messages_inbox.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-442` — set 44, `442_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-443` — set 44, `443_group_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-444` — set 44, `444_voice_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-445` — set 44, `445_media_sharing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-446` — set 44, `446_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-447` — set 44, `447_mentions_replies.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-448` — set 44, `448_saved_messages.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-449` — set 44, `449_message_search.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-450` — set 44, `450_chat_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-051` — set 6, `51_messages_conversations.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-052` — set 6, `52_message_thread.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/messages/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/messaging/**`
- `tests/messaging/**`
- `docs/execution/P3-004/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set44 extended.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P3-004/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P3-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P3-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P3-004/HANDOFF.md. Stop after the task.
```


---

# P3-005 — Implement delivery pipeline and preferences

## Metadata

| Field | Value |
|---|---|
| Task ID | `P3-005` |
| Phase | Phase 3 |
| Epic | Notifications |
| Priority | P0 |
| Dependency wave | 23 |
| Dependencies | P2-009 |
| Owning module | `src/modules/notifications` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement delivery pipeline and preferences** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-009**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p3-005-implement-delivery-pipeline-and-preferences`.

## Required implementation

1. outbox, retries, channel adapters.
2. Separate notification intent from per-channel delivery attempts.
3. Use idempotent retries and user preferences.
4. Persist before realtime broadcast.

## Related canonical entities

- `Notification` — aggregate_root; sensitivity: CONFIDENTIAL; Semantic intent and deep link.
- `NotificationDelivery` — entity; sensitivity: RESTRICTED; Channel attempt with idempotency.
- `NotificationPreference` — aggregate_root; sensitivity: CONFIDENTIAL; Per event/channel quiet hours.
- `NotificationTemplate` — versioned_reference; sensitivity: INTERNAL; Locale/channel/version.

## Related API contracts

- `GET /api/v1/notifications` — capability `profile.read_self`; request `NotificationQuery`; response `Paginated<NotificationDTO>`; events `-`
- `POST /api/v1/notifications/read` — capability `profile.read_self`; request `MarkNotificationsReadInput`; response `204`; events `notification.read`
- `GET /api/v1/notification-preferences` — capability `notification.preference.manage`; request `-`; response `NotificationPreferenceDTO`; events `-`
- `PUT /api/v1/notification-preferences` — capability `notification.preference.manage`; request `NotificationPreferenceInput`; response `NotificationPreferenceDTO`; events `notification.preferences_updated`

## Related capabilities

- `notification.preference.manage` — Manage own notification preferences

## Related routes

- `/app/notifications` — Notifications / owner `Notifications` / P0

## Visual acceptance references

- `HUD-VIS-441` — set 44, `441_messages_inbox.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-442` — set 44, `442_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-443` — set 44, `443_group_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-444` — set 44, `444_voice_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-445` — set 44, `445_media_sharing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-446` — set 44, `446_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-447` — set 44, `447_mentions_replies.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-448` — set 44, `448_saved_messages.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-449` — set 44, `449_message_search.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-450` — set 44, `450_chat_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-OVR-S58` — set 58, `huddle_set58_notification_email_push_templates_overview.png`, disposition `COMMUNICATION_TEMPLATE_REFERENCE`, route candidate `N/A`
- `HUD-VIS-581` — set 58, `581_welcome_email.png`, disposition `COMMUNICATION_TEMPLATE_REFERENCE`, route candidate `N/A`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/notifications/**`
- `tests/notifications/**`
- `docs/execution/P3-005/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: outbox, retries, channel adapters.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P3-005/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P3-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P3-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P3-005/HANDOFF.md. Stop after the task.
```


---

# P3-006 — Implement email/push template registry

## Metadata

| Field | Value |
|---|---|
| Task ID | `P3-006` |
| Phase | Phase 3 |
| Epic | Notifications |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P3-005 |
| Owning module | `src/modules/notifications` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement email/push template registry** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P3-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p3-006-implement-email-push-template-registry`.

## Required implementation

1. set58 versioned templates.
2. Separate notification intent from per-channel delivery attempts.
3. Use idempotent retries and user preferences.
4. Persist before realtime broadcast.

## Related canonical entities

- `Notification` — aggregate_root; sensitivity: CONFIDENTIAL; Semantic intent and deep link.
- `NotificationDelivery` — entity; sensitivity: RESTRICTED; Channel attempt with idempotency.
- `NotificationPreference` — aggregate_root; sensitivity: CONFIDENTIAL; Per event/channel quiet hours.
- `NotificationTemplate` — versioned_reference; sensitivity: INTERNAL; Locale/channel/version.

## Related API contracts

- `GET /api/v1/notifications` — capability `profile.read_self`; request `NotificationQuery`; response `Paginated<NotificationDTO>`; events `-`
- `POST /api/v1/notifications/read` — capability `profile.read_self`; request `MarkNotificationsReadInput`; response `204`; events `notification.read`
- `GET /api/v1/notification-preferences` — capability `notification.preference.manage`; request `-`; response `NotificationPreferenceDTO`; events `-`
- `PUT /api/v1/notification-preferences` — capability `notification.preference.manage`; request `NotificationPreferenceInput`; response `NotificationPreferenceDTO`; events `notification.preferences_updated`

## Related capabilities

- `notification.preference.manage` — Manage own notification preferences

## Related routes

- `/app/notifications` — Notifications / owner `Notifications` / P0

## Visual acceptance references

- `HUD-VIS-441` — set 44, `441_messages_inbox.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-442` — set 44, `442_chat_conversation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-443` — set 44, `443_group_chat.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages/*`
- `HUD-VIS-444` — set 44, `444_voice_message.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-445` — set 44, `445_media_sharing.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-446` — set 44, `446_notifications.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/notifications`
- `HUD-VIS-447` — set 44, `447_mentions_replies.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-448` — set 44, `448_saved_messages.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-449` — set 44, `449_message_search.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-VIS-450` — set 44, `450_chat_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/messages`
- `HUD-OVR-S58` — set 58, `huddle_set58_notification_email_push_templates_overview.png`, disposition `COMMUNICATION_TEMPLATE_REFERENCE`, route candidate `N/A`
- `HUD-VIS-581` — set 58, `581_welcome_email.png`, disposition `COMMUNICATION_TEMPLATE_REFERENCE`, route candidate `N/A`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/notifications/**`
- `tests/notifications/**`
- `docs/execution/P3-006/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set58 versioned templates.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P3-006/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P3-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P3-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P3-006/HANDOFF.md. Stop after the task.
```


---

# P4-001 — Implement Group/Membership model

## Metadata

| Field | Value |
|---|---|
| Task ID | `P4-001` |
| Phase | Phase 4 |
| Epic | Groups |
| Priority | P1 |
| Dependency wave | 23 |
| Dependencies | P2-007 |
| Owning module | `src/modules/groups` |
| Risk | MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement Group/Membership model** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-007**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p4-001-implement-group-membership-model`.

## Required implementation

1. set53.
2. Model membership and role within group scope.
3. Enforce private group visibility and membership checks.
4. Reuse community content primitives where appropriate.

## Related canonical entities

- `Group` — aggregate_root; sensitivity: CONFIDENTIAL; Visibility PUBLIC|PRIVATE|SECRET.
- `GroupMembership` — association; sensitivity: CONFIDENTIAL; Group-level roles OWNER|ADMIN|MODERATOR|MEMBER.
- `Post` — aggregate_root; sensitivity: CONFIDENTIAL; Author/context visibility enforced server-side.
- `Comment` — entity; sensitivity: CONFIDENTIAL; Thread parent optional.
- `Reaction` — association; sensitivity: CONFIDENTIAL; Unique actor+target+type.
- `Poll` — entity; sensitivity: CONFIDENTIAL; Vote privacy explicit.

## Related API contracts

- `GET /api/v1/groups` — capability `public.read`; request `GroupQuery`; response `Paginated<GroupCardDTO>`; events `groups.viewed`
- `POST /api/v1/groups` — capability `group.create`; request `CreateGroupInput`; response `GroupDTO`; events `group.created`
- `GET /api/v1/groups/{groupId}` — capability `public.read`; request `-`; response `GroupDTO`; events `group.viewed`
- `PATCH /api/v1/groups/{groupId}` — capability `group.manage`; request `UpdateGroupInput`; response `GroupDTO`; events `group.updated`
- `POST /api/v1/groups/{groupId}/join` — capability `public.read`; request `JoinGroupInput`; response `GroupMembershipDTO`; events `group.joined`
- `POST /api/v1/groups/{groupId}/leave` — capability `public.read`; request `-`; response `204`; events `group.left`

## Related capabilities

- `group.create` — Create group
- `group.manage` — Manage group where owner/admin

## Related routes

- `/app/groups` — Groups directory / owner `Groups` / P1

## Visual acceptance references

- `HUD-VIS-531` — set 53, `531_groups_directory.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-532` — set 53, `532_group_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-533` — set 53, `533_create_group.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups`
- `HUD-VIS-534` — set 53, `534_group_feed.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-535` — set 53, `535_group_members.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-536` — set 53, `536_group_events.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-537` — set 53, `537_event_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-538` — set 53, `538_group_files.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-539` — set 53, `539_group_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-540` — set 53, `540_leave_delete_group.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups`
- `HUD-VIS-451` — set 45, `451_community_home.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/community`
- `HUD-VIS-452` — set 45, `452_groups_directory.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/groups/**`
- `tests/groups/**`
- `docs/execution/P4-001/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set53.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P4-001/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P4-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P4-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P4-001/HANDOFF.md. Stop after the task.
```


---

# P4-002 — Implement group feed/members/files/settings

## Metadata

| Field | Value |
|---|---|
| Task ID | `P4-002` |
| Phase | Phase 4 |
| Epic | Groups |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P4-001, P1-010 |
| Owning module | `src/modules/groups` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement group feed/members/files/settings** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P4-001, P1-010**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p4-002-implement-group-feed-members-files-settings`.

## Required implementation

1. set53 full flow.
2. Model membership and role within group scope.
3. Enforce private group visibility and membership checks.
4. Reuse community content primitives where appropriate.

## Related canonical entities

- `Group` — aggregate_root; sensitivity: CONFIDENTIAL; Visibility PUBLIC|PRIVATE|SECRET.
- `GroupMembership` — association; sensitivity: CONFIDENTIAL; Group-level roles OWNER|ADMIN|MODERATOR|MEMBER.
- `Post` — aggregate_root; sensitivity: CONFIDENTIAL; Author/context visibility enforced server-side.
- `Comment` — entity; sensitivity: CONFIDENTIAL; Thread parent optional.
- `Reaction` — association; sensitivity: CONFIDENTIAL; Unique actor+target+type.
- `Poll` — entity; sensitivity: CONFIDENTIAL; Vote privacy explicit.

## Related API contracts

- `GET /api/v1/groups` — capability `public.read`; request `GroupQuery`; response `Paginated<GroupCardDTO>`; events `groups.viewed`
- `POST /api/v1/groups` — capability `group.create`; request `CreateGroupInput`; response `GroupDTO`; events `group.created`
- `GET /api/v1/groups/{groupId}` — capability `public.read`; request `-`; response `GroupDTO`; events `group.viewed`
- `PATCH /api/v1/groups/{groupId}` — capability `group.manage`; request `UpdateGroupInput`; response `GroupDTO`; events `group.updated`
- `POST /api/v1/groups/{groupId}/join` — capability `public.read`; request `JoinGroupInput`; response `GroupMembershipDTO`; events `group.joined`
- `POST /api/v1/groups/{groupId}/leave` — capability `public.read`; request `-`; response `204`; events `group.left`

## Related capabilities

- `group.create` — Create group
- `group.manage` — Manage group where owner/admin

## Related routes

- `/app/groups` — Groups directory / owner `Groups` / P1

## Visual acceptance references

- `HUD-VIS-531` — set 53, `531_groups_directory.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-532` — set 53, `532_group_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-533` — set 53, `533_create_group.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups`
- `HUD-VIS-534` — set 53, `534_group_feed.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-535` — set 53, `535_group_members.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-536` — set 53, `536_group_events.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-537` — set 53, `537_event_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-538` — set 53, `538_group_files.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-539` — set 53, `539_group_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-540` — set 53, `540_leave_delete_group.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/groups`
- `HUD-VIS-451` — set 45, `451_community_home.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/community`
- `HUD-VIS-452` — set 45, `452_groups_directory.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/groups/**`
- `tests/groups/**`
- `docs/execution/P4-002/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set53 full flow.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P4-002/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P4-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P4-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P4-002/HANDOFF.md. Stop after the task.
```


---

# P4-003 — Implement richer post/media lifecycle

## Metadata

| Field | Value |
|---|---|
| Task ID | `P4-003` |
| Phase | Phase 4 |
| Epic | Content |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P2-007, P1-010 |
| Owning module | `src/modules/content` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement richer post/media lifecycle** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-007, P1-010**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p4-003-implement-richer-post-media-lifecycle`.

## Required implementation

1. set48.
2. Use explicit media lifecycle and moderation states.
3. Avoid duplicating the community interaction model.
4. Apply safe serialization for author/family data.

## Related canonical entities

- `Group` — aggregate_root; sensitivity: CONFIDENTIAL; Visibility PUBLIC|PRIVATE|SECRET.
- `GroupMembership` — association; sensitivity: CONFIDENTIAL; Group-level roles OWNER|ADMIN|MODERATOR|MEMBER.
- `Post` — aggregate_root; sensitivity: CONFIDENTIAL; Author/context visibility enforced server-side.
- `Comment` — entity; sensitivity: CONFIDENTIAL; Thread parent optional.
- `Reaction` — association; sensitivity: CONFIDENTIAL; Unique actor+target+type.
- `Poll` — entity; sensitivity: CONFIDENTIAL; Vote privacy explicit.

## Related API contracts

- `GET /api/v1/feed` — capability `public.read`; request `FeedQuery`; response `Paginated<FeedItemDTO>`; events `feed.viewed`
- `POST /api/v1/posts` — capability `community.post.create`; request `CreatePostInput`; response `PostDTO`; events `post.created`
- `PATCH /api/v1/posts/{postId}` — capability `community.post.create`; request `UpdatePostInput`; response `PostDTO`; events `post.updated`
- `DELETE /api/v1/posts/{postId}` — capability `community.post.create`; request `-`; response `204`; events `post.deleted`
- `POST /api/v1/posts/{postId}/comments` — capability `community.post.create`; request `CreateCommentInput`; response `CommentDTO`; events `comment.created`
- `POST /api/v1/reactions` — capability `community.post.create`; request `ReactionInput`; response `ReactionDTO`; events `reaction.changed`

## Related capabilities

- `community.post.create` — Create community post
- `community.post.moderate` — Moderate community content

## Related routes

- `/app/community` — Community home / owner `Community` / P0

## Visual acceptance references

- `HUD-VIS-191` — set 20, `191_create_group_post_start.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-192` — set 20, `192_create_group_post_content.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-193` — set 20, `193_create_group_post_media.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-194` — set 20, `194_create_group_post_review_publish.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-195` — set 20, `195_post_published_success.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups`
- `HUD-VIS-196` — set 20, `196_group_posts_list.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-197` — set 20, `197_post_details_comments.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups`
- `HUD-VIS-198` — set 20, `198_edit_group_post.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-199` — set 20, `199_pin_post_options.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups`
- `HUD-VIS-200` — set 20, `200_group_post_analytics.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/groups/*`
- `HUD-VIS-481` — set 48, `481_feed_home.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/content`
- `HUD-VIS-482` — set 48, `482_create_post.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/content`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/content/**`
- `tests/content/**`
- `docs/execution/P4-003/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set48.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P4-003/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P4-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P4-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P4-003/HANDOFF.md. Stop after the task.
```


---

# P4-004 — Implement opt-in preferences

## Metadata

| Field | Value |
|---|---|
| Task ID | `P4-004` |
| Phase | Phase 4 |
| Epic | Matching |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P1-006, P2-008 |
| Owning module | `src/modules/matching` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement opt-in preferences** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-006, P2-008**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p4-004-implement-opt-in-preferences`.

## Required implementation

1. privacy-safe match inputs.
2. Opt-in only; coarse location; no exact child birthdate or address in discovery.
3. Apply block/safety exclusion before scoring.
4. Explanations must not leak hidden attributes.

## Related canonical entities

- `FamilyProfile` — aggregate_root; sensitivity: RESTRICTED; Parent-owned family unit.
- `FamilyMember` — entity; sensitivity: HIGHLY_RESTRICTED; Child/member data minimized; age stage preferred over birthdate in discovery.
- `Interest` — reference; sensitivity: PUBLIC; Controlled taxonomy.
- `FamilyInterest` — association; sensitivity: CONFIDENTIAL; Matching/discovery preference input.
- `FamilyVisibilityRule` — entity; sensitivity: RESTRICTED; Field-level audience policy.
- `MatchPreference` — aggregate_root; sensitivity: RESTRICTED; Explicit opt-in; coarse geography.
- `MatchCandidateSnapshot` — derived; sensitivity: RESTRICTED; Derived score explanation; no sensitive raw feature dump.
- `ConnectionRequest` — aggregate_root; sensitivity: CONFIDENTIAL; Rate-limited and reportable.
- `Connection` — aggregate_root; sensitivity: CONFIDENTIAL; Mutual relationship; messaging eligibility policy.
- `BlockRelation` — entity; sensitivity: RESTRICTED; Always checked by search/matching/messaging.

## Related API contracts

- `GET /api/v1/matching/preferences` — capability `matching.manage_preferences`; request `-`; response `MatchPreferenceDTO`; events `-`
- `PUT /api/v1/matching/preferences` — capability `matching.manage_preferences`; request `MatchPreferenceInput`; response `MatchPreferenceDTO`; events `matching.preferences_updated`
- `GET /api/v1/matching/candidates` — capability `matching.view_candidates`; request `MatchCandidateQuery`; response `Paginated<MatchCandidateDTO>`; events `matching.candidates_viewed`

## Related capabilities

- `matching.manage_preferences` — Manage own matching preferences
- `matching.view_candidates` — View privacy-filtered candidates

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- `HUD-VIS-011` — set 2, `11_parent_account_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-012` — set 2, `12_saved_items_activities_events.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-013` — set 2, `13_my_listings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-014` — set 2, `14_create_listing_step_1_category_age.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-015` — set 2, `15_create_listing_step_2_photos_price.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-016` — set 2, `16_messages_buyer_seller_chat.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-017` — set 2, `17_family_matching_preferences.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-018` — set 2, `18_family_match_results.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-019` — set 2, `19_family_match_detail_connect_request.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-020` — set 2, `20_connection_request_chat.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/matching/**`
- `tests/matching/**`
- `docs/execution/P4-004/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: privacy-safe match inputs.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P4-004/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P4-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P4-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P4-004/HANDOFF.md. Stop after the task.
```


---

# P4-005 — Implement candidate computation and explanation

## Metadata

| Field | Value |
|---|---|
| Task ID | `P4-005` |
| Phase | Phase 4 |
| Epic | Matching |
| Priority | P1 |
| Dependency wave | 25 |
| Dependencies | P4-004 |
| Owning module | `src/modules/matching` |
| Risk | MEDIUM_HIGH |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement candidate computation and explanation** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P4-004**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p4-005-implement-candidate-computation-and-explanation`.

## Required implementation

1. coarse geo, no child sensitive leakage.
2. Opt-in only; coarse location; no exact child birthdate or address in discovery.
3. Apply block/safety exclusion before scoring.
4. Explanations must not leak hidden attributes.
5. Candidate explanation must be generated from allowed coarse features only and must not reveal hidden match inputs.

## Related canonical entities

- `FamilyProfile` — aggregate_root; sensitivity: RESTRICTED; Parent-owned family unit.
- `FamilyMember` — entity; sensitivity: HIGHLY_RESTRICTED; Child/member data minimized; age stage preferred over birthdate in discovery.
- `Interest` — reference; sensitivity: PUBLIC; Controlled taxonomy.
- `FamilyInterest` — association; sensitivity: CONFIDENTIAL; Matching/discovery preference input.
- `FamilyVisibilityRule` — entity; sensitivity: RESTRICTED; Field-level audience policy.
- `MatchPreference` — aggregate_root; sensitivity: RESTRICTED; Explicit opt-in; coarse geography.
- `MatchCandidateSnapshot` — derived; sensitivity: RESTRICTED; Derived score explanation; no sensitive raw feature dump.
- `ConnectionRequest` — aggregate_root; sensitivity: CONFIDENTIAL; Rate-limited and reportable.
- `Connection` — aggregate_root; sensitivity: CONFIDENTIAL; Mutual relationship; messaging eligibility policy.
- `BlockRelation` — entity; sensitivity: RESTRICTED; Always checked by search/matching/messaging.

## Related API contracts

- `GET /api/v1/matching/preferences` — capability `matching.manage_preferences`; request `-`; response `MatchPreferenceDTO`; events `-`
- `PUT /api/v1/matching/preferences` — capability `matching.manage_preferences`; request `MatchPreferenceInput`; response `MatchPreferenceDTO`; events `matching.preferences_updated`
- `GET /api/v1/matching/candidates` — capability `matching.view_candidates`; request `MatchCandidateQuery`; response `Paginated<MatchCandidateDTO>`; events `matching.candidates_viewed`

## Related capabilities

- `matching.manage_preferences` — Manage own matching preferences
- `matching.view_candidates` — View privacy-filtered candidates

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- `HUD-VIS-011` — set 2, `11_parent_account_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-012` — set 2, `12_saved_items_activities_events.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-013` — set 2, `13_my_listings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-014` — set 2, `14_create_listing_step_1_category_age.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-015` — set 2, `15_create_listing_step_2_photos_price.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-016` — set 2, `16_messages_buyer_seller_chat.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-017` — set 2, `17_family_matching_preferences.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-018` — set 2, `18_family_match_results.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-019` — set 2, `19_family_match_detail_connect_request.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-020` — set 2, `20_connection_request_chat.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/matching/**`
- `tests/matching/**`
- `docs/execution/P4-005/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: coarse geo, no child sensitive leakage.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P4-005/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P4-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P4-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P4-005/HANDOFF.md. Stop after the task.
```


---

# P4-006 — Implement match-to-connection flow

## Metadata

| Field | Value |
|---|---|
| Task ID | `P4-006` |
| Phase | Phase 4 |
| Epic | Matching |
| Priority | P1 |
| Dependency wave | 26 |
| Dependencies | P4-005 |
| Owning module | `src/modules/matching` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement match-to-connection flow** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P4-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p4-006-implement-match-to-connection-flow`.

## Required implementation

1. set55/555 + connection policy.
2. Opt-in only; coarse location; no exact child birthdate or address in discovery.
3. Apply block/safety exclusion before scoring.
4. Explanations must not leak hidden attributes.

## Related canonical entities

- `FamilyProfile` — aggregate_root; sensitivity: RESTRICTED; Parent-owned family unit.
- `FamilyMember` — entity; sensitivity: HIGHLY_RESTRICTED; Child/member data minimized; age stage preferred over birthdate in discovery.
- `Interest` — reference; sensitivity: PUBLIC; Controlled taxonomy.
- `FamilyInterest` — association; sensitivity: CONFIDENTIAL; Matching/discovery preference input.
- `FamilyVisibilityRule` — entity; sensitivity: RESTRICTED; Field-level audience policy.
- `MatchPreference` — aggregate_root; sensitivity: RESTRICTED; Explicit opt-in; coarse geography.
- `MatchCandidateSnapshot` — derived; sensitivity: RESTRICTED; Derived score explanation; no sensitive raw feature dump.
- `ConnectionRequest` — aggregate_root; sensitivity: CONFIDENTIAL; Rate-limited and reportable.
- `Connection` — aggregate_root; sensitivity: CONFIDENTIAL; Mutual relationship; messaging eligibility policy.
- `BlockRelation` — entity; sensitivity: RESTRICTED; Always checked by search/matching/messaging.

## Related API contracts

- `GET /api/v1/matching/preferences` — capability `matching.manage_preferences`; request `-`; response `MatchPreferenceDTO`; events `-`
- `PUT /api/v1/matching/preferences` — capability `matching.manage_preferences`; request `MatchPreferenceInput`; response `MatchPreferenceDTO`; events `matching.preferences_updated`
- `GET /api/v1/matching/candidates` — capability `matching.view_candidates`; request `MatchCandidateQuery`; response `Paginated<MatchCandidateDTO>`; events `matching.candidates_viewed`

## Related capabilities

- `matching.manage_preferences` — Manage own matching preferences
- `matching.view_candidates` — View privacy-filtered candidates

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- `HUD-VIS-011` — set 2, `11_parent_account_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-012` — set 2, `12_saved_items_activities_events.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/saved`
- `HUD-VIS-013` — set 2, `13_my_listings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-014` — set 2, `14_create_listing_step_1_category_age.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-015` — set 2, `15_create_listing_step_2_photos_price.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-016` — set 2, `16_messages_buyer_seller_chat.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-017` — set 2, `17_family_matching_preferences.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-018` — set 2, `18_family_match_results.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-019` — set 2, `19_family_match_detail_connect_request.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`
- `HUD-VIS-020` — set 2, `20_connection_request_chat.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/connections/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/matching/**`
- `tests/matching/**`
- `docs/execution/P4-006/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set55/555 + connection policy.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P4-006/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P4-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P4-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P4-006/HANDOFF.md. Stop after the task.
```


---

# P5-001 — Implement ExpertProfile onboarding/state

## Metadata

| Field | Value |
|---|---|
| Task ID | `P5-001` |
| Phase | Phase 5 |
| Epic | Services |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P1-002, P1-010 |
| Owning module | `src/modules/services` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement ExpertProfile onboarding/state** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-002, P1-010**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p5-001-implement-expertprofile-onboarding-state`.

## Required implementation

1. set21 supply side.
2. Keep expert profile, service offering and availability explicit.
3. Authorization depends on expert ownership/scoped grants.
4. Do not couple booking lifecycle directly to profile UI.

## Related canonical entities

- `ExpertProfile` — aggregate_root; sensitivity: CONFIDENTIAL; Credentials separately verified.
- `ServiceOffering` — aggregate_root; sensitivity: CONFIDENTIAL; Duration/price/location mode.
- `AvailabilityRule` — entity; sensitivity: CONFIDENTIAL; Timezone-aware recurring availability.
- `Booking` — aggregate_root; sensitivity: RESTRICTED; Concurrency and cancellation policy.
- `Review` — aggregate_root; sensitivity: CONFIDENTIAL; Only eligible completed transactions.

## Related API contracts

- `GET /api/v1/services` — capability `public.read`; request `ServiceQuery`; response `Paginated<ServiceCardDTO>`; events `service.search_viewed`
- `GET /api/v1/services/{serviceId}` — capability `public.read`; request `-`; response `ServiceDTO`; events `service.viewed`
- `POST /api/v1/expert/services` — capability `service.manage_own`; request `CreateServiceInput`; response `ServiceDTO`; events `service.created`

## Related capabilities

- `service.book` — Book service
- `service.manage_own` — Manage own service offering
- `system.internal` — Internal service capability

## Related routes

- `/services` — Services discovery / owner `Services` / P1
- `/services/[serviceId]` — Service detail / owner `Services` / P1
- `/app/services` — Services / owner `Services` / P1

## Visual acceptance references

- `HUD-VIS-401` — set 40, `401_services_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-402` — set 40, `402_service_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-403` — set 40, `403_service_search_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-404` — set 40, `404_service_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-405` — set 40, `405_provider_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-406` — set 40, `406_book_service.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services`
- `HUD-VIS-407` — set 40, `407_booking_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-408` — set 40, `408_my_bookings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-409` — set 40, `409_service_reviews.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-410` — set 40, `410_recommendations.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services`
- `HUD-VIS-471` — set 47, `471_services_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-472` — set 47, `472_service_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/services/**`
- `tests/services/**`
- `docs/execution/P5-001/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set21 supply side.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P5-001/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P5-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P5-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P5-001/HANDOFF.md. Stop after the task.
```


---

# P5-002 — Implement ServiceOffering/availability

## Metadata

| Field | Value |
|---|---|
| Task ID | `P5-002` |
| Phase | Phase 5 |
| Epic | Services |
| Priority | P1 |
| Dependency wave | 25 |
| Dependencies | P5-001 |
| Owning module | `src/modules/services` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement ServiceOffering/availability** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P5-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p5-002-implement-serviceoffering-availability`.

## Required implementation

1. set47/set40.
2. Keep expert profile, service offering and availability explicit.
3. Authorization depends on expert ownership/scoped grants.
4. Do not couple booking lifecycle directly to profile UI.

## Related canonical entities

- `ExpertProfile` — aggregate_root; sensitivity: CONFIDENTIAL; Credentials separately verified.
- `ServiceOffering` — aggregate_root; sensitivity: CONFIDENTIAL; Duration/price/location mode.
- `AvailabilityRule` — entity; sensitivity: CONFIDENTIAL; Timezone-aware recurring availability.
- `Booking` — aggregate_root; sensitivity: RESTRICTED; Concurrency and cancellation policy.
- `Review` — aggregate_root; sensitivity: CONFIDENTIAL; Only eligible completed transactions.

## Related API contracts

- `GET /api/v1/services` — capability `public.read`; request `ServiceQuery`; response `Paginated<ServiceCardDTO>`; events `service.search_viewed`
- `GET /api/v1/services/{serviceId}` — capability `public.read`; request `-`; response `ServiceDTO`; events `service.viewed`
- `POST /api/v1/expert/services` — capability `service.manage_own`; request `CreateServiceInput`; response `ServiceDTO`; events `service.created`

## Related capabilities

- `service.book` — Book service
- `service.manage_own` — Manage own service offering
- `system.internal` — Internal service capability

## Related routes

- `/services` — Services discovery / owner `Services` / P1
- `/services/[serviceId]` — Service detail / owner `Services` / P1
- `/app/services` — Services / owner `Services` / P1

## Visual acceptance references

- `HUD-VIS-401` — set 40, `401_services_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-402` — set 40, `402_service_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-403` — set 40, `403_service_search_filters.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-404` — set 40, `404_service_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-405` — set 40, `405_provider_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-406` — set 40, `406_book_service.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services`
- `HUD-VIS-407` — set 40, `407_booking_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-408` — set 40, `408_my_bookings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-409` — set 40, `409_service_reviews.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-410` — set 40, `410_recommendations.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services`
- `HUD-VIS-471` — set 47, `471_services_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-472` — set 47, `472_service_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/services/**`
- `tests/services/**`
- `docs/execution/P5-002/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set47/set40.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P5-002/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P5-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P5-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P5-002/HANDOFF.md. Stop after the task.
```


---

# P5-003 — Implement booking request/confirm lifecycle

## Metadata

| Field | Value |
|---|---|
| Task ID | `P5-003` |
| Phase | Phase 5 |
| Epic | Bookings |
| Priority | P1 |
| Dependency wave | 26 |
| Dependencies | P5-002 |
| Owning module | `src/modules/bookings` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement booking request/confirm lifecycle** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P5-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p5-003-implement-booking-request-confirm-lifecycle`.

## Required implementation

1. set47.
2. Use explicit request/confirmed/rescheduled/cancelled/completed/no-show states.
3. Make slot reservation/concurrency behavior deterministic.
4. Audit provider-side overrides.

## Related canonical entities

- `ExpertProfile` — aggregate_root; sensitivity: CONFIDENTIAL; Credentials separately verified.
- `ServiceOffering` — aggregate_root; sensitivity: CONFIDENTIAL; Duration/price/location mode.
- `AvailabilityRule` — entity; sensitivity: CONFIDENTIAL; Timezone-aware recurring availability.
- `Booking` — aggregate_root; sensitivity: RESTRICTED; Concurrency and cancellation policy.
- `Review` — aggregate_root; sensitivity: CONFIDENTIAL; Only eligible completed transactions.

## Related API contracts

- `POST /api/v1/services/{serviceId}/bookings` — capability `service.book`; request `CreateBookingInput`; response `BookingDTO`; events `booking.requested`
- `GET /api/v1/bookings` — capability `booking.manage_customer`; request `BookingQuery`; response `Paginated<BookingDTO>`; events `-`
- `POST /api/v1/bookings/{bookingId}/reschedule` — capability `booking.manage_customer`; request `RescheduleBookingInput`; response `BookingDTO`; events `booking.rescheduled`
- `POST /api/v1/bookings/{bookingId}/cancel` — capability `booking.manage_customer`; request `CancelBookingInput`; response `BookingDTO`; events `booking.cancelled`

## Related capabilities

- `booking.manage_provider` — Manage provider bookings
- `booking.manage_customer` — Manage own customer booking

## Related routes

- `/app/bookings` — Bookings / owner `Bookings` / P1

## Visual acceptance references

- `HUD-VIS-471` — set 47, `471_services_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-472` — set 47, `472_service_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-473` — set 47, `473_service_listings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-474` — set 47, `474_service_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-475` — set 47, `475_book_appointment.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-476` — set 47, `476_booking_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-477` — set 47, `477_booking_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-478` — set 47, `478_my_bookings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-479` — set 47, `479_booking_reschedule.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-480` — set 47, `480_booking_cancellation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-201` — set 21, `201_expert_application.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/expert`
- `HUD-VIS-202` — set 21, `202_expert_verification.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/expert`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/bookings/**`
- `tests/bookings/**`
- `docs/execution/P5-003/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set47.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P5-003/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P5-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P5-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P5-003/HANDOFF.md. Stop after the task.
```


---

# P5-004 — Implement reschedule/cancel/no-show

## Metadata

| Field | Value |
|---|---|
| Task ID | `P5-004` |
| Phase | Phase 5 |
| Epic | Bookings |
| Priority | P1 |
| Dependency wave | 27 |
| Dependencies | P5-003 |
| Owning module | `src/modules/bookings` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement reschedule/cancel/no-show** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P5-003**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p5-004-implement-reschedule-cancel-no-show`.

## Required implementation

1. edge cases.
2. Use explicit request/confirmed/rescheduled/cancelled/completed/no-show states.
3. Make slot reservation/concurrency behavior deterministic.
4. Audit provider-side overrides.

## Related canonical entities

- `ExpertProfile` — aggregate_root; sensitivity: CONFIDENTIAL; Credentials separately verified.
- `ServiceOffering` — aggregate_root; sensitivity: CONFIDENTIAL; Duration/price/location mode.
- `AvailabilityRule` — entity; sensitivity: CONFIDENTIAL; Timezone-aware recurring availability.
- `Booking` — aggregate_root; sensitivity: RESTRICTED; Concurrency and cancellation policy.
- `Review` — aggregate_root; sensitivity: CONFIDENTIAL; Only eligible completed transactions.

## Related API contracts

- `POST /api/v1/services/{serviceId}/bookings` — capability `service.book`; request `CreateBookingInput`; response `BookingDTO`; events `booking.requested`
- `GET /api/v1/bookings` — capability `booking.manage_customer`; request `BookingQuery`; response `Paginated<BookingDTO>`; events `-`
- `POST /api/v1/bookings/{bookingId}/reschedule` — capability `booking.manage_customer`; request `RescheduleBookingInput`; response `BookingDTO`; events `booking.rescheduled`
- `POST /api/v1/bookings/{bookingId}/cancel` — capability `booking.manage_customer`; request `CancelBookingInput`; response `BookingDTO`; events `booking.cancelled`

## Related capabilities

- `booking.manage_provider` — Manage provider bookings
- `booking.manage_customer` — Manage own customer booking

## Related routes

- `/app/bookings` — Bookings / owner `Bookings` / P1

## Visual acceptance references

- `HUD-VIS-471` — set 47, `471_services_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-472` — set 47, `472_service_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-473` — set 47, `473_service_listings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-474` — set 47, `474_service_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-475` — set 47, `475_book_appointment.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-476` — set 47, `476_booking_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-477` — set 47, `477_booking_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-478` — set 47, `478_my_bookings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-479` — set 47, `479_booking_reschedule.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-480` — set 47, `480_booking_cancellation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/services/*`
- `HUD-VIS-201` — set 21, `201_expert_application.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/expert`
- `HUD-VIS-202` — set 21, `202_expert_verification.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/expert`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/bookings/**`
- `tests/bookings/**`
- `docs/execution/P5-004/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: edge cases.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P5-004/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P5-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P5-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P5-004/HANDOFF.md. Stop after the task.
```


---

# P5-005 — Implement experience creation operations

## Metadata

| Field | Value |
|---|---|
| Task ID | `P5-005` |
| Phase | Phase 5 |
| Epic | Organizer |
| Priority | P1 |
| Dependency wave | 25 |
| Dependencies | P2-002, P1-002 |
| Owning module | `src/modules/experiences` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement experience creation operations** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-002, P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p5-005-implement-experience-creation-operations`.

## Required implementation

1. set17.
2. Reuse Experience core and occurrence/registration primitives.
3. Organizer permissions are scoped to owned/assigned experiences.
4. Check-in operations require idempotency.

## Related canonical entities

- `Experience` — aggregate_root; sensitivity: CONFIDENTIAL; Kind EVENT|ACTIVITY; common discovery fields.
- `EventDetails` — entity; sensitivity: CONFIDENTIAL; Ticketing/host/event specifics.
- `ActivityDetails` — entity; sensitivity: CONFIDENTIAL; Age range/recurrence/activity specifics.
- `ExperienceOccurrence` — aggregate_root; sensitivity: CONFIDENTIAL; Timezone-aware start/end/capacity.
- `Registration` — aggregate_root; sensitivity: RESTRICTED; Family member data minimized.
- `Ticket` — entity; sensitivity: RESTRICTED; Opaque QR token; rotate/revoke.
- `CheckIn` — append_only; sensitivity: RESTRICTED; Auditable operator/time/device.

## Related API contracts

- `GET /api/v1/experiences` — capability `public.read`; request `ExperienceQuery`; response `Paginated<ExperienceCardDTO>`; events `experience.search_viewed`
- `GET /api/v1/experiences/{experienceId}` — capability `public.read`; request `-`; response `ExperienceDTO`; events `experience.viewed`
- `POST /api/v1/experiences` — capability `experience.create`; request `CreateExperienceInput`; response `ExperienceDTO`; events `experience.created`
- `PATCH /api/v1/experiences/{experienceId}` — capability `experience.manage_own`; request `UpdateExperienceInput`; response `ExperienceDTO`; events `experience.updated`
- `POST /api/v1/experiences/{experienceId}/publish` — capability `experience.manage_own`; request `PublishExperienceInput`; response `ExperienceDTO`; events `experience.published`
- `POST /api/v1/occurrences/{occurrenceId}/registrations` — capability `experience.register`; request `CreateRegistrationInput`; response `RegistrationDTO`; events `registration.created`
- `DELETE /api/v1/registrations/{registrationId}` — capability `experience.register`; request `CancelRegistrationInput`; response `204`; events `registration.cancelled`
- `POST /api/v1/checkins` — capability `experience.checkin`; request `CheckInInput`; response `CheckInDTO`; events `registration.checked_in`

## Related capabilities

- `experience.register` — Register self/family for experience
- `experience.create` — Create organizer-owned event/activity
- `experience.manage_own` — Manage own experience
- `experience.checkin` — Check in registered participant
- `experience.admin` — Administer any experience

## Related routes

- `/events` — Events discovery / owner `Experiences` / P0
- `/events/[eventId]` — Event detail / owner `Experiences` / P0
- `/activities` — Activities discovery / owner `Experiences` / P0
- `/activities/[activityId]` — Activity detail / owner `Experiences` / P1
- `/app/events` — Events / owner `Experiences` / P0
- `/app/activities` — Activities / owner `Experiences` / P0

## Visual acceptance references

- `HUD-OVR-S57` — set 57, `huddle_set57_mobile_supply_side_tools_overview.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app`
- `HUD-VIS-161` — set 17, `161_create_event_basic_info.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-162` — set 17, `162_create_event_location.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-163` — set 17, `163_create_event_tickets.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-164` — set 17, `164_create_event_description.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-165` — set 17, `165_create_event_organizer_contact.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-166` — set 17, `166_create_event_review_publish.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-167` — set 17, `167_event_published_success.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-168` — set 17, `168_my_events_list.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-169` — set 17, `169_event_registrations.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-170` — set 17, `170_event_analytics.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-171` — set 18, `171_create_activity_basic_info.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/activities`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/experiences/**`
- `tests/experiences/**`
- `docs/execution/P5-005/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set17.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P5-005/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P5-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P5-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P5-005/HANDOFF.md. Stop after the task.
```


---

# P5-006 — Implement check-in/ticket operations

## Metadata

| Field | Value |
|---|---|
| Task ID | `P5-006` |
| Phase | Phase 5 |
| Epic | Organizer |
| Priority | P1 |
| Dependency wave | 26 |
| Dependencies | P2-004, P5-005 |
| Owning module | `src/modules/experiences` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement check-in/ticket operations** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-004, P5-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p5-006-implement-check-in-ticket-operations`.

## Required implementation

1. set16/set57.
2. Reuse Experience core and occurrence/registration primitives.
3. Organizer permissions are scoped to owned/assigned experiences.
4. Check-in operations require idempotency.
5. Check-in commands require idempotency and scoped organizer authorization.

## Related canonical entities

- `Experience` — aggregate_root; sensitivity: CONFIDENTIAL; Kind EVENT|ACTIVITY; common discovery fields.
- `EventDetails` — entity; sensitivity: CONFIDENTIAL; Ticketing/host/event specifics.
- `ActivityDetails` — entity; sensitivity: CONFIDENTIAL; Age range/recurrence/activity specifics.
- `ExperienceOccurrence` — aggregate_root; sensitivity: CONFIDENTIAL; Timezone-aware start/end/capacity.
- `Registration` — aggregate_root; sensitivity: RESTRICTED; Family member data minimized.
- `Ticket` — entity; sensitivity: RESTRICTED; Opaque QR token; rotate/revoke.
- `CheckIn` — append_only; sensitivity: RESTRICTED; Auditable operator/time/device.

## Related API contracts

- `GET /api/v1/experiences` — capability `public.read`; request `ExperienceQuery`; response `Paginated<ExperienceCardDTO>`; events `experience.search_viewed`
- `GET /api/v1/experiences/{experienceId}` — capability `public.read`; request `-`; response `ExperienceDTO`; events `experience.viewed`
- `POST /api/v1/experiences` — capability `experience.create`; request `CreateExperienceInput`; response `ExperienceDTO`; events `experience.created`
- `PATCH /api/v1/experiences/{experienceId}` — capability `experience.manage_own`; request `UpdateExperienceInput`; response `ExperienceDTO`; events `experience.updated`
- `POST /api/v1/experiences/{experienceId}/publish` — capability `experience.manage_own`; request `PublishExperienceInput`; response `ExperienceDTO`; events `experience.published`
- `POST /api/v1/occurrences/{occurrenceId}/registrations` — capability `experience.register`; request `CreateRegistrationInput`; response `RegistrationDTO`; events `registration.created`
- `DELETE /api/v1/registrations/{registrationId}` — capability `experience.register`; request `CancelRegistrationInput`; response `204`; events `registration.cancelled`
- `POST /api/v1/checkins` — capability `experience.checkin`; request `CheckInInput`; response `CheckInDTO`; events `registration.checked_in`

## Related capabilities

- `experience.register` — Register self/family for experience
- `experience.create` — Create organizer-owned event/activity
- `experience.manage_own` — Manage own experience
- `experience.checkin` — Check in registered participant
- `experience.admin` — Administer any experience

## Related routes

- `/events` — Events discovery / owner `Experiences` / P0
- `/events/[eventId]` — Event detail / owner `Experiences` / P0
- `/activities` — Activities discovery / owner `Experiences` / P0
- `/activities/[activityId]` — Activity detail / owner `Experiences` / P1
- `/app/events` — Events / owner `Experiences` / P0
- `/app/activities` — Activities / owner `Experiences` / P0

## Visual acceptance references

- `HUD-OVR-S57` — set 57, `huddle_set57_mobile_supply_side_tools_overview.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app`
- `HUD-VIS-161` — set 17, `161_create_event_basic_info.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-162` — set 17, `162_create_event_location.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-163` — set 17, `163_create_event_tickets.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-164` — set 17, `164_create_event_description.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-165` — set 17, `165_create_event_organizer_contact.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-166` — set 17, `166_create_event_review_publish.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-167` — set 17, `167_event_published_success.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-168` — set 17, `168_my_events_list.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-169` — set 17, `169_event_registrations.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-170` — set 17, `170_event_analytics.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/events`
- `HUD-VIS-171` — set 18, `171_create_activity_basic_info.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/organizer/activities`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/experiences/**`
- `tests/experiences/**`
- `docs/execution/P5-006/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set16/set57.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P5-006/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P5-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P5-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P5-006/HANDOFF.md. Stop after the task.
```


---

# P6-001 — Implement Partner/Store/Product core

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-001` |
| Phase | Phase 6 |
| Epic | Catalog |
| Priority | P1 |
| Dependency wave | 21 |
| Dependencies | P1-002 |
| Owning module | `src/modules/catalog` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement Partner/Store/Product core** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-001-implement-partner-store-product-core`.

## Required implementation

1. set49/catalog boundary.
2. Keep partner catalog separate from P2P listings.
3. Feed sync runs are observable, idempotent and retryable.
4. Preserve external source identifiers without making them internal primary keys.

## Related canonical entities

- `Partner` — aggregate_root; sensitivity: CONFIDENTIAL; Commercial partner profile.
- `Store` — aggregate_root; sensitivity: CONFIDENTIAL; Public storefront settings.
- `Product` — aggregate_root; sensitivity: CONFIDENTIAL; Partner/native catalog product; never P2P Listing.
- `ProductVariant` — entity; sensitivity: CONFIDENTIAL; SKU/price/stock attributes.
- `PartnerFeed` — aggregate_root; sensitivity: RESTRICTED; Source configuration/credentials by secret reference.
- `FeedSyncRun` — entity; sensitivity: INTERNAL; Operational trace and error summary.
- `AffiliateClick` — append_only; sensitivity: CONFIDENTIAL; Pseudonymous attribution; explicit retention.

## Related API contracts

- `GET /api/v1/products` — capability `public.read`; request `ProductQuery`; response `Paginated<ProductCardDTO>`; events `product.search_viewed`
- `GET /api/v1/products/{productId}` — capability `public.read`; request `-`; response `ProductDTO`; events `product.viewed`
- `POST /api/v1/partner/feeds` — capability `catalog.manage_partner`; request `CreatePartnerFeedInput`; response `PartnerFeedDTO`; events `partner_feed.created`
- `POST /api/v1/partner/feeds/{feedId}/sync` — capability `catalog.manage_partner`; request `-`; response `FeedSyncRunDTO`; events `partner_feed.sync_requested`

## Related capabilities

- `catalog.manage_partner` — Manage scoped partner catalog/feed
- `catalog.approve` — Approve partner/store/product feed
- `order.fulfill` — Fulfill scoped seller/partner order
- `partner.manage_org` — Manage partner organization

## Related routes

- `/marketplace/products/[productId]` — Product catalog / owner `Catalog` / P1

## Visual acceptance references

- `HUD-VIS-491` — set 49, `491_marketplace_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-492` — set 49, `492_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-493` — set 49, `493_product_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-494` — set 49, `494_cart.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-495` — set 49, `495_checkout.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-496` — set 49, `496_order_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-497` — set 49, `497_my_orders.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-498` — set 49, `498_order_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-499` — set 49, `499_track_order.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-500` — set 49, `500_seller_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-131` — set 14, `131_partner_application.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/partner`
- `HUD-VIS-132` — set 14, `132_store_verification_business_details.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/partner`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/catalog/**`
- `tests/catalog/**`
- `docs/execution/P6-001/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set49/catalog boundary.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-001/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-001/HANDOFF.md. Stop after the task.
```


---

# P6-002 — Implement partner feed sync run model

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-002` |
| Phase | Phase 6 |
| Epic | Catalog |
| Priority | P2 |
| Dependency wave | 22 |
| Dependencies | P6-001 |
| Owning module | `src/modules/catalog` |
| Risk | MEDIUM |
| React UI expected | no / not primary |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement partner feed sync run model** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-002-implement-partner-feed-sync-run-model`.

## Required implementation

1. set14/set55.
2. Keep partner catalog separate from P2P listings.
3. Feed sync runs are observable, idempotent and retryable.
4. Preserve external source identifiers without making them internal primary keys.

## Related canonical entities

- `Partner` — aggregate_root; sensitivity: CONFIDENTIAL; Commercial partner profile.
- `Store` — aggregate_root; sensitivity: CONFIDENTIAL; Public storefront settings.
- `Product` — aggregate_root; sensitivity: CONFIDENTIAL; Partner/native catalog product; never P2P Listing.
- `ProductVariant` — entity; sensitivity: CONFIDENTIAL; SKU/price/stock attributes.
- `PartnerFeed` — aggregate_root; sensitivity: RESTRICTED; Source configuration/credentials by secret reference.
- `FeedSyncRun` — entity; sensitivity: INTERNAL; Operational trace and error summary.
- `AffiliateClick` — append_only; sensitivity: CONFIDENTIAL; Pseudonymous attribution; explicit retention.

## Related API contracts

- `GET /api/v1/products` — capability `public.read`; request `ProductQuery`; response `Paginated<ProductCardDTO>`; events `product.search_viewed`
- `GET /api/v1/products/{productId}` — capability `public.read`; request `-`; response `ProductDTO`; events `product.viewed`
- `POST /api/v1/partner/feeds` — capability `catalog.manage_partner`; request `CreatePartnerFeedInput`; response `PartnerFeedDTO`; events `partner_feed.created`
- `POST /api/v1/partner/feeds/{feedId}/sync` — capability `catalog.manage_partner`; request `-`; response `FeedSyncRunDTO`; events `partner_feed.sync_requested`

## Related capabilities

- `catalog.manage_partner` — Manage scoped partner catalog/feed
- `catalog.approve` — Approve partner/store/product feed
- `order.fulfill` — Fulfill scoped seller/partner order
- `partner.manage_org` — Manage partner organization

## Related routes

- `/marketplace/products/[productId]` — Product catalog / owner `Catalog` / P1

## Visual acceptance references

- `HUD-VIS-491` — set 49, `491_marketplace_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-492` — set 49, `492_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-493` — set 49, `493_product_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-494` — set 49, `494_cart.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-495` — set 49, `495_checkout.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-496` — set 49, `496_order_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-497` — set 49, `497_my_orders.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-498` — set 49, `498_order_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-499` — set 49, `499_track_order.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-500` — set 49, `500_seller_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-131` — set 14, `131_partner_application.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/partner`
- `HUD-VIS-132` — set 14, `132_store_verification_business_details.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/partner`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/catalog/**`
- `tests/catalog/**`
- `docs/execution/P6-002/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set14/set55.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-002/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-002/HANDOFF.md. Stop after the task.
```


---

# P6-003 — Implement cart and server pricing

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-003` |
| Phase | Phase 6 |
| Epic | Cart |
| Priority | P1 |
| Dependency wave | 22 |
| Dependencies | P6-001 |
| Owning module | `src/modules/orders` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement cart and server pricing** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-003-implement-cart-and-server-pricing`.

## Required implementation

1. set49/set43.
2. Server owns price calculation and availability validation.
3. Never trust client totals.
4. Define deterministic merge behavior for anonymous/authenticated carts if supported.
5. Calculate prices on server from canonical ProductVariant and promotion rules; client totals are display-only.

## Related canonical entities

- `Cart` — aggregate_root; sensitivity: CONFIDENTIAL; Server recalculates price.
- `CartItem` — entity; sensitivity: CONFIDENTIAL; Snapshot commercial terms.
- `Order` — aggregate_root; sensitivity: RESTRICTED; Immutable order number and totals snapshot.
- `OrderItem` — entity; sensitivity: RESTRICTED; Product/title/price tax snapshot.
- `Shipment` — aggregate_root; sensitivity: RESTRICTED; Tracking token protected.
- `ReturnRequest` — aggregate_root; sensitivity: RESTRICTED; Evidence/media optional.

## Related API contracts

- `GET /api/v1/cart` — capability `order.create`; request `-`; response `CartDTO`; events `-`
- `PUT /api/v1/cart/items` — capability `order.create`; request `UpsertCartItemInput`; response `CartDTO`; events `cart.updated`
- `POST /api/v1/checkout` — capability `order.create`; request `CheckoutInput`; response `CheckoutSessionDTO`; events `checkout.started`
- `POST /api/v1/orders` — capability `order.create`; request `CreateOrderInput`; response `OrderDTO`; events `order.created`
- `GET /api/v1/orders` — capability `order.read_own`; request `OrderQuery`; response `Paginated<OrderSummaryDTO>`; events `-`
- `GET /api/v1/orders/{orderId}` — capability `order.read_own`; request `-`; response `OrderDTO`; events `order.viewed`
- `POST /api/v1/orders/{orderId}/cancel` — capability `order.read_own`; request `CancelOrderInput`; response `OrderDTO`; events `order.cancelled`
- `POST /api/v1/orders/{orderId}/returns` — capability `order.refund_request`; request `CreateReturnInput`; response `ReturnRequestDTO`; events `return.requested`

## Related capabilities

- `order.create` — Create order
- `order.read_own` — Read own buyer order
- `order.fulfill` — Fulfill scoped seller/partner order
- `order.refund_request` — Request refund

## Related routes

- `/app/orders` — Orders / owner `Orders` / P1

## Visual acceptance references

- `HUD-VIS-431` — set 43, `431_mobile_cart.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-432` — set 43, `432_mobile_checkout.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-433` — set 43, `433_mobile_payment_method.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders`
- `HUD-VIS-434` — set 43, `434_mobile_order_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-435` — set 43, `435_mobile_order_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-436` — set 43, `436_mobile_pickup_scheduling.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-437` — set 43, `437_mobile_delivery_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-438` — set 43, `438_mobile_return_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-439` — set 43, `439_mobile_refund_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-440` — set 43, `440_mobile_order_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-491` — set 49, `491_marketplace_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-492` — set 49, `492_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/orders/**`
- `tests/orders/**`
- `docs/execution/P6-003/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set49/set43.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-003/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-003/HANDOFF.md. Stop after the task.
```


---

# P6-004 — Implement Order/OrderItem lifecycle

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-004` |
| Phase | Phase 6 |
| Epic | Orders |
| Priority | P1 |
| Dependency wave | 23 |
| Dependencies | P6-003 |
| Owning module | `src/modules/orders` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement Order/OrderItem lifecycle** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-003**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-004-implement-order-orderitem-lifecycle`.

## Required implementation

1. set49.
2. Order snapshots preserve purchase-time facts.
3. Use idempotency on create and state transition commands.
4. Financial state is not inferred from UI.
5. Persist order-time snapshots of title, price, tax/fee facts and seller/partner references needed for history.

## Related canonical entities

- `Cart` — aggregate_root; sensitivity: CONFIDENTIAL; Server recalculates price.
- `CartItem` — entity; sensitivity: CONFIDENTIAL; Snapshot commercial terms.
- `Order` — aggregate_root; sensitivity: RESTRICTED; Immutable order number and totals snapshot.
- `OrderItem` — entity; sensitivity: RESTRICTED; Product/title/price tax snapshot.
- `Shipment` — aggregate_root; sensitivity: RESTRICTED; Tracking token protected.
- `ReturnRequest` — aggregate_root; sensitivity: RESTRICTED; Evidence/media optional.

## Related API contracts

- `GET /api/v1/cart` — capability `order.create`; request `-`; response `CartDTO`; events `-`
- `PUT /api/v1/cart/items` — capability `order.create`; request `UpsertCartItemInput`; response `CartDTO`; events `cart.updated`
- `POST /api/v1/checkout` — capability `order.create`; request `CheckoutInput`; response `CheckoutSessionDTO`; events `checkout.started`
- `POST /api/v1/orders` — capability `order.create`; request `CreateOrderInput`; response `OrderDTO`; events `order.created`
- `GET /api/v1/orders` — capability `order.read_own`; request `OrderQuery`; response `Paginated<OrderSummaryDTO>`; events `-`
- `GET /api/v1/orders/{orderId}` — capability `order.read_own`; request `-`; response `OrderDTO`; events `order.viewed`
- `POST /api/v1/orders/{orderId}/cancel` — capability `order.read_own`; request `CancelOrderInput`; response `OrderDTO`; events `order.cancelled`
- `POST /api/v1/orders/{orderId}/returns` — capability `order.refund_request`; request `CreateReturnInput`; response `ReturnRequestDTO`; events `return.requested`

## Related capabilities

- `order.create` — Create order
- `order.read_own` — Read own buyer order
- `order.fulfill` — Fulfill scoped seller/partner order
- `order.refund_request` — Request refund

## Related routes

- `/app/orders` — Orders / owner `Orders` / P1

## Visual acceptance references

- `HUD-VIS-431` — set 43, `431_mobile_cart.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-432` — set 43, `432_mobile_checkout.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-433` — set 43, `433_mobile_payment_method.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders`
- `HUD-VIS-434` — set 43, `434_mobile_order_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-435` — set 43, `435_mobile_order_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-436` — set 43, `436_mobile_pickup_scheduling.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-437` — set 43, `437_mobile_delivery_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-438` — set 43, `438_mobile_return_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-439` — set 43, `439_mobile_refund_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-440` — set 43, `440_mobile_order_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-491` — set 49, `491_marketplace_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-492` — set 49, `492_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/orders/**`
- `tests/orders/**`
- `docs/execution/P6-004/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set49.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-004/HANDOFF.md` exists and accurately records the change.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-004/HANDOFF.md. Stop after the task.
```


---

# P6-005 — Implement provider-neutral payment interfaces

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-005` |
| Phase | Phase 6 |
| Epic | Payments |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P6-004 |
| Owning module | `src/modules/payments` |
| Risk | HIGH |
| React UI expected | no / not primary |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement provider-neutral payment interfaces** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-004**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-005-implement-provider-neutral-payment-interfaces`.

## Required implementation

1. no live mode without gate.
2. Provider-neutral interfaces only until commercial/legal gate approves live provider.
3. Use immutable internal references, webhook inbox and idempotency.
4. Never log secrets or raw payment credentials.
5. Do not enable live charges or payouts. Implement interfaces and test adapter only until separate provider/legal ADR.

## Related canonical entities

- `Payment` — aggregate_root; sensitivity: RESTRICTED; Provider-neutral references only; no PAN.
- `PaymentAttempt` — append_only; sensitivity: RESTRICTED; Idempotency and provider event refs.
- `Refund` — aggregate_root; sensitivity: RESTRICTED; Amount/currency/reason/audit.
- `Dispute` — aggregate_root; sensitivity: RESTRICTED; Provider state mirrored.
- `Payout` — aggregate_root; sensitivity: RESTRICTED; KYC gate externalized.
- `Commission` — append_only; sensitivity: RESTRICTED; Immutable ledger-style line.
- `Invoice` — aggregate_root; sensitivity: RESTRICTED; Tax fields approval gate.
- `WebhookInbox` — append_only; sensitivity: RESTRICTED; Unique provider event id; safe retries.

## Related API contracts

- `POST /api/v1/payments/intents` — capability `order.create`; request `CreatePaymentIntentInput`; response `PaymentIntentDTO`; events `payment.intent_created`
- `POST /api/v1/payments/webhooks/{provider}` — capability `system.internal`; request `ProviderWebhook`; response `204`; events `payment.provider_event_received`

## Related capabilities

- `finance.refund_execute` — Execute approved refund
- `finance.dispute_manage` — Manage payment disputes
- `finance.payout_review` — Review payout
- `finance.ledger_read` — Read financial operations ledger

## Related routes

- `/app/wallet` — Wallet / owner `Payments` / P1

## Visual acceptance references

- `HUD-OVR-S62` — set 62, `huddle_set62_admin_finance_commercial_operations_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-621` — set 62, `621_payment_overview_admin.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-622` — set 62, `622_refund_queue.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-623` — set 62, `623_dispute_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-624` — set 62, `624_partner_commission_ledger.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-625` — set 62, `625_expert_payout_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-626` — set 62, `626_organizer_payout_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-627` — set 62, `627_invoice_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-628` — set 62, `628_failed_payment_queue.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-629` — set 62, `629_tax_vat_report.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-630` — set 62, `630_revenue_dashboard.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-071` — set 8, `71_wallet_transactions.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/payments/**`
- `tests/payments/**`
- `docs/execution/P6-005/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: no live mode without gate.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-005/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-005/HANDOFF.md. Stop after the task.
```


---

# P6-006 — Implement webhook inbox/idempotency

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-006` |
| Phase | Phase 6 |
| Epic | Payments |
| Priority | P1 |
| Dependency wave | 25 |
| Dependencies | P6-005 |
| Owning module | `src/modules/payments` |
| Risk | HIGH |
| React UI expected | no / not primary |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement webhook inbox/idempotency** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-006-implement-webhook-inbox-idempotency`.

## Required implementation

1. safe event processing.
2. Provider-neutral interfaces only until commercial/legal gate approves live provider.
3. Use immutable internal references, webhook inbox and idempotency.
4. Never log secrets or raw payment credentials.
5. Webhook inbox stores provider event identity, raw-body hash/reference, processing state and idempotent outcome; verify signatures in provider adapter.

## Related canonical entities

- `Payment` — aggregate_root; sensitivity: RESTRICTED; Provider-neutral references only; no PAN.
- `PaymentAttempt` — append_only; sensitivity: RESTRICTED; Idempotency and provider event refs.
- `Refund` — aggregate_root; sensitivity: RESTRICTED; Amount/currency/reason/audit.
- `Dispute` — aggregate_root; sensitivity: RESTRICTED; Provider state mirrored.
- `Payout` — aggregate_root; sensitivity: RESTRICTED; KYC gate externalized.
- `Commission` — append_only; sensitivity: RESTRICTED; Immutable ledger-style line.
- `Invoice` — aggregate_root; sensitivity: RESTRICTED; Tax fields approval gate.
- `WebhookInbox` — append_only; sensitivity: RESTRICTED; Unique provider event id; safe retries.

## Related API contracts

- `POST /api/v1/payments/intents` — capability `order.create`; request `CreatePaymentIntentInput`; response `PaymentIntentDTO`; events `payment.intent_created`
- `POST /api/v1/payments/webhooks/{provider}` — capability `system.internal`; request `ProviderWebhook`; response `204`; events `payment.provider_event_received`

## Related capabilities

- `finance.refund_execute` — Execute approved refund
- `finance.dispute_manage` — Manage payment disputes
- `finance.payout_review` — Review payout
- `finance.ledger_read` — Read financial operations ledger

## Related routes

- `/app/wallet` — Wallet / owner `Payments` / P1

## Visual acceptance references

- `HUD-OVR-S62` — set 62, `huddle_set62_admin_finance_commercial_operations_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-621` — set 62, `621_payment_overview_admin.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-622` — set 62, `622_refund_queue.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-623` — set 62, `623_dispute_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-624` — set 62, `624_partner_commission_ledger.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-625` — set 62, `625_expert_payout_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-626` — set 62, `626_organizer_payout_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-627` — set 62, `627_invoice_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-628` — set 62, `628_failed_payment_queue.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-629` — set 62, `629_tax_vat_report.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-630` — set 62, `630_revenue_dashboard.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-071` — set 8, `71_wallet_transactions.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/payments/**`
- `tests/payments/**`
- `docs/execution/P6-006/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: safe event processing.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-006/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.
- [ ] Idempotency/concurrency behavior is covered by tests where the task can receive duplicate or concurrent commands.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-006/HANDOFF.md. Stop after the task.
```


---

# P6-007 — Implement shipment/pickup/tracking

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-007` |
| Phase | Phase 6 |
| Epic | Fulfillment |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P6-004 |
| Owning module | `src/modules/orders` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement shipment/pickup/tracking** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-004**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-007-implement-shipment-pickup-tracking`.

## Required implementation

1. set12/set43.
2. Model shipment/pickup/tracking independently from payment state.
3. State transitions must be validated.
4. External carrier events are idempotently ingested.

## Related canonical entities

- `Cart` — aggregate_root; sensitivity: CONFIDENTIAL; Server recalculates price.
- `CartItem` — entity; sensitivity: CONFIDENTIAL; Snapshot commercial terms.
- `Order` — aggregate_root; sensitivity: RESTRICTED; Immutable order number and totals snapshot.
- `OrderItem` — entity; sensitivity: RESTRICTED; Product/title/price tax snapshot.
- `Shipment` — aggregate_root; sensitivity: RESTRICTED; Tracking token protected.
- `ReturnRequest` — aggregate_root; sensitivity: RESTRICTED; Evidence/media optional.

## Related API contracts

- `GET /api/v1/cart` — capability `order.create`; request `-`; response `CartDTO`; events `-`
- `PUT /api/v1/cart/items` — capability `order.create`; request `UpsertCartItemInput`; response `CartDTO`; events `cart.updated`
- `POST /api/v1/checkout` — capability `order.create`; request `CheckoutInput`; response `CheckoutSessionDTO`; events `checkout.started`
- `POST /api/v1/orders` — capability `order.create`; request `CreateOrderInput`; response `OrderDTO`; events `order.created`
- `GET /api/v1/orders` — capability `order.read_own`; request `OrderQuery`; response `Paginated<OrderSummaryDTO>`; events `-`
- `GET /api/v1/orders/{orderId}` — capability `order.read_own`; request `-`; response `OrderDTO`; events `order.viewed`
- `POST /api/v1/orders/{orderId}/cancel` — capability `order.read_own`; request `CancelOrderInput`; response `OrderDTO`; events `order.cancelled`
- `POST /api/v1/orders/{orderId}/returns` — capability `order.refund_request`; request `CreateReturnInput`; response `ReturnRequestDTO`; events `return.requested`

## Related capabilities

- `order.create` — Create order
- `order.read_own` — Read own buyer order
- `order.fulfill` — Fulfill scoped seller/partner order
- `order.refund_request` — Request refund

## Related routes

- `/app/orders` — Orders / owner `Orders` / P1

## Visual acceptance references

- `HUD-VIS-431` — set 43, `431_mobile_cart.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-432` — set 43, `432_mobile_checkout.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-433` — set 43, `433_mobile_payment_method.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders`
- `HUD-VIS-434` — set 43, `434_mobile_order_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-435` — set 43, `435_mobile_order_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-436` — set 43, `436_mobile_pickup_scheduling.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-437` — set 43, `437_mobile_delivery_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-438` — set 43, `438_mobile_return_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-439` — set 43, `439_mobile_refund_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-440` — set 43, `440_mobile_order_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-111` — set 12, `111_cart_reserved_items.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-112` — set 12, `112_partner_product_outbound_redirect.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/orders`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/orders/**`
- `tests/orders/**`
- `docs/execution/P6-007/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set12/set43.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-007/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-007/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-007. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-007/HANDOFF.md. Stop after the task.
```


---

# P6-008 — Implement return/refund request lifecycle

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-008` |
| Phase | Phase 6 |
| Epic | Returns |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P6-004 |
| Owning module | `src/modules/orders` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement return/refund request lifecycle** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-004**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-008-implement-return-refund-request-lifecycle`.

## Required implementation

1. set12.
2. Separate return request from refund execution.
3. Preserve reason/evidence references and decision audit.
4. Do not auto-refund without approved policy/provider gate.

## Related canonical entities

- `Cart` — aggregate_root; sensitivity: CONFIDENTIAL; Server recalculates price.
- `CartItem` — entity; sensitivity: CONFIDENTIAL; Snapshot commercial terms.
- `Order` — aggregate_root; sensitivity: RESTRICTED; Immutable order number and totals snapshot.
- `OrderItem` — entity; sensitivity: RESTRICTED; Product/title/price tax snapshot.
- `Shipment` — aggregate_root; sensitivity: RESTRICTED; Tracking token protected.
- `ReturnRequest` — aggregate_root; sensitivity: RESTRICTED; Evidence/media optional.
- `Payment` — aggregate_root; sensitivity: RESTRICTED; Provider-neutral references only; no PAN.
- `PaymentAttempt` — append_only; sensitivity: RESTRICTED; Idempotency and provider event refs.
- `Refund` — aggregate_root; sensitivity: RESTRICTED; Amount/currency/reason/audit.
- `Dispute` — aggregate_root; sensitivity: RESTRICTED; Provider state mirrored.
- `Payout` — aggregate_root; sensitivity: RESTRICTED; KYC gate externalized.
- `Commission` — append_only; sensitivity: RESTRICTED; Immutable ledger-style line.
- `Invoice` — aggregate_root; sensitivity: RESTRICTED; Tax fields approval gate.
- `WebhookInbox` — append_only; sensitivity: RESTRICTED; Unique provider event id; safe retries.

## Related API contracts

- `GET /api/v1/cart` — capability `order.create`; request `-`; response `CartDTO`; events `-`
- `PUT /api/v1/cart/items` — capability `order.create`; request `UpsertCartItemInput`; response `CartDTO`; events `cart.updated`
- `POST /api/v1/checkout` — capability `order.create`; request `CheckoutInput`; response `CheckoutSessionDTO`; events `checkout.started`
- `POST /api/v1/orders` — capability `order.create`; request `CreateOrderInput`; response `OrderDTO`; events `order.created`
- `GET /api/v1/orders` — capability `order.read_own`; request `OrderQuery`; response `Paginated<OrderSummaryDTO>`; events `-`
- `GET /api/v1/orders/{orderId}` — capability `order.read_own`; request `-`; response `OrderDTO`; events `order.viewed`
- `POST /api/v1/orders/{orderId}/cancel` — capability `order.read_own`; request `CancelOrderInput`; response `OrderDTO`; events `order.cancelled`
- `POST /api/v1/orders/{orderId}/returns` — capability `order.refund_request`; request `CreateReturnInput`; response `ReturnRequestDTO`; events `return.requested`
- `POST /api/v1/payments/intents` — capability `order.create`; request `CreatePaymentIntentInput`; response `PaymentIntentDTO`; events `payment.intent_created`
- `POST /api/v1/payments/webhooks/{provider}` — capability `system.internal`; request `ProviderWebhook`; response `204`; events `payment.provider_event_received`

## Related capabilities

- `order.create` — Create order
- `order.read_own` — Read own buyer order
- `order.fulfill` — Fulfill scoped seller/partner order
- `order.refund_request` — Request refund
- `finance.refund_execute` — Execute approved refund
- `finance.dispute_manage` — Manage payment disputes
- `finance.payout_review` — Review payout
- `finance.ledger_read` — Read financial operations ledger

## Related routes

- `/app/orders` — Orders / owner `Orders` / P1

## Visual acceptance references

- `HUD-OVR-S62` — set 62, `huddle_set62_admin_finance_commercial_operations_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-431` — set 43, `431_mobile_cart.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-432` — set 43, `432_mobile_checkout.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-433` — set 43, `433_mobile_payment_method.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders`
- `HUD-VIS-434` — set 43, `434_mobile_order_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-435` — set 43, `435_mobile_order_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-436` — set 43, `436_mobile_pickup_scheduling.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-437` — set 43, `437_mobile_delivery_tracking.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-438` — set 43, `438_mobile_return_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-439` — set 43, `439_mobile_refund_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-440` — set 43, `440_mobile_order_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-621` — set 62, `621_payment_overview_admin.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/orders/**`
- `tests/orders/**`
- `docs/execution/P6-008/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set12.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-008/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-008/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-008. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-008/HANDOFF.md. Stop after the task.
```


---

# P6-009 — Implement outbound attribution boundary

## Metadata

| Field | Value |
|---|---|
| Task ID | `P6-009` |
| Phase | Phase 6 |
| Epic | Affiliate |
| Priority | P2 |
| Dependency wave | 22 |
| Dependencies | P6-001 |
| Owning module | `src/modules/catalog` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement outbound attribution boundary** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p6-009-implement-outbound-attribution-boundary`.

## Required implementation

1. separate from native order.
2. Keep outbound attribution separate from native Order lifecycle.
3. Avoid dark patterns and preserve consent requirements.
4. Use signed/validated attribution parameters.
5. Affiliate click attribution must never create a native Order.

## Related canonical entities

- `Partner` — aggregate_root; sensitivity: CONFIDENTIAL; Commercial partner profile.
- `Store` — aggregate_root; sensitivity: CONFIDENTIAL; Public storefront settings.
- `Product` — aggregate_root; sensitivity: CONFIDENTIAL; Partner/native catalog product; never P2P Listing.
- `ProductVariant` — entity; sensitivity: CONFIDENTIAL; SKU/price/stock attributes.
- `PartnerFeed` — aggregate_root; sensitivity: RESTRICTED; Source configuration/credentials by secret reference.
- `FeedSyncRun` — entity; sensitivity: INTERNAL; Operational trace and error summary.
- `AffiliateClick` — append_only; sensitivity: CONFIDENTIAL; Pseudonymous attribution; explicit retention.

## Related API contracts

- `GET /api/v1/products` — capability `public.read`; request `ProductQuery`; response `Paginated<ProductCardDTO>`; events `product.search_viewed`
- `GET /api/v1/products/{productId}` — capability `public.read`; request `-`; response `ProductDTO`; events `product.viewed`
- `POST /api/v1/partner/feeds` — capability `catalog.manage_partner`; request `CreatePartnerFeedInput`; response `PartnerFeedDTO`; events `partner_feed.created`
- `POST /api/v1/partner/feeds/{feedId}/sync` — capability `catalog.manage_partner`; request `-`; response `FeedSyncRunDTO`; events `partner_feed.sync_requested`

## Related capabilities

- `catalog.manage_partner` — Manage scoped partner catalog/feed
- `catalog.approve` — Approve partner/store/product feed
- `order.fulfill` — Fulfill scoped seller/partner order
- `partner.manage_org` — Manage partner organization

## Related routes

- `/marketplace/products/[productId]` — Product catalog / owner `Catalog` / P1

## Visual acceptance references

- `HUD-VIS-491` — set 49, `491_marketplace_home.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-492` — set 49, `492_categories.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-493` — set 49, `493_product_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace/*`
- `HUD-VIS-494` — set 49, `494_cart.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-495` — set 49, `495_checkout.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-496` — set 49, `496_order_confirmation.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-497` — set 49, `497_my_orders.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-498` — set 49, `498_order_details.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-499` — set 49, `499_track_order.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-500` — set 49, `500_seller_profile.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/marketplace`
- `HUD-VIS-131` — set 14, `131_partner_application.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/partner`
- `HUD-VIS-132` — set 14, `132_store_verification_business_details.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/partner`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/catalog/**`
- `tests/catalog/**`
- `docs/execution/P6-009/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: separate from native order.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P6-009/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P6-009/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P6-009. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P6-009/HANDOFF.md. Stop after the task.
```


---

# P7-001 — Implement localized public shell

## Metadata

| Field | Value |
|---|---|
| Task ID | `P7-001` |
| Phase | Phase 7 |
| Epic | Public Web |
| Priority | P1 |
| Dependency wave | 23 |
| Dependencies | P1-009 |
| Owning module | `src/modules/public-web` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement localized public shell** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-009**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p7-001-implement-localized-public-shell`.

## Required implementation

1. /en and /no.
2. Use localized public shell and canonical metadata strategy.
3. Do not leak private app state into public rendering.
4. Keep React component reuse without coupling public pages to authenticated shells.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- `/` — Marketing / owner `PublicWeb` / P0
- `/marketplace` — Marketplace discovery / owner `Listings/Catalog` / P0
- `/marketplace/listings/[listingId]` — P2P listing / owner `Listings` / P0
- `/marketplace/products/[productId]` — Product catalog / owner `Catalog` / P1
- `/events` — Events discovery / owner `Experiences` / P0
- `/events/[eventId]` — Event detail / owner `Experiences` / P0
- `/activities` — Activities discovery / owner `Experiences` / P0
- `/activities/[activityId]` — Activity detail / owner `Experiences` / P1
- `/services` — Services discovery / owner `Services` / P1
- `/services/[serviceId]` — Service detail / owner `Services` / P1
- `/experts/[expertId]` — Expert profile / owner `Expert` / P1
- `/safety` — Safety / owner `TrustSafety` / P0
- `/privacy` — Privacy / owner `Privacy` / P0
- `/terms` — Terms / owner `Terms` / P0
- `/community-guidelines` — Guidelines / owner `Guidelines` / P0
- `/family-guides/[stage]` — Age-stage guides / owner `Age-stage` / P1
- `/seasonal-guides/[slug]` — Seasonal guides / owner `Seasonal` / P1
- `/cities/[citySlug]` — City landing / owner `City` / P1
- `/cities/[citySlug]/activities` — City activities SEO / owner `City` / P1
- `/cities/[citySlug]/events` — City events SEO / owner `City` / P1

## Visual acceptance references

- `HUD-VIS-S01-01` — set 1, `1 Image 26 июн. 2026 г., 08_30_03 (1).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-02` — set 1, `10 Image 26 июн. 2026 г., 08_30_03 (10).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-03` — set 1, `2 Image 26 июн. 2026 г., 08_30_03 (2).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-04` — set 1, `3 Image 26 июн. 2026 г., 08_30_03 (3).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-05` — set 1, `4 Image 26 июн. 2026 г., 08_30_03 (4).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-06` — set 1, `5 Image 26 июн. 2026 г., 08_30_03 (5).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-07` — set 1, `6 Image 26 июн. 2026 г., 08_30_03 (6).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-08` — set 1, `7 Image 26 июн. 2026 г., 08_30_03 (7).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-09` — set 1, `8 Image 26 июн. 2026 г., 08_30_03 (8).png`, disposition `REFERENCE_ONLY`, route candidate `/`
- `HUD-VIS-S01-10` — set 1, `9 Image 26 июн. 2026 г., 08_30_03 (9).png`, disposition `REFERENCE_ONLY`, route candidate `/`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/public-web/**`
- `tests/public-web/**`
- `docs/execution/P7-001/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: /en and /no.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P7-001/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P7-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P7-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P7-001/HANDOFF.md. Stop after the task.
```


---

# P7-002 — Implement city/category/age/season templates

## Metadata

| Field | Value |
|---|---|
| Task ID | `P7-002` |
| Phase | Phase 7 |
| Epic | SEO |
| Priority | P1 |
| Dependency wave | 24 |
| Dependencies | P7-001, P2-001 |
| Owning module | `src/modules/seo` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement city/category/age/season templates** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P7-001, P2-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p7-002-implement-city-category-age-season-templates`.

## Required implementation

1. set41/42/59.
2. Use canonical route mapping, hreflang and sitemap contracts.
3. Do not generate infinite filter-index pages.
4. Structured data must reflect actual visible content.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- `GET /api/v1/search` — capability `public.read`; request `GlobalSearchQuery`; response `GlobalSearchDTO`; events `search.performed`

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- `/community-guidelines` — Guidelines / owner `Guidelines` / P0
- `/family-guides/[stage]` — Age-stage guides / owner `Age-stage` / P1
- `/seasonal-guides/[slug]` — Seasonal guides / owner `Seasonal` / P1
- `/cities/[citySlug]` — City landing / owner `City` / P1
- `/cities/[citySlug]/activities` — City activities SEO / owner `City` / P1
- `/cities/[citySlug]/events` — City events SEO / owner `City` / P1
- `/cities/[citySlug]/marketplace` — City marketplace SEO / owner `City` / P1
- `/cities/[citySlug]/services` — City services SEO / owner `City` / P1

## Visual acceptance references

- `HUD-VIS-411` — set 41, `411_oslo_family_activities.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/activities/*`
- `HUD-VIS-412` — set 41, `412_oslo_family_events.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-413` — set 41, `413_oslo_kids_marketplace.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-414` — set 41, `414_oslo_parent_community.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-415` — set 41, `415_oslo_family_services.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-416` — set 41, `416_free_family_activities_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/activities/*`
- `HUD-VIS-417` — set 41, `417_weekend_family_events_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-418` — set 41, `418_used_baby_gear_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-419` — set 41, `419_kids_workshops_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-420` — set 41, `420_family_safety_privacy_guide.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-421` — set 42, `421_newborn_hub.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/family-guides`
- `HUD-VIS-422` — set 42, `422_toddler_hub.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/family-guides`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/seo/**`
- `tests/seo/**`
- `docs/execution/P7-002/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set41/42/59.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P7-002/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P7-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P7-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P7-002/HANDOFF.md. Stop after the task.
```


---

# P7-003 — Implement metadata/canonical/hreflang/sitemap

## Metadata

| Field | Value |
|---|---|
| Task ID | `P7-003` |
| Phase | Phase 7 |
| Epic | SEO |
| Priority | P1 |
| Dependency wave | 25 |
| Dependencies | P7-002 |
| Owning module | `src/modules/seo` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement metadata/canonical/hreflang/sitemap** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P7-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p7-003-implement-metadata-canonical-hreflang-sitemap`.

## Required implementation

1. SEO contract tests.
2. Use canonical route mapping, hreflang and sitemap contracts.
3. Do not generate infinite filter-index pages.
4. Structured data must reflect actual visible content.
5. Add automated canonical/hreflang/sitemap contract tests.

## Related canonical entities

- None mandated by current catalog for this task. Do not invent schema without explicit need.

## Related API contracts

- `GET /api/v1/search` — capability `public.read`; request `GlobalSearchQuery`; response `GlobalSearchDTO`; events `search.performed`

## Related capabilities

- No new capability is mandated. Existing authorization rules still apply.

## Related routes

- `/community-guidelines` — Guidelines / owner `Guidelines` / P0
- `/family-guides/[stage]` — Age-stage guides / owner `Age-stage` / P1
- `/seasonal-guides/[slug]` — Seasonal guides / owner `Seasonal` / P1
- `/cities/[citySlug]` — City landing / owner `City` / P1
- `/cities/[citySlug]/activities` — City activities SEO / owner `City` / P1
- `/cities/[citySlug]/events` — City events SEO / owner `City` / P1
- `/cities/[citySlug]/marketplace` — City marketplace SEO / owner `City` / P1
- `/cities/[citySlug]/services` — City services SEO / owner `City` / P1

## Visual acceptance references

- `HUD-VIS-411` — set 41, `411_oslo_family_activities.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/activities/*`
- `HUD-VIS-412` — set 41, `412_oslo_family_events.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-413` — set 41, `413_oslo_kids_marketplace.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-414` — set 41, `414_oslo_parent_community.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-415` — set 41, `415_oslo_family_services.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-416` — set 41, `416_free_family_activities_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/activities/*`
- `HUD-VIS-417` — set 41, `417_weekend_family_events_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-418` — set 41, `418_used_baby_gear_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-419` — set 41, `419_kids_workshops_oslo.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/cities/[citySlug]`
- `HUD-VIS-420` — set 41, `420_family_safety_privacy_guide.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-421` — set 42, `421_newborn_hub.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/family-guides`
- `HUD-VIS-422` — set 42, `422_toddler_hub.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/family-guides`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/seo/**`
- `tests/seo/**`
- `docs/execution/P7-003/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: SEO contract tests.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P7-003/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P7-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P7-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P7-003/HANDOFF.md. Stop after the task.
```


---

# P7-004 — Implement user accessibility preferences

## Metadata

| Field | Value |
|---|---|
| Task ID | `P7-004` |
| Phase | Phase 7 |
| Epic | Accessibility |
| Priority | P0 |
| Dependency wave | 23 |
| Dependencies | P1-009 |
| Owning module | `src/modules/accessibility` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement user accessibility preferences** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-009**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p7-004-implement-user-accessibility-preferences`.

## Required implementation

1. set60.
2. Keyboard, focus, labels, contrast and reduced-motion behavior are release gates.
3. Store preferences without assuming disability-sensitive analytics consent.
4. Test compact and wide layouts.

## Related canonical entities

- `ConsentRecord` — append_only; sensitivity: RESTRICTED; Purpose, source, timestamp, evidence.
- `PolicyVersion` — versioned_reference; sensitivity: PUBLIC; Legal source reference.
- `DataRequest` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Access/export/delete/correct.
- `RetentionPolicy` — versioned_reference; sensitivity: RESTRICTED; Cannot be silently disabled.
- `AnonymizationRule` — versioned_reference; sensitivity: RESTRICTED; Audited transform definition.
- `ExportApproval` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Four-eyes policy for sensitive exports.
- `PrivacyIncident` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Restricted access and timeline.

## Related API contracts

- `GET /api/v1/consents` — capability `privacy.consent.manage_self`; request `-`; response `ConsentSummaryDTO`; events `-`
- `POST /api/v1/consents` — capability `privacy.consent.manage_self`; request `ConsentDecisionInput`; response `ConsentRecordDTO`; events `consent.changed`
- `POST /api/v1/privacy/requests` — capability `privacy.request.create`; request `CreateDataRequestInput`; response `DataRequestDTO`; events `privacy.request_submitted`
- `GET /api/v1/privacy/requests` — capability `privacy.request.create`; request `-`; response `DataRequestDTO[]`; events `-`
- `GET /api/v1/admin/privacy/governance` — capability `privacy.policy.manage`; request `-`; response `GovernanceDashboardDTO`; events `-`
- `POST /api/v1/admin/privacy/exports/{id}/approve` — capability `privacy.export.approve`; request `ExportApprovalInput`; response `ExportApprovalDTO`; events `privacy.export_approved`

## Related capabilities

- `matching.view_candidates` — View privacy-filtered candidates
- `privacy.consent.manage_self` — Manage own consent records
- `privacy.request.create` — Create own data request
- `privacy.request.process` — Process privacy request
- `privacy.policy.manage` — Manage retention/anonymization rules
- `privacy.export.approve` — Approve governed export

## Related routes

- `/privacy` — Privacy / owner `Privacy` / P0
- `/app/privacy` — Privacy center / owner `Privacy` / P0
- `/admin/privacy` — Privacy governance / owner `Privacy` / P0

## Visual acceptance references

- `HUD-OVR-S60` — set 60, `huddle_set60_accessibility_localization_consent_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-601` — set 60, `601_accessibility_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-602` — set 60, `602_high_contrast_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-603` — set 60, `603_large_text_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-604` — set 60, `604_language_selector_en_no.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-605` — set 60, `605_consent_management.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-606` — set 60, `606_cookie_preferences.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-607` — set 60, `607_data_download_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-608` — set 60, `608_delete_account_flow.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-609` — set 60, `609_parent_consent_update.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-610` — set 60, `610_privacy_request_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-OVR-S61` — set 61, `huddle_set61_responsive_web_variants_overview.png`, disposition `RESPONSIVE_REFERENCE`, route candidate `N/A`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/accessibility/**`
- `tests/accessibility/**`
- `docs/execution/P7-004/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set60.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P7-004/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P7-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P7-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P7-004/HANDOFF.md. Stop after the task.
```


---

# P7-005 — Implement data request workflow

## Metadata

| Field | Value |
|---|---|
| Task ID | `P7-005` |
| Phase | Phase 7 |
| Epic | Privacy |
| Priority | P0 |
| Dependency wave | 23 |
| Dependencies | P1-007 |
| Owning module | `src/modules/privacy` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement data request workflow** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-007**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p7-005-implement-data-request-workflow`.

## Required implementation

1. set60.
2. Data requests are authenticated, auditable workflows.
3. Deletion honors retention/legal hold and uses anonymization/tombstoning where required.
4. Never promise immediate hard delete of append-only required records.

## Related canonical entities

- `ConsentRecord` — append_only; sensitivity: RESTRICTED; Purpose, source, timestamp, evidence.
- `PolicyVersion` — versioned_reference; sensitivity: PUBLIC; Legal source reference.
- `DataRequest` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Access/export/delete/correct.
- `RetentionPolicy` — versioned_reference; sensitivity: RESTRICTED; Cannot be silently disabled.
- `AnonymizationRule` — versioned_reference; sensitivity: RESTRICTED; Audited transform definition.
- `ExportApproval` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Four-eyes policy for sensitive exports.
- `PrivacyIncident` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Restricted access and timeline.

## Related API contracts

- `GET /api/v1/consents` — capability `privacy.consent.manage_self`; request `-`; response `ConsentSummaryDTO`; events `-`
- `POST /api/v1/consents` — capability `privacy.consent.manage_self`; request `ConsentDecisionInput`; response `ConsentRecordDTO`; events `consent.changed`
- `POST /api/v1/privacy/requests` — capability `privacy.request.create`; request `CreateDataRequestInput`; response `DataRequestDTO`; events `privacy.request_submitted`
- `GET /api/v1/privacy/requests` — capability `privacy.request.create`; request `-`; response `DataRequestDTO[]`; events `-`
- `GET /api/v1/admin/privacy/governance` — capability `privacy.policy.manage`; request `-`; response `GovernanceDashboardDTO`; events `-`
- `POST /api/v1/admin/privacy/exports/{id}/approve` — capability `privacy.export.approve`; request `ExportApprovalInput`; response `ExportApprovalDTO`; events `privacy.export_approved`

## Related capabilities

- `matching.view_candidates` — View privacy-filtered candidates
- `privacy.consent.manage_self` — Manage own consent records
- `privacy.request.create` — Create own data request
- `privacy.request.process` — Process privacy request
- `privacy.policy.manage` — Manage retention/anonymization rules
- `privacy.export.approve` — Approve governed export

## Related routes

- `/privacy` — Privacy / owner `Privacy` / P0
- `/app/privacy` — Privacy center / owner `Privacy` / P0
- `/admin/privacy` — Privacy governance / owner `Privacy` / P0

## Visual acceptance references

- `HUD-OVR-S60` — set 60, `huddle_set60_accessibility_localization_consent_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-OVR-S63` — set 63, `huddle_set63_data_privacy_governance_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-601` — set 60, `601_accessibility_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-602` — set 60, `602_high_contrast_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-603` — set 60, `603_large_text_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-604` — set 60, `604_language_selector_en_no.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-605` — set 60, `605_consent_management.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-606` — set 60, `606_cookie_preferences.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-607` — set 60, `607_data_download_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-608` — set 60, `608_delete_account_flow.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-609` — set 60, `609_parent_consent_update.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-610` — set 60, `610_privacy_request_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/privacy/**`
- `tests/privacy/**`
- `docs/execution/P7-005/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set60.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P7-005/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P7-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P7-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P7-005/HANDOFF.md. Stop after the task.
```


---

# P7-006 — Implement delete-account orchestration

## Metadata

| Field | Value |
|---|---|
| Task ID | `P7-006` |
| Phase | Phase 7 |
| Epic | Privacy |
| Priority | P0 |
| Dependency wave | 24 |
| Dependencies | P7-005 |
| Owning module | `src/modules/privacy` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement delete-account orchestration** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P7-005**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p7-006-implement-delete-account-orchestration`.

## Required implementation

1. retention/anonymization aware.
2. Data requests are authenticated, auditable workflows.
3. Deletion honors retention/legal hold and uses anonymization/tombstoning where required.
4. Never promise immediate hard delete of append-only required records.
5. Deletion orchestrator must honor retention policy/legal hold and provide status without claiming impossible hard deletion.

## Related canonical entities

- `ConsentRecord` — append_only; sensitivity: RESTRICTED; Purpose, source, timestamp, evidence.
- `PolicyVersion` — versioned_reference; sensitivity: PUBLIC; Legal source reference.
- `DataRequest` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Access/export/delete/correct.
- `RetentionPolicy` — versioned_reference; sensitivity: RESTRICTED; Cannot be silently disabled.
- `AnonymizationRule` — versioned_reference; sensitivity: RESTRICTED; Audited transform definition.
- `ExportApproval` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Four-eyes policy for sensitive exports.
- `PrivacyIncident` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Restricted access and timeline.

## Related API contracts

- `GET /api/v1/consents` — capability `privacy.consent.manage_self`; request `-`; response `ConsentSummaryDTO`; events `-`
- `POST /api/v1/consents` — capability `privacy.consent.manage_self`; request `ConsentDecisionInput`; response `ConsentRecordDTO`; events `consent.changed`
- `POST /api/v1/privacy/requests` — capability `privacy.request.create`; request `CreateDataRequestInput`; response `DataRequestDTO`; events `privacy.request_submitted`
- `GET /api/v1/privacy/requests` — capability `privacy.request.create`; request `-`; response `DataRequestDTO[]`; events `-`
- `GET /api/v1/admin/privacy/governance` — capability `privacy.policy.manage`; request `-`; response `GovernanceDashboardDTO`; events `-`
- `POST /api/v1/admin/privacy/exports/{id}/approve` — capability `privacy.export.approve`; request `ExportApprovalInput`; response `ExportApprovalDTO`; events `privacy.export_approved`

## Related capabilities

- `matching.view_candidates` — View privacy-filtered candidates
- `privacy.consent.manage_self` — Manage own consent records
- `privacy.request.create` — Create own data request
- `privacy.request.process` — Process privacy request
- `privacy.policy.manage` — Manage retention/anonymization rules
- `privacy.export.approve` — Approve governed export

## Related routes

- `/privacy` — Privacy / owner `Privacy` / P0
- `/app/privacy` — Privacy center / owner `Privacy` / P0
- `/admin/privacy` — Privacy governance / owner `Privacy` / P0

## Visual acceptance references

- `HUD-OVR-S60` — set 60, `huddle_set60_accessibility_localization_consent_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-OVR-S63` — set 63, `huddle_set63_data_privacy_governance_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-601` — set 60, `601_accessibility_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-602` — set 60, `602_high_contrast_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-603` — set 60, `603_large_text_mode.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-604` — set 60, `604_language_selector_en_no.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-605` — set 60, `605_consent_management.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-606` — set 60, `606_cookie_preferences.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/settings`
- `HUD-VIS-607` — set 60, `607_data_download_request.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-608` — set 60, `608_delete_account_flow.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-609` — set 60, `609_parent_consent_update.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-610` — set 60, `610_privacy_request_status.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/privacy/**`
- `tests/privacy/**`
- `docs/execution/P7-006/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: retention/anonymization aware.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P7-006/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P7-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P7-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P7-006/HANDOFF.md. Stop after the task.
```


---

# P8-001 — Implement core admin dashboard/user management

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-001` |
| Phase | Phase 8 |
| Epic | Admin |
| Priority | P0 |
| Dependency wave | 29 |
| Dependencies | P1-002, P2-012 |
| Owning module | `src/modules/admin` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement core admin dashboard/user management** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-002, P2-012**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-001-implement-core-admin-dashboard-user-management`.

## Required implementation

1. set25.
2. Every control requires a real backend capability and audit path.
3. No fake production controls.
4. Use scoped grants for operational access.

## Related canonical entities

- `User` — aggregate_root; sensitivity: CONFIDENTIAL; Business identity; never use provider user id as domain foreign key.
- `AuthIdentity` — entity; sensitivity: RESTRICTED; provider, providerSubject, verifiedEmail/Phone metadata.
- `Role` — reference; sensitivity: INTERNAL; Seeded stable RoleKey.
- `UserRole` — association; sensitivity: INTERNAL; Coarse role assignment; auditable.
- `Capability` — reference; sensitivity: INTERNAL; Code-defined key mirrored for admin display.
- `ScopedGrant` — entity; sensitivity: RESTRICTED; Fine-grained scoped grant; optional resource/geo scope.
- `Organization` — aggregate_root; sensitivity: CONFIDENTIAL; Partner, municipality, provider organizations.
- `OrganizationMembership` — association; sensitivity: CONFIDENTIAL; Membership separate from platform RoleKey.
- `UserPreference` — entity; sensitivity: CONFIDENTIAL; Locale, timezone, accessibility, communication settings.
- `AuditLog` — append_only; sensitivity: RESTRICTED; Actor, action, target, before/after hash, request id, IP risk metadata.
- `SafetyReport` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Reporter identity protected.
- `ModerationCase` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Case access is capability/scoped.
- `EnforcementAction` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Warning, restriction, suspension, removal.
- `Appeal` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Independent reviewer policy.

## Related API contracts

- `GET /api/v1/admin/users` — capability `admin.user.manage`; request `AdminUserQuery`; response `Paginated<AdminUserDTO>`; events `-`
- `PATCH /api/v1/admin/users/{userId}/status` — capability `admin.user.manage`; request `UpdateUserStatusInput`; response `AdminUserDTO`; events `admin.user_status_changed`
- `POST /api/v1/admin/users/{userId}/grants` — capability `admin.role.grant`; request `CreateScopedGrantInput`; response `ScopedGrantDTO`; events `admin.grant_created`
- `GET /api/v1/admin/audit-log` — capability `admin.audit.read`; request `AuditLogQuery`; response `Paginated<AuditLogDTO>`; events `-`

## Related capabilities

- `group.manage` — Manage group where owner/admin
- `experience.admin` — Administer any experience
- `admin.user.manage` — Manage user status/roles
- `admin.role.grant` — Grant coarse role/scoped capability
- `admin.audit.read` — Read audit log

## Related routes

- `/admin` — Admin dashboard / owner `Admin` / P0

## Visual acceptance references

- `HUD-VIS-251` — set 25, `251_admin_dashboard.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-252` — set 25, `252_user_management.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-253` — set 25, `253_user_detail.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-254` — set 25, `254_family_account_review.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-255` — set 25, `255_listing_moderation_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-256` — set 25, `256_product_listing_moderation_detail.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-257` — set 25, `257_organizer_verification_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-258` — set 25, `258_partner_store_approval.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-259` — set 25, `259_expert_verification_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/admin`
- `HUD-VIS-260` — set 25, `260_reports_safety_queue.png`, disposition `SPECIALIST_CANONICAL_SUPPLEMENT`, route candidate `/app/safety/*`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/admin/**`
- `tests/admin/**`
- `docs/execution/P8-001/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set25.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-001/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-001/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-001. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-001/HANDOFF.md. Stop after the task.
```


---

# P8-002 — Implement ticket/helpdesk core

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-002` |
| Phase | Phase 8 |
| Epic | Support |
| Priority | P2 |
| Dependency wave | 21 |
| Dependencies | P1-002 |
| Owning module | `src/modules/support` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement ticket/helpdesk core** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-002-implement-ticket-helpdesk-core`.

## Required implementation

1. set28.
2. Keep support conversation context within shared messaging where appropriate.
3. Protect user data with least-privilege access.
4. Audit sensitive ticket access/override actions.

## Related canonical entities

- `SupportTicket` — aggregate_root; sensitivity: RESTRICTED; Category, priority, assignment.
- `TicketReply` — entity; sensitivity: RESTRICTED; Internal/public visibility flag.
- `KnowledgeBaseArticle` — aggregate_root; sensitivity: PUBLIC; Versioned localized content.

## Related API contracts

- `POST /api/v1/support/tickets` — capability `support.ticket.create`; request `CreateSupportTicketInput`; response `SupportTicketDTO`; events `support.ticket_created`
- `GET /api/v1/support/tickets` — capability `support.ticket.create`; request `TicketQuery`; response `Paginated<SupportTicketDTO>`; events `-`

## Related capabilities

- `support.ticket.create` — Create support ticket
- `support.ticket.manage` — Manage assigned support ticket

## Related routes

- `/admin` — Admin dashboard / owner `Admin` / P0

## Visual acceptance references

- `HUD-VIS-281` — set 28, `281_support_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/support`
- `HUD-VIS-282` — set 28, `282_ticket_inbox.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-283` — set 28, `283_ticket_detail.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-284` — set 28, `284_reply_to_ticket.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/events/*`
- `HUD-VIS-285` — set 28, `285_knowledge_base.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/support`
- `HUD-VIS-286` — set 28, `286_knowledge_base_article.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/support`
- `HUD-VIS-287` — set 28, `287_faq_management.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/support`
- `HUD-VIS-288` — set 28, `288_feedback_ratings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/support`
- `HUD-VIS-289` — set 28, `289_announcement_center.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/support`
- `HUD-VIS-290` — set 28, `290_support_settings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/support`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/support/**`
- `tests/support/**`
- `docs/execution/P8-002/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set28.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-002/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-002/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-002. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-002/HANDOFF.md. Stop after the task.
```


---

# P8-003 — Implement refund/dispute/payout operations

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-003` |
| Phase | Phase 8 |
| Epic | Finance |
| Priority | P2 |
| Dependency wave | 26 |
| Dependencies | P6-006, P1-002 |
| Owning module | `src/modules/payments` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement refund/dispute/payout operations** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P6-006, P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-003-implement-refund-dispute-payout-operations`.

## Required implementation

1. set62.
2. High-risk operations require capability checks, idempotency and audit.
3. Separate request/review/execute where risk warrants.
4. Respect payment provider and legal gates.
5. Refund/dispute/payout operations are high-risk; require explicit capabilities, audit and provider gate.

## Related canonical entities

- `Payment` — aggregate_root; sensitivity: RESTRICTED; Provider-neutral references only; no PAN.
- `PaymentAttempt` — append_only; sensitivity: RESTRICTED; Idempotency and provider event refs.
- `Refund` — aggregate_root; sensitivity: RESTRICTED; Amount/currency/reason/audit.
- `Dispute` — aggregate_root; sensitivity: RESTRICTED; Provider state mirrored.
- `Payout` — aggregate_root; sensitivity: RESTRICTED; KYC gate externalized.
- `Commission` — append_only; sensitivity: RESTRICTED; Immutable ledger-style line.
- `Invoice` — aggregate_root; sensitivity: RESTRICTED; Tax fields approval gate.
- `WebhookInbox` — append_only; sensitivity: RESTRICTED; Unique provider event id; safe retries.

## Related API contracts

- `POST /api/v1/admin/refunds/{refundId}/approve` — capability `finance.refund_execute`; request `ApproveRefundInput`; response `RefundDTO`; events `refund.approved`
- `POST /api/v1/admin/payouts/{payoutId}/approve` — capability `finance.payout_review`; request `ApprovePayoutInput`; response `PayoutDTO`; events `payout.approved`

## Related capabilities

- `finance.refund_execute` — Execute approved refund
- `finance.dispute_manage` — Manage payment disputes
- `finance.payout_review` — Review payout
- `finance.ledger_read` — Read financial operations ledger

## Related routes

- `/app/wallet` — Wallet / owner `Payments` / P1

## Visual acceptance references

- `HUD-OVR-S62` — set 62, `huddle_set62_admin_finance_commercial_operations_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-621` — set 62, `621_payment_overview_admin.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-622` — set 62, `622_refund_queue.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/orders/*`
- `HUD-VIS-623` — set 62, `623_dispute_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-624` — set 62, `624_partner_commission_ledger.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-625` — set 62, `625_expert_payout_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-626` — set 62, `626_organizer_payout_review.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-627` — set 62, `627_invoice_detail.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-628` — set 62, `628_failed_payment_queue.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-629` — set 62, `629_tax_vat_report.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-630` — set 62, `630_revenue_dashboard.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/finance`
- `HUD-VIS-311` — set 31, `311_payment_dispute_admin.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/finance`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/payments/**`
- `tests/payments/**`
- `docs/execution/P8-003/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set62.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-003/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-003/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-003. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-003/HANDOFF.md. Stop after the task.
```


---

# P8-004 — Implement governance dashboard/policies

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-004` |
| Phase | Phase 8 |
| Epic | Privacy Ops |
| Priority | P0 |
| Dependency wave | 24 |
| Dependencies | P7-005, P1-002 |
| Owning module | `src/modules/privacy` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement governance dashboard/policies** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P7-005, P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-004-implement-governance-dashboard-policies`.

## Required implementation

1. set63.
2. Policy and export approvals are versioned and auditable.
3. No direct raw-data export from UI.
4. Use explicit governance state transitions.

## Related canonical entities

- `ConsentRecord` — append_only; sensitivity: RESTRICTED; Purpose, source, timestamp, evidence.
- `PolicyVersion` — versioned_reference; sensitivity: PUBLIC; Legal source reference.
- `DataRequest` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Access/export/delete/correct.
- `RetentionPolicy` — versioned_reference; sensitivity: RESTRICTED; Cannot be silently disabled.
- `AnonymizationRule` — versioned_reference; sensitivity: RESTRICTED; Audited transform definition.
- `ExportApproval` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Four-eyes policy for sensitive exports.
- `PrivacyIncident` — aggregate_root; sensitivity: HIGHLY_RESTRICTED; Restricted access and timeline.

## Related API contracts

- `GET /api/v1/consents` — capability `privacy.consent.manage_self`; request `-`; response `ConsentSummaryDTO`; events `-`
- `POST /api/v1/consents` — capability `privacy.consent.manage_self`; request `ConsentDecisionInput`; response `ConsentRecordDTO`; events `consent.changed`
- `POST /api/v1/privacy/requests` — capability `privacy.request.create`; request `CreateDataRequestInput`; response `DataRequestDTO`; events `privacy.request_submitted`
- `GET /api/v1/privacy/requests` — capability `privacy.request.create`; request `-`; response `DataRequestDTO[]`; events `-`
- `GET /api/v1/admin/privacy/governance` — capability `privacy.policy.manage`; request `-`; response `GovernanceDashboardDTO`; events `-`
- `POST /api/v1/admin/privacy/exports/{id}/approve` — capability `privacy.export.approve`; request `ExportApprovalInput`; response `ExportApprovalDTO`; events `privacy.export_approved`

## Related capabilities

- `matching.view_candidates` — View privacy-filtered candidates
- `privacy.consent.manage_self` — Manage own consent records
- `privacy.request.create` — Create own data request
- `privacy.request.process` — Process privacy request
- `privacy.policy.manage` — Manage retention/anonymization rules
- `privacy.export.approve` — Approve governed export

## Related routes

- `/privacy` — Privacy / owner `Privacy` / P0
- `/app/privacy` — Privacy center / owner `Privacy` / P0
- `/admin/privacy` — Privacy governance / owner `Privacy` / P0

## Visual acceptance references

- `HUD-OVR-S63` — set 63, `huddle_set63_data_privacy_governance_overview.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-631` — set 63, `631_data_governance_dashboard.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`
- `HUD-VIS-632` — set 63, `632_consent_audit_log.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-633` — set 63, `633_municipality_data_scope.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`
- `HUD-VIS-634` — set 63, `634_aggregated_insights_rules.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`
- `HUD-VIS-635` — set 63, `635_data_retention_settings.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`
- `HUD-VIS-636` — set 63, `636_anonymization_rules.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`
- `HUD-VIS-637` — set 63, `637_export_approval.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`
- `HUD-VIS-638` — set 63, `638_privacy_incident_report.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/app/privacy/*`
- `HUD-VIS-639` — set 63, `639_access_control_matrix.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`
- `HUD-VIS-640` — set 63, `640_compliance_checklist.png`, disposition `CANONICAL_CANDIDATE_IMPLEMENT`, route candidate `/admin/privacy`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/privacy/**`
- `tests/privacy/**`
- `docs/execution/P8-004/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set63.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-004/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-004/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-004. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-004/HANDOFF.md. Stop after the task.
```


---

# P8-005 — Implement org scopes/programs

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-005` |
| Phase | Phase 8 |
| Epic | Municipality |
| Priority | P2 |
| Dependency wave | 21 |
| Dependencies | P1-002 |
| Owning module | `src/modules/municipality` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement org scopes/programs** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-005-implement-org-scopes-programs`.

## Required implementation

1. set23.
2. Only aggregate/de-identified reporting.
3. Default minimum cohort threshold 10 and protect against differencing attacks.
4. Scope all access to municipality geography/programs.

## Related canonical entities

- `PublicProgram` — aggregate_root; sensitivity: CONFIDENTIAL; Municipality-owned program.
- `MunicipalityScope` — entity; sensitivity: RESTRICTED; Allowed geography/data scope.
- `AggregateReport` — derived; sensitivity: RESTRICTED; No row-level personal data.

## Related API contracts

- `GET /api/v1/municipality/reports` — capability `municipality.report_read`; request `MunicipalityReportQuery`; response `AggregateReportDTO[]`; events `-`
- `POST /api/v1/municipality/programs` — capability `municipality.program_manage`; request `CreateProgramInput`; response `PublicProgramDTO`; events `municipality.program_created`

## Related capabilities

- `municipality.program_manage` — Manage scoped public programs
- `municipality.report_read` — Read approved aggregated scoped reports
- `municipality.raw_data` — Read row-level personal data

## Related routes

- `/app/municipality` — Municipality dashboard / owner `Municipality` / P2

## Visual acceptance references

- `HUD-VIS-031` — set 4, `31_partner_store_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-032` — set 4, `32_product_feed_sync.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-033` — set 4, `33_product_feed_mapping.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-034` — set 4, `34_product_performance_analytics.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-035` — set 4, `35_campaign_manager.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-036` — set 4, `36_create_sponsored_campaign.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-037` — set 4, `37_regional_banner_placement.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-038` — set 4, `38_billing_commission_report.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-039` — set 4, `39_municipality_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-040` — set 4, `40_municipality_report_detail.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-231` — set 23, `231_municipality_onboarding.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-232` — set 23, `232_municipality_access_roles.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/municipality`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/municipality/**`
- `tests/municipality/**`
- `docs/execution/P8-005/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set23.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-005/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-005/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-005. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-005/HANDOFF.md. Stop after the task.
```


---

# P8-006 — Implement aggregate reporting pipeline

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-006` |
| Phase | Phase 8 |
| Epic | Municipality |
| Priority | P2 |
| Dependency wave | 25 |
| Dependencies | P8-005, P8-004 |
| Owning module | `src/modules/municipality` |
| Risk | HIGH |
| React UI expected | yes |
| Prisma schema expected | yes |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement aggregate reporting pipeline** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P8-005, P8-004**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-006-implement-aggregate-reporting-pipeline`.

## Required implementation

1. threshold/suppression.
2. Only aggregate/de-identified reporting.
3. Default minimum cohort threshold 10 and protect against differencing attacks.
4. Scope all access to municipality geography/programs.
5. Enforce cohort threshold >=10 by default, suppress small cells and defend against repeated-query differencing.

## Related canonical entities

- `PublicProgram` — aggregate_root; sensitivity: CONFIDENTIAL; Municipality-owned program.
- `MunicipalityScope` — entity; sensitivity: RESTRICTED; Allowed geography/data scope.
- `AggregateReport` — derived; sensitivity: RESTRICTED; No row-level personal data.

## Related API contracts

- `GET /api/v1/municipality/reports` — capability `municipality.report_read`; request `MunicipalityReportQuery`; response `AggregateReportDTO[]`; events `-`
- `POST /api/v1/municipality/programs` — capability `municipality.program_manage`; request `CreateProgramInput`; response `PublicProgramDTO`; events `municipality.program_created`

## Related capabilities

- `municipality.program_manage` — Manage scoped public programs
- `municipality.report_read` — Read approved aggregated scoped reports
- `municipality.raw_data` — Read row-level personal data

## Related routes

- `/app/municipality` — Municipality dashboard / owner `Municipality` / P2

## Visual acceptance references

- `HUD-VIS-031` — set 4, `31_partner_store_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-032` — set 4, `32_product_feed_sync.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-033` — set 4, `33_product_feed_mapping.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-034` — set 4, `34_product_performance_analytics.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-035` — set 4, `35_campaign_manager.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-036` — set 4, `36_create_sponsored_campaign.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-037` — set 4, `37_regional_banner_placement.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-038` — set 4, `38_billing_commission_report.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-039` — set 4, `39_municipality_dashboard.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app`
- `HUD-VIS-040` — set 4, `40_municipality_report_detail.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-231` — set 23, `231_municipality_onboarding.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/onboarding/*`
- `HUD-VIS-232` — set 23, `232_municipality_access_roles.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/municipality`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/municipality/**`
- `tests/municipality/**`
- `docs/execution/P8-006/**`
- `src/app/**`
- `src/components/**`
- `prisma/schema.prisma`
- `prisma/migrations/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm exec prisma validate`
- `pnpm exec prisma generate`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: threshold/suppression.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] Prisma schema validates; migration is reviewable, forward-safe and contains no unrelated schema churn.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-006/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-006/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-006. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-006/HANDOFF.md. Stop after the task.
```


---

# P8-007 — Implement metric/report definitions

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-007` |
| Phase | Phase 8 |
| Epic | Analytics |
| Priority | P2 |
| Dependency wave | 23 |
| Dependencies | P2-001 |
| Owning module | `src/modules/analytics` |
| Risk | MEDIUM |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement metric/report definitions** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P2-001**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-007-implement-metric-report-definitions`.

## Required implementation

1. set27.
2. Use versioned metric definitions.
3. Server events authoritative for transactional/security metrics.
4. Never send child identifiers, message text, exact address or sensitive free text.

## Related canonical entities

- `AnalyticsEvent` — append_only; sensitivity: PSEUDONYMOUS; Versioned schema; no prohibited sensitive payload.
- `MetricDefinition` — versioned_reference; sensitivity: INTERNAL; Owner, formula, dimensions.
- `ReportDefinition` — versioned_reference; sensitivity: INTERNAL; Access and privacy policy.

## Related API contracts

- No API contract is mandated by current map. Add none unless task scope explicitly requires it.

## Related capabilities

- `analytics.product.read` — Read product analytics

## Related routes

- `/app/organizer/analytics` — Analytics / owner `Analytics` / P2
- `/admin/analytics` — Analytics / owner `Analytics` / P2

## Visual acceptance references

- `HUD-VIS-271` — set 27, `271_analytics_overview.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`
- `HUD-VIS-272` — set 27, `272_user_growth.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`
- `HUD-VIS-273` — set 27, `273_engagement_metrics.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`
- `HUD-VIS-274` — set 27, `274_content_performance.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`
- `HUD-VIS-275` — set 27, `275_financial_overview.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`
- `HUD-VIS-276` — set 27, `276_reports_center.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`
- `HUD-VIS-277` — set 27, `277_custom_report_builder.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-278` — set 27, `278_report_preview.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/app/safety/*`
- `HUD-VIS-279` — set 27, `279_scheduled_reports.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`
- `HUD-VIS-280` — set 27, `280_data_export.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/reports`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/analytics/**`
- `tests/analytics/**`
- `docs/execution/P8-007/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: set27.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-007/HANDOFF.md` exists and accurately records the change.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-007/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-007. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-007/HANDOFF.md. Stop after the task.
```


---

# P8-008 — Implement real-backed settings/feature flags/jobs UI

## Metadata

| Field | Value |
|---|---|
| Task ID | `P8-008` |
| Phase | Phase 8 |
| Epic | Platform Ops |
| Priority | P3 |
| Dependency wave | 21 |
| Dependencies | P1-002 |
| Owning module | `src/modules/platform-ops` |
| Risk | MEDIUM_HIGH |
| React UI expected | yes |
| Prisma schema expected | no unless separately approved |
| Agent | Claude Code or Codex |
| Reviewer | Prefer independent other agent/session |

## Objective

Implement **Implement real-backed settings/feature flags/jobs UI** for Huddle according to the Developer Implementation Bible, accepted ADRs and this task contract.

## Read before editing

1. `.ai/HUDDLE_RULES.md`
2. `references/Huddle_Developer_Implementation_Bible_v1.0.md`
3. `references/Huddle_ADR_Register_v1.0.csv`
4. `architecture/Huddle_React_Dual_Agent_Architecture_Addendum_v1.1.md`
5. This task file
6. Relevant matrices listed below

## Preconditions

- Required dependencies merged: **P1-002**.
- Actual repository state inspected; do not assume paths exist.
- One task per branch.
- Branch suggestion: `ai/p8-008-implement-real-backed-settings-feature-flags-job`.

## Required implementation

1. sets26-29; no fake controls.
2. Every setting/flag/job control must be real-backed, permissioned and auditable.
3. Provide rollback path for dangerous changes.
4. Do not expose secrets in UI or logs.
5. No visual-only settings. Every control needs persisted backend behavior, capability, audit and rollback path.

## Related canonical entities

- `FeatureFlag` — aggregate_root; sensitivity: INTERNAL; P2/P3 admin only.
- `BackgroundJob` — entity; sensitivity: INTERNAL; Operational record, not queue implementation itself.
- `OutboxEvent` — append_only; sensitivity: INTERNAL; Transactional domain event.
- `MediaAsset` — aggregate_root; sensitivity: RESTRICTED; Storage key, MIME, size, checksum, variants.
- `IdempotencyKey` — entity; sensitivity: INTERNAL; Mutation result replay protection.

## Related API contracts

- `GET /api/v1/admin/users` — capability `admin.user.manage`; request `AdminUserQuery`; response `Paginated<AdminUserDTO>`; events `-`
- `PATCH /api/v1/admin/users/{userId}/status` — capability `admin.user.manage`; request `UpdateUserStatusInput`; response `AdminUserDTO`; events `admin.user_status_changed`
- `POST /api/v1/admin/users/{userId}/grants` — capability `admin.role.grant`; request `CreateScopedGrantInput`; response `ScopedGrantDTO`; events `admin.grant_created`
- `GET /api/v1/admin/audit-log` — capability `admin.audit.read`; request `AuditLogQuery`; response `Paginated<AuditLogDTO>`; events `-`

## Related capabilities

- `group.manage` — Manage group where owner/admin
- `experience.admin` — Administer any experience
- `admin.user.manage` — Manage user status/roles
- `admin.role.grant` — Grant coarse role/scoped capability
- `admin.audit.read` — Read audit log
- `platform.settings.manage` — Manage platform settings
- `platform.jobs.manage` — Manage background jobs

## Related routes

- No route is mandated by current route map for this task.

## Visual acceptance references

- `HUD-VIS-261` — set 26, `261_platform_settings_overview.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-262` — set 26, `262_general_settings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-263` — set 26, `263_feature_flags.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-264` — set 26, `264_security_settings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-265` — set 26, `265_notification_settings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-266` — set 26, `266_payment_settings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-267` — set 26, `267_localization_settings.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-268` — set 26, `268_integrations.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-269` — set 26, `269_appearance_branding.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-270` — set 26, `270_system_information.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/settings`
- `HUD-VIS-291` — set 29, `291_system_health_overview.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/system`
- `HUD-VIS-292` — set 29, `292_background_jobs.png`, disposition `RECONCILE_BEFORE_IMPLEMENT`, route candidate `/admin/system`

The PNG/artifact is a visual acceptance reference. Behavior, privacy, permissions, data model and API semantics come from the Bible/ADRs/task contract.

## Allowed files

- `src/modules/platform-ops/**`
- `tests/platform-ops/**`
- `docs/execution/P8-008/**`
- `src/app/**`
- `src/components/**`

Files outside these patterns require an explicit task-owner decision before modification.

## Forbidden changes

- `AGENTS.md`
- `CLAUDE.md`
- `.ai/HUDDLE_RULES.md`
- `references/**`
- `pnpm-lock.yaml (unless dependency change is explicitly approved)`
- `package.json (unless dependency change is explicitly approved)`
- `prisma/schema.prisma and prisma/migrations/**`
- `unrelated src/modules/**`
- `generated brand assets`
- `committed secrets or production credentials`

Also forbidden:

- beginning another roadmap task;
- inventing routes, roles, colors or provider commitments;
- bypassing server authorization;
- duplicating messaging/orders/notifications/audit infrastructure;
- creating fake production controls or fabricated production data.

## React implementation contract

- UI is React.
- Next.js App Router only; no Pages Router.
- Prefer React Server Components by default.
- Use Client Components only for actual browser interactivity/state/effects.
- Keep business rules out of React components.
- Use canonical design tokens; no arbitrary Huddle brand values.
- All interactive states must be keyboard accessible.

## Testing requirements

At minimum:

- unit tests for domain invariants introduced by this task;
- authorization negative-path tests for mutations/privileged reads;
- validation tests for malformed input;
- integration tests for persistence/API behavior when applicable;
- React interaction tests for stateful UI when applicable;
- E2E coverage for the primary user journey when the task creates a user-facing flow;
- regression test for each bug found during implementation.

## Required commands

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

If a listed command does not exist because `S0-001` is incomplete, stop and report the dependency violation rather than silently skipping it.

## Acceptance criteria

- [ ] The deliverable is complete: sets26-29; no fake controls.
- [ ] Implementation stays inside the task scope and owning module boundaries.
- [ ] All external inputs are validated at the trusted boundary where applicable.
- [ ] Every mutation is server-authorized; negative authorization paths are tested where applicable.
- [ ] Loading, empty, error and forbidden states are implemented for user-facing surfaces where applicable.
- [ ] No secrets, sensitive free text, exact child location data or prohibited analytics payloads are introduced.
- [ ] All required quality-gate commands pass.
- [ ] `docs/execution/P8-008/HANDOFF.md` exists and accurately records the change.
- [ ] Required audit records are written for privileged/security-sensitive mutations.

## Definition of Done

The task is done only when:

1. code satisfies this contract;
2. all required commands pass;
3. diff contains no unrelated changes;
4. migration/API/capability impacts are documented;
5. handoff file exists;
6. independent review has no unresolved BLOCKER/HIGH findings;
7. agent stops without starting the next task.

## Required handoff

Create:

```text
docs/execution/P8-008/HANDOFF.md
```

Use `handoff-templates/HANDOFF_TEMPLATE.md`.

## Universal agent prompt

```text
Read your repository instruction file (AGENTS.md for Codex or CLAUDE.md for Claude Code), then read .ai/HUDDLE_RULES.md and this task file. Inspect the actual repository. Execute exactly P8-008. Respect dependencies, allowed files, forbidden changes, React/Next.js architecture, authorization, privacy and quality gates. Write docs/execution/P8-008/HANDOFF.md. Stop after the task.
```
