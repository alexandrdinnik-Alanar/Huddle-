# Huddle Master Project Package v2.0

This archive consolidates the current Huddle project source material and engineering deliverables into one package.

## Directory map

### 01_Visual_Source
- `Huddle_Full_Screen_Corpus_Site.zip` — current full visual corpus supplied by the project owner; treat as primary visual source subject to canonical classification.
- `Legacy_Screen_Archive_nested_site.zip` — earlier/legacy screen archive retained for reference.
- `Legacy_Screen_Contact_Sheet.jpg` — earlier visual contact sheet retained for reference.

### 02_Source_of_Truth_Audit
Contains the Source-of-Truth Audit package plus key expanded outputs:
- canonical product map
- conflict register
- candidate route map
- unique artifact inventory

### 03_Developer_Bible
Contains:
- packaged Developer Implementation Bible v1.0
- expanded engineering reference files, including ADR, API, RBAC, route, domain entity, screen registry, roadmap, and decision matrices

### 04_React_Claude_Codex_Execution
Contains:
- React / Claude / Codex Execution Pack v2.0
- expanded task contracts and manifests
- `AGENTS.md` for Codex
- `CLAUDE.md` for Claude Code
- shared AI rules
- task prompts
- independent review and handoff templates
- GitHub bootstrap instructions

### 05_Sprint_0_Source
Original Sprint 0 Codex execution source pack retained as historical/foundation reference.

### 06_Project_Context
Earlier project context retained for traceability.

## Current canonical implementation direction

- Frontend/application foundation: React
- Framework layer: Next.js App Router
- Language: TypeScript strict
- AI-assisted development: one codebase, usable through Claude Code or Codex
- Agent instructions: shared canonical rules with thin `AGENTS.md` and `CLAUDE.md` adapters
- Execution model: one atomic task, one branch, one implementation agent, quality gates, handoff, independent review

## Recommended starting point

1. Read `03_Developer_Bible/Expanded/Huddle_Developer_Implementation_Bible_v1.0.md`.
2. Read `04_React_Claude_Codex_Execution/Expanded/README.md`.
3. Read `04_React_Claude_Codex_Execution/Expanded/NEXT_TASK.md`.
4. Bootstrap the repository using `04_React_Claude_Codex_Execution/Expanded/Huddle_GitHub_Bootstrap_Instructions.md`.
5. Execute task `S0-001` before feature development.

## Source-of-truth caution

Do not implement every image in the visual corpus as a production screen. Use the Screen Implementation Registry and Canonical Domain Selection to distinguish canonical candidates, variants, references, component boards, system states, architecture diagrams, and archived duplicates.
