# Huddle Developer Implementation Bible v1.0

**Дата:** 2026-07-04  
**Статус:** implementation baseline  
**Назначение:** единая техническая инструкция для senior developer, engineering team и Codex-first execution.  
**Источники:** текущий `Site.zip` (63 sets; 628 unique binaries), Huddle Sprint 0 Codex Execution Pack v1.0, Source-of-Truth Audit v1.0, фактический GitHub repository state.

> Этот документ заменяет разработку «по памяти» и по отдельным PNG. Исходные изображения остаются визуальными acceptance references; поведение, данные, безопасность, API, permissions и последовательность реализации определяются этим Bible и приложенными матрицами.

## 0. Executive engineering directive

1. Репозиторий считается **pre-Sprint-0**. Сначала выполнить `S0-001…S0-018` в исходном порядке; до прохождения foundation gates запрещено начинать feature development.
2. Архитектура — **modular monolith**, не набор случайно связанных feature folders и не premature microservices.
3. Все server mutations обязаны проходить authentication, capability authorization, input validation, object-scope checks, audit policy и idempotency where applicable.
4. Нельзя объединять разные commerce-модели в «MarketplaceItem». P2P listings, partner products, orders, payments и affiliate attribution — разные bounded contexts.
5. Нельзя создавать отдельный chat backend для каждого feature. Используется единое messaging core с context policy.
6. Нельзя отдавать municipality raw user data. Reporting — aggregate/de-identified only, с suppression threshold.
7. Family matching и child-related surfaces реализуются privacy-by-default; exact address и child discovery identifiers запрещены.
8. Current target — responsive web. Mobile sets — compact interaction reference; native mobile — отдельная future program.
9. Visual baseline — новый corpus. Set50/51/61 определяют design-system/component/responsive reference; set54 archive duplicate.
10. Любой UI control без реального backend capability, permission, audit trail и error state считается незавершённым и не должен выглядеть functioning in production.

## 1. Source-of-truth hierarchy

| Rank | Source | Authority |
|---|---|---|
| 1 | Approved ADR / this Bible | Architecture, security, behavior, conflict resolution |
| 2 | Actual GitHub implementation | What is really implemented; never infer missing code |
| 3 | Canonical visual sets | UI composition and visible workflow |
| 4 | Set55 flow maps | Cross-screen business-flow reference |
| 5 | Sprint 0 pack | Foundation execution; superseded where this Bible explicitly resolves conflicts |
| 6 | Older/reference sets | Missing states and domain detail only |
| 7 | Legal design screens | UX template only; not legal authority |

### 1.1 Conflict resolution adopted in v1.0

| ADR | Decision | Status |
|---|---|---|
| ADR-001 | Treat GitHub as pre-Sprint-0. No product feature work before S0-001…S0-018 passes quality gates. | ACCEPTED |
| ADR-002 | Modular monolith in one Next.js + TypeScript application. Domain modules own business logic and persistence access; cross-domain calls go through public module services/events. | ACCEPTED |
| ADR-003 | PostgreSQL + Prisma. Supabase Postgres is the initial hosting target. Database remains portable PostgreSQL; vendor-specific features require an adapter/ADR. | ACCEPTED |
| ADR-004 | Supabase Auth is identity provider. Application User is canonical business identity. Email and verified phone identities may link to one User; no custom password store. | ACCEPTED |
| ADR-005 | Hybrid RBAC + capability grants. Coarse RoleKey is stable; fine-grained operational access uses Capability and ScopedGrant. Every server mutation checks capability and object scope. | ACCEPTED |
| ADR-006 | Public pages live outside protected shells; authenticated product under /app; privileged operations under /admin. Role workspaces are subtrees of /app. | ACCEPTED |
| ADR-007 | The current Site.zip corpus is visual baseline. Dedicated canonical sets supersede older domain generations; older sets remain reference for missing states/capabilities. | ACCEPTED |
| ADR-008 | Set50 is canonical for production visual tokens. Sprint 0 token values are deprecated starter values. Canonical colors: Copper #C6683D; Deep Green #163A2F; Ivory #FAF7F2; Sage #A8BFAE; Sand #F1E9D8; Stone #D9D5CC; Charcoal #1F1F1F; Success #2E7D4F; Warning #E2A23B; Error #D64545; Info #4A7BD3. | ACCEPTED |
| ADR-009 | Set50/510 is canonical. Approved Primary Logo may use Huddle wordmark + icon lockup exactly as supplied. Do not recreate or alter geometry. Sprint 0 prohibition on lockup is superseded. | ACCEPTED |
| ADR-010 | Visual metrics follow set50. Use a production-safe system UI stack by default: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif. Do not bundle or redistribute SF Pro font files. H1 32/700, H2 24/600, H3 20/600, body large 16/400, body regular 14/400, body small 12/400. | ACCEPTED |
| ADR-011 | Set50 8pt scale: 4, 8, 16, 24, 32, 64px. Semantic viewports: compact 0–767, medium 768–1199, wide >=1200. Set61 is responsive behavior reference; mobile sets target responsive web first. | ACCEPTED |
| ADR-012 | P0/P1 is responsive web/PWA-capable web. Native mobile is a separate future program. Sets34/43/52/57 are interaction and compact-layout references, not authorization to create native clients in current roadmap. | ACCEPTED |
| ADR-013 | Separate Listings, Catalog & Partner Feed, Orders & Fulfillment, Payments & Settlement, and Affiliate Tracking. Never create a single MarketplaceItem aggregate/table. | ACCEPTED |
| ADR-014 | Use shared Experience aggregate for discoverable scheduled offerings with ExperienceKind EVENT\|ACTIVITY, shared occurrence/registration primitives, and optional EventDetails/ActivityDetails extensions. Community events are Experience with community context. | ACCEPTED |
| ADR-015 | One Conversation/Participant/Message core supports direct, group, listing, booking, event and support contexts. Context policies determine who may create, join, message, attach media, or report. | ACCEPTED |
| ADR-016 | Use an application RealtimeGateway abstraction. Initial adapter may use Supabase Realtime; domain services remain provider-neutral. Persist messages/notifications before broadcast; reconnect and deduplicate by event id. | ACCEPTED |
| ADR-017 | Separate Notification (user-facing intent), NotificationDelivery (per-channel attempt), NotificationPreference, and Template. Channels: in-app, email, push. Adapters are idempotent and retryable. | ACCEPTED |
| ADR-018 | P0 uses PostgreSQL full-text/trigram search behind SearchProvider interface. External search engine may replace/augment later without changing domain APIs. Sensitive/private entities are filtered before result serialization. | ACCEPTED |
| ADR-019 | Build provider-neutral PaymentProvider and SettlementProvider interfaces, immutable internal transaction references, idempotency keys and webhook inbox. No live charges/payouts until merchant-of-record, marketplace liability, KYC and provider ADR are approved. | ACCEPTED_WITH_GATE |
| ADR-020 | Privacy by default: no child exact birthdate in discovery, no exact home address, coarse location only, explicit parent consent for matching, reciprocal connection before unrestricted chat, block/report controls on every connection surface. | ACCEPTED |
| ADR-021 | Only aggregate/de-identified outputs. Default minimum cohort threshold 10, suppress smaller cells, no row-level export, no direct identifiers, scoped municipality geography, auditable export approvals. Threshold is configuration but cannot be disabled in production. | ACCEPTED |
| ADR-022 | Public SEO pages use explicit locale prefixes /en and /no with canonical/hreflang. Authenticated /app routes are locale-neutral and use user preference. No translated slug without canonical mapping. | ACCEPTED |
| ADR-023 | Set56 is canonical moderation operations UI; set22 is reference for unique capabilities. Trust & Safety owns reports/cases/enforcement/appeals. | ACCEPTED |
| ADR-024 | Sets26–29 are P2/P3. Do not ship controls that are visual-only; each admin control requires a functioning backend capability, audit event, permission and rollback path. | ACCEPTED |
| ADR-025 | Set30 is UX/template reference only. Production legal copy must come from separately approved legal source and be versioned. | ACCEPTED |
| ADR-026 | Keep source artifact IDs stable. Archive exact duplicate set54. Reserve absent numbering 221–230. Never renumber source screens. | ACCEPTED |
| ADR-027 | Every privileged or security-sensitive mutation writes AuditLog. Cross-domain side effects use transactional outbox/domain-event pattern; consumers are idempotent. | ACCEPTED |
| ADR-028 | Supabase Storage initial target behind MediaStorage interface. Uploads use signed URLs, MIME/size allowlists, malware scanning hook, image metadata stripping, ownership checks and quarantine state. | ACCEPTED |
| ADR-029 | Use versioned product-event taxonomy. Never send child identifiers, message text, exact address or sensitive free text to analytics. Server events are authoritative for transactions/security. | ACCEPTED |
| ADR-030 | Soft delete only where recovery/audit is required. Financial/audit records are append-only; privacy deletion uses tombstoning/anonymization according to retention policy and legal hold. | ACCEPTED |

## 2. Non-negotiable technical stack and boundaries

| Area | Decision |
|---|---|
| Architecture | Modular monolith |
| Framework | Next.js + TypeScript; use stable project-selected versions, no unreviewed major-version upgrades |
| Database | PostgreSQL |
| ORM | Prisma |
| Auth | Supabase Auth |
| DB hosting | Supabase Postgres initial target |
| Storage | Supabase Storage initial target behind adapter |
| Hosting | Vercel initial target |
| Validation | Schema-first validation pattern; one validated DTO boundary per mutation/query |
| Authorization | RBAC + capability + scoped grant + object policy |
| Audit | Append-only AuditLog for privileged/security-sensitive operations |
| Events | Transactional outbox; idempotent consumers |
| Realtime | RealtimeGateway adapter; persist before broadcast |
| Search | Postgres FTS/trigram behind SearchProvider |
| Payments | Provider-neutral interfaces; live-mode approval gate |
| Localization | Public `/en` and `/no`; app preference-driven |
| Mobile | Responsive web first; native deferred |

## 3. Repository and module architecture

Recommended target structure:

```text
src/
├── app/
│   ├── (public)/                # public + localized SEO surfaces
│   ├── (auth)/                  # login/signup/recovery
│   ├── onboarding/
│   ├── app/                     # authenticated product shell
│   ├── admin/                   # privileged operations
│   └── api/v1/                  # HTTP boundary; thin handlers
├── modules/
│   ├── identity/
│   ├── family/
│   ├── matching/
│   ├── connections/
│   ├── community/
│   ├── groups/
│   ├── messaging/
│   ├── listings/
│   ├── catalog/
│   ├── orders/
│   ├── payments/
│   ├── experiences/
│   ├── services/
│   ├── bookings/
│   ├── advertising/
│   ├── municipality/
│   ├── trust-safety/
│   ├── notifications/
│   ├── support/
│   ├── search/
│   ├── analytics/
│   ├── privacy/
│   ├── platform-ops/
│   ├── media/
├── components/
│   ├── ui/                      # primitives from set50
│   ├── patterns/                # reusable composed patterns from set51
│   └── layout/
├── lib/
│   ├── auth/ permissions/ audit/ validation/ db/ events/
│   └── providers/               # realtime/search/media/payment adapters
└── styles/                      # canonical tokens and global styles
prisma/
├── schema.prisma
├── migrations/
└── seed.ts
```

### 3.1 Module dependency rules

- `app/**` orchestrates UI and calls module public services; route files must not contain domain rules.
- `modules/<domain>/domain` must not import Next.js, React, provider SDKs or another module’s repository implementation.
- Each module exposes a narrow public API from `modules/<domain>/index.ts`. Deep cross-module imports are forbidden.
- Database access is server-only. Client components never import Prisma or service-role Supabase clients.
- Cross-domain effects use explicit application services or domain events/outbox; never hidden ORM hooks.
- Provider SDKs are isolated under `lib/providers` or module infrastructure adapters.
- Circular module dependencies are build failures and must be removed, not worked around.

### 3.2 Server/client rendering rules

- Default to server-rendered/server components for read-heavy pages.
- Use client components only for local interaction, browser APIs, optimistic UI and realtime subscriptions.
- Authorization is never delegated to client rendering. Hidden button ≠ permission control.
- Sensitive DTOs are explicitly serialized; never pass raw Prisma models to client components.
- Public SEO pages must render meaningful content without requiring client JavaScript.

## 4. Design system implementation contract

### 4.1 Canonical colors

| Token | Hex | Usage |
|---|---|---|
| copper | #C6683D | Brand accent; selected emphasis; never long body text on ivory without contrast check |
| deep-green | #163A2F | Primary action, strong text/accent |
| ivory | #FAF7F2 | Primary warm background |
| sage | #A8BFAE | Secondary/success-adjacent surfaces; not semantic success |
| sand | #F1E9D8 | Secondary neutral surface |
| stone | #D9D5CC | Borders/dividers/disabled surfaces |
| charcoal | #1F1F1F | Primary text |
| success | #2E7D4F | Semantic success only |
| warning | #E2A23B | Semantic warning only |
| error | #D64545 | Semantic error/destructive only |
| info | #4A7BD3 | Semantic information only |

### 4.2 Typography

| Style | Size | Weight | Tracking |
|---|---|---|---|
| H1 | 32px | 700 | -0.5px |
| H2 | 24px | 600 | -0.3px |
| H3 | 20px | 600 | 0 |
| Body Large | 16px | 400 | 0 |
| Body Regular | 14px | 400 | 0 |
| Body Small | 12px | 400 | 0 |

Production font stack: `ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`. Do not commit or redistribute SF Pro font files. Typography visual metrics should remain aligned to set50.

### 4.3 Spacing, grid and responsive

- Canonical spacing scale: `4, 8, 16, 24, 32, 64px`. Use semantic aliases (`space-1…space-6`) rather than arbitrary values.
- Compact: `0–767px`; medium: `768–1199px`; wide: `>=1200px`. Components respond semantically; do not implement page-specific random breakpoints.
- Bottom navigation is compact-only; wide app shell uses header/sidebar patterns defined by set39/set61.
- Safe-area insets must be honored for compact bottom navigation and fixed actions.

### 4.4 Component ownership

- Set50: tokens/primitives. Set51: composed component reference. Set54: archive duplicate.
- Required primitives: Button, IconButton, Input, Textarea, Select, Checkbox, Radio, Switch, FormField, Badge, Avatar, Card, Dialog, Drawer, DropdownMenu, Tabs, Toast, Tooltip, Skeleton, EmptyState, ErrorState, Pagination.
- Every interactive primitive must support keyboard operation, focus-visible, disabled, loading, error and reduced-motion behavior where applicable.

## 5. Canonical route architecture

The canonical route map contains **105 route rows**. Full matrix: `Huddle_Canonical_Route_Map_v1.0.csv`.

| Surface | Route | Domain | Priority | Sources |
|---|---|---|---|---|
| public | / | Marketing | P0 | set1 |
| public | /marketplace | Marketplace discovery | P0 | set36/49 |
| public | /marketplace/listings/[listingId] | P2P listing | P0 | set36 |
| public | /marketplace/products/[productId] | Product catalog | P1 | set49 |
| public | /events | Events discovery | P0 | set37 |
| public | /events/[eventId] | Event detail | P0 | set37 |
| public | /activities | Activities discovery | P0 | set18/37 |
| public | /activities/[activityId] | Activity detail | P1 | set3/18 |
| public | /services | Services discovery | P1 | set40/47 |
| public | /services/[serviceId] | Service detail | P1 | set40/47 |
| public | /experts/[expertId] | Expert profile | P1 | set21/40 |
| public | /safety | Safety | P0 | Sprint0/set52 |
| public | /privacy | Privacy | P0 | Sprint0/set30/60 |
| public | /terms | Terms | P0 | set30 |
| public | /community-guidelines | Guidelines | P0 | set30/35/38 |
| public | /family-guides/[stage] | Age-stage guides | P1 | Sprint0/set42 |
| public | /seasonal-guides/[slug] | Seasonal guides | P1 | Sprint0/set42 |
| public | /cities/[citySlug] | City landing | P1 | set41/59 |
| public | /cities/[citySlug]/activities | City activities SEO | P1 | set41/59 |
| public | /cities/[citySlug]/events | City events SEO | P1 | set41/59 |
| public | /cities/[citySlug]/marketplace | City marketplace SEO | P1 | set41/59 |
| public | /cities/[citySlug]/services | City services SEO | P1 | set41/59 |
| auth | /signup | Sign up | P0 | set35 + Sprint0 |
| auth | /login | Login | P0 | set35 + Sprint0 |
| auth | /forgot-password | Password recovery | P0 | set35 + Sprint0 |
| auth | /verify | Identity verification | P0 | set35 + Sprint0 |
| auth | /onboarding | Onboarding entry | P0 | set35 + Sprint0 |
| auth | /onboarding/family | Family profile | P0 | set35 + Sprint0 |
| auth | /onboarding/children | Children | P0 | set35 + Sprint0 |
| auth | /onboarding/interests | Interests | P0 | set35 + Sprint0 |
| auth | /onboarding/location | Location/privacy | P0 | set35 + Sprint0 |
| auth | /onboarding/consent | Consent | P0 | set35 + Sprint0 |
| app | /app | Home shell | P0 | set39 |
| app | /app/search | Global search | P0 | Sprint0/set39 |
| app | /app/saved | Saved hub | P0 | Sprint0/set39 |
| app | /app/notifications | Notifications | P0 | set39/44 |
| app | /app/messages | Messaging inbox | P0 | set44 |
| app | /app/messages/[conversationId] | Conversation | P0 | set44 |
| app | /app/account | Account | P0 | Sprint0/set46 |
| app | /app/settings | Settings | P0 | set60 |
| app | /app/family | Family profile | P0 | set46 |
| app | /app/family/members | Family members | P0 | set7/46 |
| app | /app/connections | Connections | P0 | set46 |
| app | /app/matching | Family matching | P1 | set2/55 |
| app | /app/community | Community home | P0 | set38/45 |
| app | /app/groups | Groups directory | P1 | set53 |
| app | /app/groups/[groupId] | Group detail | P1 | set53 |
| app | /app/calendar | Family calendar | P1 | set6/10 |
| app | /app/marketplace | Marketplace | P0 | Sprint0/set36 |
| app | /app/marketplace/listings | My listings | P1 | set13 |
| app | /app/orders | Orders | P1 | set43/49 |
| app | /app/events | Events | P0 | Sprint0/set37 |
| app | /app/activities | Activities | P0 | set18/37 |
| app | /app/services | Services | P1 | set40/47 |
| app | /app/bookings | Bookings | P1 | set40/47 |
| app | /app/wallet | Wallet | P1 | set8 |
| app | /app/privacy | Privacy center | P0 | Sprint0/set60 |
| app | /app/safety | Safety center | P0 | Sprint0/set52 |
| app | /app/support | Support | P1 | set8 |
| app-role | /app/seller | Seller dashboard | P1 | set13 |
| app-role | /app/seller/listings | Seller listings | P1 | set13 |
| app-role | /app/seller/inquiries | Buyer inquiries | P1 | set13 |
| app-role | /app/seller/orders | Seller reservations/orders | P1 | set12/13 |
| app-role | /app/seller/payouts | Seller payouts | P2 | set6/8 |
| app-role | /app/organizer | Organizer dashboard | P1 | set3/57 |
| app-role | /app/organizer/events | Organizer events | P1 | set17 |
| app-role | /app/organizer/activities | Organizer activities | P1 | set18 |
| app-role | /app/organizer/registrations | Registrations | P1 | set16/17 |
| app-role | /app/organizer/check-in | Check-in | P1 | set16/57 |
| app-role | /app/organizer/analytics | Analytics | P2 | set3/17/18 |
| app-role | /app/expert | Expert dashboard | P1 | set21/57 |
| app-role | /app/expert/profile | Expert profile | P1 | set21 |
| app-role | /app/expert/services | Service packages | P1 | set21 |
| app-role | /app/expert/availability | Availability | P1 | set21/57 |
| app-role | /app/expert/bookings | Booking requests | P1 | set21/57 |
| app-role | /app/partner | Partner dashboard | P2 | set4/57 |
| app-role | /app/partner/store | Store profile | P2 | set14 |
| app-role | /app/partner/feed | Product feed | P2 | set14 |
| app-role | /app/partner/campaigns | Campaigns | P2 | set15 |
| app-role | /app/partner/billing | Billing/commission | P2 | set4 |
| app-role | /app/municipality | Municipality dashboard | P2 | set4/23 |
| app-role | /app/municipality/programs | Public programs | P2 | set23 |
| app-role | /app/municipality/reports | Reporting | P2 | set23/55 |
| app-role | /app/municipality/governance | Data scope | P0 | set23/63 |
| admin | /admin | Admin dashboard | P0 | Sprint0/set25 |
| admin | /admin/users | User management | P0 | Sprint0/set25 |
| admin | /admin/listings | Listing moderation | P0 | Sprint0/set25 |
| admin | /admin/events | Event administration | P1 | Sprint0/set25 |
| admin | /admin/reports | Reports | P1 | Sprint0/set27 |
| admin | /admin/audit-log | Audit log | P0 | Sprint0/set22/56 |
| admin | /admin/moderation | Moderation dashboard | P0 | set56 |
| admin | /admin/moderation/reports | Reports queue | P0 | set22/56 |
| admin | /admin/moderation/appeals | Appeals | P0 | set22/56 |
| admin | /admin/approvals | Supply approvals | P1 | set25 |
| admin | /admin/finance | Finance overview | P2 | set31/62 |
| admin | /admin/finance/refunds | Refunds | P2 | set31/62 |
| admin | /admin/finance/disputes | Disputes | P2 | set31/62 |
| admin | /admin/finance/commissions | Commissions | P2 | set31/62 |
| admin | /admin/finance/payouts | Payouts | P2 | set31/62 |
| admin | /admin/finance/invoices | Invoices | P2 | set31/62 |
| admin | /admin/support | Helpdesk | P2 | set28 |
| admin | /admin/settings | Platform settings | P2 | set26 |
| admin | /admin/system | System operations | P3 | set29 |
| admin | /admin/privacy | Privacy governance | P0 | set63 |
| admin | /admin/analytics | Analytics | P2 | set27 |

### 5.1 Route rules

- Public resources use stable semantic slugs and canonical IDs where collision-safe routing is required.
- `/app` requires authenticated User and completed minimum onboarding state unless route is explicitly onboarding-safe.
- `/admin` requires capability checks; `ADMIN` role alone does not imply every admin capability.
- Role switcher changes active context only; it never grants a role or permission.
- Resource routes return 404 when existence disclosure is unsafe; use 403 only when disclosure is acceptable.

## 6. Domain model and bounded contexts

The entity catalog defines **100 entities/reference records**. Full matrix: `Huddle_Domain_Entity_Catalog_v1.0.csv`.

### 6.1 Identity & Access

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| User | aggregate_root | CONFIDENTIAL | ACTIVE\|SUSPENDED\|DEACTIVATED\|DELETED | AuthIdentity, UserRole, UserPreference |
| AuthIdentity | entity | RESTRICTED | ACTIVE\|REVOKED | User |
| Role | reference | INTERNAL | ACTIVE | UserRole |
| UserRole | association | INTERNAL | ACTIVE\|REVOKED | User, Role |
| Capability | reference | INTERNAL | ACTIVE | ScopedGrant |
| ScopedGrant | entity | RESTRICTED | ACTIVE\|REVOKED\|EXPIRED | User, Capability, Organization |
| Organization | aggregate_root | CONFIDENTIAL | PENDING\|ACTIVE\|SUSPENDED\|CLOSED | OrganizationMembership |
| OrganizationMembership | association | CONFIDENTIAL | INVITED\|ACTIVE\|SUSPENDED\|LEFT | Organization, User |
| UserPreference | entity | CONFIDENTIAL | ACTIVE | User |
| AuditLog | append_only | RESTRICTED | IMMUTABLE | User, Organization |
- **Invariant:** Provider identity is not the business primary key.
- **Invariant:** Role context cannot elevate permissions.
- **Invariant:** Role/grant changes are audited and revoke server-side access immediately.

### 6.2 Family

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| FamilyProfile | aggregate_root | RESTRICTED | ACTIVE\|HIDDEN\|DELETED | User, FamilyMember, FamilyVisibilityRule |
| FamilyMember | entity | HIGHLY_RESTRICTED | ACTIVE\|REMOVED\|ANONYMIZED | FamilyProfile |
| Interest | reference | PUBLIC | ACTIVE | FamilyInterest |
| FamilyInterest | association | CONFIDENTIAL | ACTIVE | FamilyProfile, Interest |
| FamilyVisibilityRule | entity | RESTRICTED | ACTIVE | FamilyProfile |
- **Invariant:** Discovery DTOs never expose exact address or unrestricted child attributes.
- **Invariant:** Only authorized parent/guardian manages child/member records.
- **Invariant:** Deletion/anonymization follows retention and safety legal-hold policy.

### 6.3 Connections & Matching

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| MatchPreference | aggregate_root | RESTRICTED | ACTIVE\|PAUSED | FamilyProfile |
| MatchCandidateSnapshot | derived | RESTRICTED | EPHEMERAL | FamilyProfile |
| ConnectionRequest | aggregate_root | CONFIDENTIAL | PENDING\|ACCEPTED\|DECLINED\|CANCELLED\|EXPIRED | User, FamilyProfile |
| Connection | aggregate_root | CONFIDENTIAL | ACTIVE\|BLOCKED\|REMOVED | User |
| BlockRelation | entity | RESTRICTED | ACTIVE\|REVOKED | User |
- **Invariant:** Matching requires explicit opt-in.
- **Invariant:** Blocked users are excluded before candidate scoring/result serialization.
- **Invariant:** Connection does not override field-level visibility rules.

### 6.4 Community

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Group | aggregate_root | CONFIDENTIAL | DRAFT\|ACTIVE\|ARCHIVED\|DELETED | GroupMembership, Post, Experience |
| GroupMembership | association | CONFIDENTIAL | PENDING\|ACTIVE\|MUTED\|BANNED\|LEFT | Group, User |
| Post | aggregate_root | CONFIDENTIAL | DRAFT\|PUBLISHED\|HIDDEN\|DELETED | Comment, Reaction, MediaAsset |
| Comment | entity | CONFIDENTIAL | PUBLISHED\|HIDDEN\|DELETED | Post, User |
| Reaction | association | CONFIDENTIAL | ACTIVE\|REMOVED | User, Post/Comment |
| Poll | entity | CONFIDENTIAL | OPEN\|CLOSED | Post, PollOption, PollVote |
- **Invariant:** Visibility is checked for every read, not only list queries.
- **Invariant:** Moderated/removed content remains audit-addressable but is not user-visible.

### 6.5 Messaging

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Conversation | aggregate_root | RESTRICTED | ACTIVE\|ARCHIVED\|LOCKED | ConversationParticipant, Message |
| ConversationParticipant | association | RESTRICTED | ACTIVE\|LEFT\|REMOVED\|BLOCKED | Conversation, User |
| Message | aggregate_root | HIGHLY_RESTRICTED | SENT\|EDITED\|DELETED\|REMOVED | Conversation, MediaAsset |
| MessageMention | association | RESTRICTED | ACTIVE | Message, User |
| MessageReceipt | entity | RESTRICTED | DELIVERED\|READ | Message, User |
- **Invariant:** Message authorization checks active participation, block relations and context policy.
- **Invariant:** Persist before realtime broadcast.
- **Invariant:** Message text is excluded from analytics and ordinary logs.

### 6.6 Listings

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Listing | aggregate_root | CONFIDENTIAL | DRAFT\|PENDING_REVIEW\|PUBLISHED\|RESERVED\|SOLD\|ARCHIVED\|REJECTED | User, ListingMedia, Category |
| ListingMedia | association | CONFIDENTIAL | PENDING\|READY\|QUARANTINED\|DELETED | Listing, MediaAsset |
| ListingInquiry | aggregate_root | CONFIDENTIAL | OPEN\|CLOSED\|BLOCKED | Listing, Conversation |
| ListingReservation | aggregate_root | CONFIDENTIAL | PENDING\|CONFIRMED\|CANCELLED\|EXPIRED | Listing, User |
- **Invariant:** Listing lifecycle is separate from Product lifecycle.
- **Invariant:** Publish requires required fields, ownership and moderation policy.
- **Invariant:** Reservation is concurrency-safe.

### 6.7 Catalog & Partner Feed

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Partner | aggregate_root | CONFIDENTIAL | PENDING\|ACTIVE\|SUSPENDED\|CLOSED | Organization, Store, PartnerFeed |
| Store | aggregate_root | CONFIDENTIAL | DRAFT\|ACTIVE\|SUSPENDED | Partner, Product |
| Product | aggregate_root | CONFIDENTIAL | DRAFT\|ACTIVE\|OUT_OF_STOCK\|ARCHIVED | Store, ProductVariant |
| ProductVariant | entity | CONFIDENTIAL | ACTIVE\|INACTIVE | Product |
| PartnerFeed | aggregate_root | RESTRICTED | ACTIVE\|PAUSED\|ERROR | Partner, FeedSyncRun |
| FeedSyncRun | entity | INTERNAL | QUEUED\|RUNNING\|SUCCEEDED\|FAILED\|PARTIAL | PartnerFeed |
| AffiliateClick | append_only | CONFIDENTIAL | RECORDED | Product, User? |
- **Invariant:** Partner feeds cannot directly bypass approval/policy rules.
- **Invariant:** Feed sync is idempotent and records source lineage.

### 6.8 Orders & Fulfillment

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Cart | aggregate_root | CONFIDENTIAL | ACTIVE\|CONVERTED\|ABANDONED\|EXPIRED | CartItem |
| CartItem | entity | CONFIDENTIAL | ACTIVE\|REMOVED | Cart, ProductVariant |
| Order | aggregate_root | RESTRICTED | PENDING_PAYMENT\|PAID\|PROCESSING\|SHIPPED\|READY_PICKUP\|COMPLETED\|CANCELLED\|REFUNDED\|DISPUTED | OrderItem, Payment, Shipment |
| OrderItem | entity | RESTRICTED | ACTIVE\|CANCELLED\|REFUNDED | Order, ProductVariant |
| Shipment | aggregate_root | RESTRICTED | PENDING\|SHIPPED\|IN_TRANSIT\|DELIVERED\|FAILED\|RETURNED | Order |
| ReturnRequest | aggregate_root | RESTRICTED | REQUESTED\|APPROVED\|REJECTED\|RECEIVED\|REFUNDED\|CLOSED | OrderItem |
- **Invariant:** Order totals are server snapshots.
- **Invariant:** Order state transitions are explicit and validated.
- **Invariant:** No client-controlled paid/fulfilled state.

### 6.9 Payments & Settlement

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Payment | aggregate_root | RESTRICTED | CREATED\|REQUIRES_ACTION\|AUTHORIZED\|CAPTURED\|FAILED\|CANCELLED\|REFUNDED\|DISPUTED | Order, PaymentAttempt |
| PaymentAttempt | append_only | RESTRICTED | CREATED\|SUCCEEDED\|FAILED | Payment |
| Refund | aggregate_root | RESTRICTED | REQUESTED\|APPROVED\|PROCESSING\|SUCCEEDED\|FAILED\|REJECTED | Payment |
| Dispute | aggregate_root | RESTRICTED | OPEN\|EVIDENCE_REQUIRED\|WON\|LOST\|CLOSED | Payment |
| Payout | aggregate_root | RESTRICTED | PENDING\|ON_HOLD\|APPROVED\|PROCESSING\|PAID\|FAILED | Organization/User |
| Commission | append_only | RESTRICTED | ACCRUED\|ADJUSTED\|SETTLED | Order, Partner |
| Invoice | aggregate_root | RESTRICTED | DRAFT\|ISSUED\|PAID\|VOID\|OVERDUE | Organization |
| WebhookInbox | append_only | RESTRICTED | RECEIVED\|PROCESSED\|FAILED\|IGNORED | Provider |
- **Invariant:** No card PAN/CVC storage.
- **Invariant:** Provider webhooks are verified, deduplicated and replay-safe.
- **Invariant:** Financial adjustments are append-only or compensating entries.

### 6.10 Events & Activities

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Experience | aggregate_root | CONFIDENTIAL | DRAFT\|PENDING_REVIEW\|PUBLISHED\|CANCELLED\|COMPLETED\|ARCHIVED | ExperienceOccurrence, Registration |
| EventDetails | entity | CONFIDENTIAL | ACTIVE | Experience |
| ActivityDetails | entity | CONFIDENTIAL | ACTIVE | Experience |
| ExperienceOccurrence | aggregate_root | CONFIDENTIAL | SCHEDULED\|CANCELLED\|COMPLETED | Experience |
| Registration | aggregate_root | RESTRICTED | PENDING\|CONFIRMED\|WAITLISTED\|CANCELLED\|ATTENDED\|NO_SHOW | ExperienceOccurrence, User/FamilyMember |
| Ticket | entity | RESTRICTED | ACTIVE\|USED\|VOID | Registration |
| CheckIn | append_only | RESTRICTED | RECORDED\|REVERSED | Registration, User |
- **Invariant:** Occurrence timezone is explicit.
- **Invariant:** Capacity changes cannot invalidate confirmed registrations without a defined policy.
- **Invariant:** QR/check-in tokens are opaque and revocable.

### 6.11 Services & Experts

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| ExpertProfile | aggregate_root | CONFIDENTIAL | DRAFT\|PENDING_REVIEW\|ACTIVE\|SUSPENDED | User, ServiceOffering |
| ServiceOffering | aggregate_root | CONFIDENTIAL | DRAFT\|ACTIVE\|PAUSED\|ARCHIVED | ExpertProfile, AvailabilityRule |
| AvailabilityRule | entity | CONFIDENTIAL | ACTIVE\|INACTIVE | ServiceOffering |
| Booking | aggregate_root | RESTRICTED | REQUESTED\|CONFIRMED\|DECLINED\|CANCELLED\|COMPLETED\|NO_SHOW | ServiceOffering, User |
| Review | aggregate_root | CONFIDENTIAL | PUBLISHED\|HIDDEN\|DELETED | Booking, User |
- **Invariant:** Booking slots are concurrency-safe.
- **Invariant:** Only completed eligible bookings may produce verified reviews.

### 6.12 Advertising

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Campaign | aggregate_root | CONFIDENTIAL | DRAFT\|PENDING_REVIEW\|ACTIVE\|PAUSED\|COMPLETED\|REJECTED | Creative, Placement |
| Creative | entity | CONFIDENTIAL | DRAFT\|APPROVED\|REJECTED\|ARCHIVED | Campaign, MediaAsset |
| Placement | reference | INTERNAL | ACTIVE\|INACTIVE | Campaign |
- **Invariant:** Creative approval is separate from campaign activation.
- **Invariant:** Targeting may not use prohibited child/sensitive attributes.

### 6.13 Municipality

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| PublicProgram | aggregate_root | CONFIDENTIAL | DRAFT\|PUBLISHED\|ARCHIVED | Organization, Experience? |
| MunicipalityScope | entity | RESTRICTED | ACTIVE | Organization |
| AggregateReport | derived | RESTRICTED | GENERATING\|READY\|SUPPRESSED\|EXPIRED | ReportDefinition |
- **Invariant:** No raw personal row access.
- **Invariant:** Cohorts below threshold are suppressed.
- **Invariant:** Geography scope is enforced server-side.

### 6.14 Trust & Safety

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| SafetyReport | aggregate_root | HIGHLY_RESTRICTED | SUBMITTED\|TRIAGED\|IN_REVIEW\|RESOLVED\|CLOSED | Reporter, target, ModerationCase |
| ModerationCase | aggregate_root | HIGHLY_RESTRICTED | OPEN\|ASSIGNED\|INVESTIGATING\|DECIDED\|CLOSED | SafetyReport, EnforcementAction |
| EnforcementAction | aggregate_root | HIGHLY_RESTRICTED | PROPOSED\|ACTIVE\|REVOKED\|EXPIRED | ModerationCase, User/Content |
| Appeal | aggregate_root | HIGHLY_RESTRICTED | SUBMITTED\|IN_REVIEW\|UPHELD\|OVERTURNED\|CLOSED | EnforcementAction |
- **Invariant:** Case access is least privilege.
- **Invariant:** Reporter identity is protected.
- **Invariant:** Enforcement and appeal actions are auditable.

### 6.15 Notifications

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| Notification | aggregate_root | CONFIDENTIAL | CREATED\|READ\|ARCHIVED | User, NotificationDelivery |
| NotificationDelivery | entity | RESTRICTED | PENDING\|SENDING\|DELIVERED\|FAILED\|SUPPRESSED | Notification |
| NotificationPreference | aggregate_root | CONFIDENTIAL | ACTIVE | User |
| NotificationTemplate | versioned_reference | INTERNAL | DRAFT\|ACTIVE\|RETIRED | NotificationDelivery |
- **Invariant:** Notification intent is distinct from delivery attempts.
- **Invariant:** Preferences and mandatory security messages are handled explicitly.

### 6.16 Support

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| SupportTicket | aggregate_root | RESTRICTED | OPEN\|PENDING_USER\|PENDING_INTERNAL\|RESOLVED\|CLOSED | TicketReply |
| TicketReply | entity | RESTRICTED | PUBLISHED\|REDACTED | SupportTicket, User |
| KnowledgeBaseArticle | aggregate_root | PUBLIC | DRAFT\|PUBLISHED\|ARCHIVED | User |
- **Invariant:** Internal notes never leak into user-visible replies.
- **Invariant:** Sensitive attachments use restricted media policy.

### 6.17 Analytics & Reporting

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| AnalyticsEvent | append_only | PSEUDONYMOUS | RECORDED | User? |
| MetricDefinition | versioned_reference | INTERNAL | DRAFT\|ACTIVE\|RETIRED | ReportDefinition |
| ReportDefinition | versioned_reference | INTERNAL | DRAFT\|ACTIVE\|RETIRED | MetricDefinition |
- **Invariant:** Schema is versioned.
- **Invariant:** Sensitive free text and child identifiers are prohibited.
- **Invariant:** Server events are authoritative for transaction/security outcomes.

### 6.18 Privacy & Governance

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| ConsentRecord | append_only | RESTRICTED | GRANTED\|WITHDRAWN\|EXPIRED | User, PolicyVersion |
| PolicyVersion | versioned_reference | PUBLIC | DRAFT\|ACTIVE\|RETIRED | ConsentRecord |
| DataRequest | aggregate_root | HIGHLY_RESTRICTED | SUBMITTED\|VERIFYING\|IN_PROGRESS\|READY\|COMPLETED\|REJECTED\|CANCELLED | User |
| RetentionPolicy | versioned_reference | RESTRICTED | DRAFT\|ACTIVE\|RETIRED | Data class |
| AnonymizationRule | versioned_reference | RESTRICTED | DRAFT\|ACTIVE\|RETIRED | Data class |
| ExportApproval | aggregate_root | HIGHLY_RESTRICTED | REQUESTED\|APPROVED\|REJECTED\|EXPIRED | User, Organization |
| PrivacyIncident | aggregate_root | HIGHLY_RESTRICTED | OPEN\|CONTAINED\|INVESTIGATING\|REMEDIATED\|CLOSED | User? |
- **Invariant:** Consent is append-only evidence, not a mutable boolean.
- **Invariant:** Data requests require identity verification.
- **Invariant:** Retention/anonymization changes are versioned and audited.

### 6.19 Platform Operations

| Entity | Kind | Sensitivity | Lifecycle | Key relations |
|---|---|---|---|---|
| FeatureFlag | aggregate_root | INTERNAL | DRAFT\|ACTIVE\|DISABLED\|ARCHIVED | FlagRule |
| BackgroundJob | entity | INTERNAL | QUEUED\|RUNNING\|SUCCEEDED\|FAILED\|DEAD | OutboxEvent |
| OutboxEvent | append_only | INTERNAL | PENDING\|PUBLISHED\|FAILED | Aggregate |
| MediaAsset | aggregate_root | RESTRICTED | PENDING\|SCANNING\|READY\|QUARANTINED\|DELETED | User/context |
| IdempotencyKey | entity | INTERNAL | ACTIVE\|EXPIRED | Request |
- **Invariant:** No fake operational controls.
- **Invariant:** Jobs/events are idempotent and observable.
- **Invariant:** Secrets are stored by secret reference, never plain DB/UI values.

## 7. Identity, authentication and onboarding

### 7.1 Identity model

- `User` is canonical domain identity. `AuthIdentity` maps Supabase subject(s) to `User`.
- A user may have verified email and phone identities; account linking requires proof of both current session and target identity challenge.
- Never merge accounts solely because email/phone strings match without verified linking workflow.
- `UserStatus` changes are enforced centrally: suspended/deactivated users cannot bypass through alternate role context.

### 7.2 Canonical onboarding state machine

`WELCOME → ROLE_SELECTED → ACCOUNT_CREATED → PHONE_VERIFIED? → FAMILY_PROFILE → CHILDREN? → INTERESTS → LOCATION_POLICY → GUIDELINES_ACCEPTED → COMPLETE`

- Steps are resumable and server-persisted.
- Optional steps must be explicit; UI must not fake completion.
- Location permission denial must preserve core product access and allow manual coarse location.
- Guidelines acceptance stores policy version and timestamp.
- Onboarding completion does not grant supply/admin privileges.

## 8. Authorization model

The capability matrix contains **61 capabilities**. `Y` = allowed by role baseline; `S` = scope/object-policy required; `N` = denied; `I` = internal service only.

| Capability | Domain | Description | GUEST | PARENT | SELLER | ORGANIZER | EXPERT | PARTNER | MUNICIPALITY_USER | MODERATOR | ADMIN | SUPER_ADMIN | SYSTEM |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| public.read | Public | Read public content | Y | Y | Y | Y | Y | Y | Y | Y | Y | Y | Y |
| profile.read_self | Identity | Read own profile | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| profile.update_self | Identity | Update own profile | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| family.manage_self | Family | Manage own family profile/members | N | Y | N | N | N | N | N | N | S | S | N |
| family.view_connected | Family | View visibility-filtered connected family | N | S | N | N | N | N | N | S | S | S | N |
| matching.manage_preferences | Matching | Manage own matching preferences | N | Y | N | N | N | N | N | N | S | S | N |
| matching.view_candidates | Matching | View privacy-filtered candidates | N | S | N | N | N | N | N | S | S | S | N |
| connection.request | Connections | Send connection request | N | S | S | S | S | N | N | N | N | N | N |
| connection.block | Connections | Block/mute a user | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| community.post.create | Community | Create community post | N | S | S | S | S | S | N | S | S | S | N |
| community.post.moderate | Community | Moderate community content | N | N | N | N | N | N | N | S | Y | Y | N |
| group.create | Groups | Create group | N | S | N | S | S | N | N | N | S | S | N |
| group.manage | Groups | Manage group where owner/admin | N | S | N | S | S | N | N | S | S | S | N |
| message.send | Messaging | Send message in authorized conversation | N | S | S | S | S | S | S | S | S | S | N |
| message.moderate | Messaging | Review reported message content | N | N | N | N | N | N | N | S | Y | Y | N |
| listing.create | Listings | Create own P2P listing | N | S | Y | N | N | N | N | N | S | S | N |
| listing.manage_own | Listings | Manage own listing | N | S | Y | N | N | N | N | N | S | S | N |
| listing.moderate | Listings | Approve/remove listing | N | N | N | N | N | N | N | S | Y | Y | N |
| catalog.manage_partner | Catalog | Manage scoped partner catalog/feed | N | N | N | N | N | S | N | N | S | S | I |
| catalog.approve | Catalog | Approve partner/store/product feed | N | N | N | N | N | N | N | N | S | Y | N |
| order.create | Orders | Create order | N | S | S | S | S | N | N | N | S | S | N |
| order.read_own | Orders | Read own buyer order | N | Y | S | S | S | N | N | N | S | S | N |
| order.fulfill | Orders | Fulfill scoped seller/partner order | N | N | S | N | N | S | N | N | S | S | N |
| order.refund_request | Orders | Request refund | N | S | S | N | N | N | N | N | S | S | N |
| finance.refund_execute | Finance | Execute approved refund | N | N | N | N | N | N | N | N | S | Y | I |
| finance.dispute_manage | Finance | Manage payment disputes | N | N | N | N | N | N | N | N | S | Y | N |
| finance.payout_review | Finance | Review payout | N | N | N | N | N | N | N | N | S | Y | N |
| finance.ledger_read | Finance | Read financial operations ledger | N | N | N | N | N | N | N | N | S | Y | N |
| experience.register | Experiences | Register self/family for experience | N | S | S | S | S | N | N | N | S | S | N |
| experience.create | Experiences | Create organizer-owned event/activity | N | N | N | Y | N | N | N | N | S | S | N |
| experience.manage_own | Experiences | Manage own experience | N | N | N | Y | N | N | N | N | S | S | N |
| experience.checkin | Experiences | Check in registered participant | N | N | N | S | N | N | N | N | S | S | N |
| experience.admin | Experiences | Administer any experience | N | N | N | N | N | N | N | N | S | Y | N |
| service.book | Services | Book service | N | S | S | S | S | N | N | N | S | S | N |
| service.manage_own | Services | Manage own service offering | N | N | N | N | Y | N | N | N | S | S | N |
| booking.manage_provider | Bookings | Manage provider bookings | N | N | N | N | S | N | N | N | S | S | N |
| booking.manage_customer | Bookings | Manage own customer booking | N | S | S | S | N | N | N | N | S | S | N |
| partner.manage_org | Partner | Manage partner organization | N | N | N | N | N | S | N | N | S | S | N |
| municipality.program_manage | Municipality | Manage scoped public programs | N | N | N | N | N | N | S | N | S | S | N |
| municipality.report_read | Municipality | Read approved aggregated scoped reports | N | N | N | N | N | N | S | N | S | S | N |
| municipality.raw_data | Municipality | Read row-level personal data | N | N | N | N | N | N | N | N | N | N | N |
| safety.report.create | Safety | Create safety report | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| safety.case.read | Safety | Read assigned moderation case | N | N | N | N | N | N | N | S | Y | Y | N |
| safety.case.decide | Safety | Issue moderation decision | N | N | N | N | N | N | N | S | Y | Y | N |
| safety.enforcement.manage | Safety | Manage enforcement action | N | N | N | N | N | N | N | S | Y | Y | N |
| safety.appeal.review | Safety | Review appeal | N | N | N | N | N | N | N | S | Y | Y | N |
| support.ticket.create | Support | Create support ticket | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| support.ticket.manage | Support | Manage assigned support ticket | N | N | N | N | N | N | N | N | S | Y | N |
| notification.preference.manage | Notifications | Manage own notification preferences | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| analytics.product.read | Analytics | Read product analytics | N | N | N | N | N | N | N | N | S | Y | N |
| privacy.consent.manage_self | Privacy | Manage own consent records | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| privacy.request.create | Privacy | Create own data request | N | Y | Y | Y | Y | Y | Y | Y | Y | Y | N |
| privacy.request.process | Privacy | Process privacy request | N | N | N | N | N | N | N | N | S | Y | N |
| privacy.policy.manage | Privacy | Manage retention/anonymization rules | N | N | N | N | N | N | N | N | N | S | N |
| privacy.export.approve | Privacy | Approve governed export | N | N | N | N | N | N | N | N | S | Y | N |
| admin.user.manage | Admin | Manage user status/roles | N | N | N | N | N | N | N | N | S | Y | N |
| admin.role.grant | Admin | Grant coarse role/scoped capability | N | N | N | N | N | N | N | N | S | Y | N |
| admin.audit.read | Admin | Read audit log | N | N | N | N | N | N | N | S | Y | Y | N |
| platform.settings.manage | Platform | Manage platform settings | N | N | N | N | N | N | N | N | N | Y | N |
| platform.jobs.manage | Platform | Manage background jobs | N | N | N | N | N | N | N | N | N | S | I |
| system.internal | System | Internal service capability | N | N | N | N | N | N | N | N | N | N | I |

### 8.1 Authorization algorithm

For every protected operation:

```text
1. resolve authenticated User
2. enforce UserStatus
3. resolve active coarse roles
4. evaluate required capability
5. apply ScopedGrant / organization / geography scope
6. apply object policy: ownership, membership, visibility, block relation, lifecycle
7. validate transition invariants
8. execute transaction
9. append AuditLog when required
10. append OutboxEvent when side effects exist
```

## 9. Database conventions

- Primary keys: PostgreSQL UUID, generated server-side/database-side consistently. Do not expose sequential IDs for sensitive resources.
- All timestamps UTC `timestamptz`; user timezone is presentation/input context.
- Standard columns where relevant: `id`, `createdAt`, `updatedAt`, `version`; selective `deletedAt`.
- Use optimistic versioning for conflict-prone mutable aggregates; use database transactions/locking for capacity, reservation, cart/order conversion and financial transitions.
- Unique constraints enforce business idempotency, not only application checks.
- Do not use generic polymorphic `targetType/targetId` where referential integrity is critical; use explicit associations or bounded typed references.
- JSON is allowed for versioned provider payload snapshots and flexible metadata, not as replacement for core relational schema.
- Sensitive fields must have explicit data classification and retention rule.

### 9.1 Deletion policy

- User-generated recoverable content: selective soft-delete.
- Audit, payment, commission and webhook history: append-only/retained according to policy.
- Privacy deletion: orchestrated anonymization/tombstoning; never blindly cascade-delete records needed for security, disputes or legal retention.

## 10. API contract

The API contract map contains **105 endpoint contracts**. Full matrix: `Huddle_API_Contract_Map_v1.0.csv`.

### 10.1 Standard response envelope

```json
{
  "data": {},
  "meta": { "requestId": "..." },
  "error": null
}
```

Error:

```json
{
  "data": null,
  "meta": { "requestId": "..." },
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Human-safe summary",
    "fieldErrors": { "field": ["reason"] }
  }
}
```

### 10.2 API rules

- API version prefix: `/api/v1`. Breaking contract changes require new version or explicit compatibility plan.
- Validation occurs at HTTP boundary and again at domain transition boundary where business invariants apply.
- Mutation endpoints that can be retried by clients/providers require `Idempotency-Key`.
- Pagination uses stable cursor for large/high-churn collections; offset only for bounded admin tables where stable ordering is explicit.
- Errors never reveal another user’s resource existence when privacy policy forbids disclosure.
- Rate limits are policy-based by actor, IP risk and operation sensitivity. Auth/OTP, messaging, connection requests and reports require specific limits.

| Module | Method | Path | Capability | Priority | Events |
|---|---|---|---|---|---|
| Identity | GET | /api/v1/me | profile.read_self | P0 | - |
| Identity | PATCH | /api/v1/me | profile.update_self | P0 | user.profile_updated |
| Identity | POST | /api/v1/auth/link-phone | profile.update_self | P0 | auth.phone_challenge_created |
| Identity | POST | /api/v1/auth/verify-phone | profile.update_self | P0 | auth.phone_verified |
| Identity | GET | /api/v1/roles | profile.read_self | P0 | - |
| Identity | POST | /api/v1/role-context | profile.read_self | P0 | user.role_context_changed |
| Onboarding | GET | /api/v1/onboarding | profile.read_self | P0 | - |
| Onboarding | PATCH | /api/v1/onboarding | profile.update_self | P0 | onboarding.step_completed |
| Onboarding | POST | /api/v1/onboarding/complete | profile.update_self | P0 | onboarding.completed |
| Family | GET | /api/v1/family | family.manage_self | P0 | - |
| Family | PUT | /api/v1/family | family.manage_self | P0 | family.updated |
| Family | POST | /api/v1/family/members | family.manage_self | P0 | family.member_added |
| Family | PATCH | /api/v1/family/members/{memberId} | family.manage_self | P0 | family.member_updated |
| Family | DELETE | /api/v1/family/members/{memberId} | family.manage_self | P0 | family.member_removed |
| Matching | GET | /api/v1/matching/preferences | matching.manage_preferences | P0 | - |
| Matching | PUT | /api/v1/matching/preferences | matching.manage_preferences | P0 | matching.preferences_updated |
| Matching | GET | /api/v1/matching/candidates | matching.view_candidates | P1 | matching.candidates_viewed |
| Connections | POST | /api/v1/connections/requests | connection.request | P0 | connection.requested |
| Connections | POST | /api/v1/connections/requests/{id}/accept | connection.request | P0 | connection.accepted |
| Connections | POST | /api/v1/connections/requests/{id}/decline | connection.request | P0 | connection.declined |
| Connections | POST | /api/v1/users/{userId}/block | connection.block | P0 | user.blocked |
| Community | GET | /api/v1/feed | public.read | P0 | feed.viewed |
| Community | POST | /api/v1/posts | community.post.create | P0 | post.created |
| Community | PATCH | /api/v1/posts/{postId} | community.post.create | P1 | post.updated |
| Community | DELETE | /api/v1/posts/{postId} | community.post.create | P1 | post.deleted |
| Community | POST | /api/v1/posts/{postId}/comments | community.post.create | P0 | comment.created |
| Community | POST | /api/v1/reactions | community.post.create | P1 | reaction.changed |
| Groups | GET | /api/v1/groups | public.read | P0 | groups.viewed |
| Groups | POST | /api/v1/groups | group.create | P1 | group.created |
| Groups | GET | /api/v1/groups/{groupId} | public.read | P0 | group.viewed |
| Groups | PATCH | /api/v1/groups/{groupId} | group.manage | P1 | group.updated |
| Groups | POST | /api/v1/groups/{groupId}/join | public.read | P0 | group.joined |
| Groups | POST | /api/v1/groups/{groupId}/leave | public.read | P0 | group.left |
| Messaging | GET | /api/v1/conversations | message.send | P0 | - |
| Messaging | POST | /api/v1/conversations | message.send | P0 | conversation.created |
| Messaging | GET | /api/v1/conversations/{conversationId}/messages | message.send | P0 | - |
| Messaging | POST | /api/v1/conversations/{conversationId}/messages | message.send | P0 | message.created |
| Messaging | PATCH | /api/v1/messages/{messageId} | message.send | P1 | message.updated |
| Messaging | DELETE | /api/v1/messages/{messageId} | message.send | P1 | message.deleted |
| Messaging | POST | /api/v1/conversations/{conversationId}/read | message.send | P0 | conversation.read_updated |
| Messaging | GET | /api/v1/messages/search | message.send | P1 | - |
| Listings | GET | /api/v1/listings | public.read | P0 | listing.search_viewed |
| Listings | POST | /api/v1/listings | listing.create | P0 | listing.created |
| Listings | GET | /api/v1/listings/{listingId} | public.read | P0 | listing.viewed |
| Listings | PATCH | /api/v1/listings/{listingId} | listing.manage_own | P0 | listing.updated |
| Listings | POST | /api/v1/listings/{listingId}/publish | listing.manage_own | P0 | listing.published |
| Listings | POST | /api/v1/listings/{listingId}/reserve | order.create | P1 | listing.reserved |
| Listings | POST | /api/v1/listings/{listingId}/inquiries | message.send | P0 | listing.inquiry_created |
| Catalog | GET | /api/v1/products | public.read | P1 | product.search_viewed |
| Catalog | GET | /api/v1/products/{productId} | public.read | P1 | product.viewed |
| Catalog | POST | /api/v1/partner/feeds | catalog.manage_partner | P2 | partner_feed.created |
| Catalog | POST | /api/v1/partner/feeds/{feedId}/sync | catalog.manage_partner | P2 | partner_feed.sync_requested |
| Orders | GET | /api/v1/cart | order.create | P1 | - |
| Orders | PUT | /api/v1/cart/items | order.create | P1 | cart.updated |
| Orders | POST | /api/v1/checkout | order.create | P1 | checkout.started |
| Orders | POST | /api/v1/orders | order.create | P1 | order.created |
| Orders | GET | /api/v1/orders | order.read_own | P1 | - |
| Orders | GET | /api/v1/orders/{orderId} | order.read_own | P1 | order.viewed |
| Orders | POST | /api/v1/orders/{orderId}/cancel | order.read_own | P1 | order.cancelled |
| Orders | POST | /api/v1/orders/{orderId}/returns | order.refund_request | P1 | return.requested |
| Payments | POST | /api/v1/payments/intents | order.create | P1 | payment.intent_created |
| Payments | POST | /api/v1/payments/webhooks/{provider} | system.internal | P1 | payment.provider_event_received |
| Finance | POST | /api/v1/admin/refunds/{refundId}/approve | finance.refund_execute | P2 | refund.approved |
| Finance | POST | /api/v1/admin/payouts/{payoutId}/approve | finance.payout_review | P2 | payout.approved |
| Experiences | GET | /api/v1/experiences | public.read | P0 | experience.search_viewed |
| Experiences | GET | /api/v1/experiences/{experienceId} | public.read | P0 | experience.viewed |
| Experiences | POST | /api/v1/experiences | experience.create | P1 | experience.created |
| Experiences | PATCH | /api/v1/experiences/{experienceId} | experience.manage_own | P1 | experience.updated |
| Experiences | POST | /api/v1/experiences/{experienceId}/publish | experience.manage_own | P1 | experience.published |
| Experiences | POST | /api/v1/occurrences/{occurrenceId}/registrations | experience.register | P0 | registration.created |
| Experiences | DELETE | /api/v1/registrations/{registrationId} | experience.register | P0 | registration.cancelled |
| Experiences | POST | /api/v1/checkins | experience.checkin | P1 | registration.checked_in |
| Services | GET | /api/v1/services | public.read | P1 | service.search_viewed |
| Services | GET | /api/v1/services/{serviceId} | public.read | P1 | service.viewed |
| Services | POST | /api/v1/expert/services | service.manage_own | P1 | service.created |
| Bookings | POST | /api/v1/services/{serviceId}/bookings | service.book | P1 | booking.requested |
| Bookings | GET | /api/v1/bookings | booking.manage_customer | P1 | - |
| Bookings | POST | /api/v1/bookings/{bookingId}/reschedule | booking.manage_customer | P1 | booking.rescheduled |
| Bookings | POST | /api/v1/bookings/{bookingId}/cancel | booking.manage_customer | P1 | booking.cancelled |
| Notifications | GET | /api/v1/notifications | profile.read_self | P0 | - |
| Notifications | POST | /api/v1/notifications/read | profile.read_self | P0 | notification.read |
| Notifications | GET | /api/v1/notification-preferences | notification.preference.manage | P0 | - |
| Notifications | PUT | /api/v1/notification-preferences | notification.preference.manage | P0 | notification.preferences_updated |
| Search | GET | /api/v1/search | public.read | P0 | search.performed |
| Media | POST | /api/v1/media/uploads | profile.update_self | P0 | media.upload_created |
| Media | POST | /api/v1/media/{mediaId}/complete | profile.update_self | P0 | media.upload_completed |
| Safety | POST | /api/v1/reports | safety.report.create | P0 | safety.report_submitted |
| Safety | GET | /api/v1/admin/moderation/cases | safety.case.read | P0 | - |
| Safety | GET | /api/v1/admin/moderation/cases/{caseId} | safety.case.read | P0 | - |
| Safety | POST | /api/v1/admin/moderation/cases/{caseId}/decisions | safety.case.decide | P0 | moderation.decision_issued |
| Safety | POST | /api/v1/appeals | safety.report.create | P0 | appeal.submitted |
| Support | POST | /api/v1/support/tickets | support.ticket.create | P1 | support.ticket_created |
| Support | GET | /api/v1/support/tickets | support.ticket.create | P1 | - |
| Privacy | GET | /api/v1/consents | privacy.consent.manage_self | P0 | - |
| Privacy | POST | /api/v1/consents | privacy.consent.manage_self | P0 | consent.changed |
| Privacy | POST | /api/v1/privacy/requests | privacy.request.create | P0 | privacy.request_submitted |
| Privacy | GET | /api/v1/privacy/requests | privacy.request.create | P0 | - |
| Privacy | GET | /api/v1/admin/privacy/governance | privacy.policy.manage | P0 | - |
| Privacy | POST | /api/v1/admin/privacy/exports/{id}/approve | privacy.export.approve | P0 | privacy.export_approved |
| Municipality | GET | /api/v1/municipality/reports | municipality.report_read | P2 | - |
| Municipality | POST | /api/v1/municipality/programs | municipality.program_manage | P2 | municipality.program_created |
| Admin | GET | /api/v1/admin/users | admin.user.manage | P0 | - |
| Admin | PATCH | /api/v1/admin/users/{userId}/status | admin.user.manage | P0 | admin.user_status_changed |
| Admin | POST | /api/v1/admin/users/{userId}/grants | admin.role.grant | P0 | admin.grant_created |
| Admin | GET | /api/v1/admin/audit-log | admin.audit.read | P0 | - |

## 11. Realtime architecture

Canonical event envelope:

```ts
type RealtimeEvent<T> = {
  id: string;              // globally unique event id
  type: string;            // e.g. message.created
  version: number;
  occurredAt: string;
  channel: string;         // authorized server-derived channel
  actorId?: string;
  correlationId?: string;
  payload: T;
};
```

Required event families: `message.created|updated|deleted`, `conversation.read_updated`, `notification.created|read`, `connection.requested|accepted`, `listing.updated|reserved`, `registration.created|cancelled|checked_in`, `booking.updated`, `moderation.case_updated`.

- Client never chooses an arbitrary private channel without server authorization.
- Event id deduplication is mandatory after reconnect.
- Realtime is an acceleration layer; canonical state is fetched from API/database after gap detection.
- Presence/typing are ephemeral and must not be persisted as durable business events.

## 12. Messaging implementation contract

- One core model supports DIRECT, GROUP, LISTING, BOOKING, EVENT and SUPPORT contexts.
- Conversation creation is policy-driven: e.g. listing inquiry requires visible listing and non-blocked actors; family direct chat requires connection policy.
- Message send transaction: authorize participant → validate content/media → persist message → update conversation activity → outbox → broadcast.
- Attachments must be READY, owned/authorized, and not quarantined.
- Deletion policy distinguishes user delete, moderation removal and legal hold.
- Search only returns messages from conversations the current user can still access.
- No message text in analytics, ordinary application logs or notification provider metadata beyond necessary preview policy.

## 13. Marketplace and commerce contract

### 13.1 Listings
- P2P user-generated listing lifecycle: DRAFT → PENDING_REVIEW? → PUBLISHED → RESERVED/SOLD → ARCHIVED; REJECTED is separate terminal/rework state.
- Listing ownership and seller identity are explicit. A Listing is not a Product.
- Required states from sets32/33 must be wired: upload failure, publish rejection, empty search, unavailable/reserved states.

### 13.2 Catalog
- Partner Product belongs to Store/Partner context, supports variants/feed lineage and catalog approval.
- Feed synchronization creates `FeedSyncRun`; retries cannot duplicate products by source identity.

### 13.3 Orders and fulfillment
- Cart is user-scoped and price is advisory until checkout server recalculation.
- Order stores immutable commercial snapshot. Never calculate historical order display from current Product price.
- State transitions are command-based; no generic `PATCH status` endpoint for client.

### 13.4 Payments
- Live payment provider remains gated by commercial/legal decision. Build interfaces and webhook inbox first.
- Never store raw card data. Provider event signatures are verified before processing.
- Refunds, disputes, payouts and commissions are independent auditable lifecycles.

## 14. Experiences: events and activities

- Shared `Experience` handles discovery, title, media, location policy, organizer, visibility and kind.
- `ExperienceOccurrence` owns timezone-aware schedule and capacity.
- `Registration` can reference User and privacy-minimized FamilyMember participant selection.
- Registration capacity check and insertion occur transactionally.
- Event-specific ticket/check-in behavior is extension capability, not required for every Activity.
- Community events are linked to Group/context; the group does not own a separate duplicate event table.

## 15. Family, connections and matching

### 15.1 Prohibited implementation patterns
- Do not expose exact child birthdate in candidate cards.
- Do not expose exact home address or distance precise enough to infer address.
- Do not allow unrestricted direct messaging solely because a match score exists.
- Do not send sensitive matching features to analytics.

### 15.2 Matching pipeline

```text
opt-in preferences
  → eligibility filter
  → block/safety exclusion
  → geography coarse filter
  → compatibility scoring
  → privacy-safe explanation
  → candidate DTO
  → connection request
  → reciprocal acceptance
  → conversation eligibility
```

Scores are derived and should not persist raw sensitive features in a user-visible snapshot. Explanations use coarse reasons such as shared interests, age-stage compatibility and broad area.

## 16. Trust & Safety

- User entry points from set52: report listing/user/message, block/mute, child privacy controls, appeal, suspicious behavior warning, safety support.
- Admin operations from set56: queue, reported entity detail, child safety review, decision panel, appeals, enforcement history, safety audit.
- `SafetyReport` and `ModerationCase` are separate: multiple reports may consolidate into one case.
- Moderation decisions create explicit `EnforcementAction`; never silently mutate user/content state without case linkage where policy requires.
- Appeals preserve original decision and create review outcome; do not overwrite history.
- High-risk actions require reason codes, evidence references and audit entries.

## 17. Notifications and communications

```text
Domain event
  → Notification policy
  → Notification record
  → Preference evaluation
  → Delivery records per channel
  → adapter send
  → delivery/retry/dead-letter state
```

- In-app notification creation is durable and independent of email/push success.
- Templates are versioned by event, locale and channel. Set58 is visual/copy reference, not hardcoded JSX per event.
- Mandatory security/safety notices use explicit policy and cannot be accidentally disabled by broad marketing preference.
- Delivery retries are idempotent; provider message IDs are recorded.

## 18. Search

- P0 SearchProvider uses Postgres FTS + trigram where appropriate.
- Search indexes only fields permitted for the entity’s visibility model.
- Query result serialization re-checks current visibility and block policy.
- Global search returns typed groups, e.g. `listing`, `experience`, `group`, `service`, `profile` only when user is eligible to view.
- Search analytics logs normalized query metrics only according to privacy policy; never associate sensitive queries with child identifiers.

## 19. Media and files

Upload lifecycle: `PENDING → SCANNING → READY | QUARANTINED | DELETED`.

- Client requests signed upload intent; server validates purpose, MIME, size and actor scope.
- Completion verifies object checksum/metadata and starts scanning/processing.
- Images strip unnecessary metadata before public delivery.
- Private media uses signed delivery URLs and object authorization; public bucket is not acceptable for private chat/family evidence.
- Safety evidence and support attachments have stricter retention/access policies.

## 20. Privacy and governance

### 20.1 Data classes

| Class | Examples | Rules |
|---|---|---|
| PUBLIC | Published listings/events/public pages | May be indexed when policy allows |
| CONFIDENTIAL | Profiles, bookings, orders | Authenticated/scoped access |
| RESTRICTED | Phone, address, finance, audit | Least privilege, enhanced logging |
| HIGHLY_RESTRICTED | Child data, messages, safety cases, privacy incidents | Strict scoped access, no ordinary analytics/logging |
| PSEUDONYMOUS | Analytics identifiers | No direct identifying payload; defined retention |

### 20.2 Municipality reporting

- Default minimum cohort threshold: 10. Any cell below threshold is suppressed, not rounded into a guessable value.
- Difference attacks must be considered: repeated filtered queries cannot reconstruct small groups.
- Exports require scope check, purpose, approval and audit. Row-level personal exports are not a municipality capability.
- Exact location and child identifiers are forbidden in municipality reports.

### 20.3 Data requests

- Request types: access/export, correction, deletion, restriction where supported.
- Identity verification occurs before fulfillment.
- Export package is short-lived, encrypted/signed, access audited and expires.
- Deletion orchestration respects legal hold/retention, then anonymizes or deletes according to active policy version.

## 21. Accessibility, localization and SEO

- Keyboard navigation and visible focus are mandatory for all interactive surfaces.
- Target WCAG 2.2 AA acceptance; color tokens still require component-level contrast verification.
- Respect reduced motion and user text-size preference; no essential information encoded only by color.
- Public locales: `/en/...`, `/no/...`; localized pages declare canonical and reciprocal hreflang.
- `/app` locale is preference-driven to avoid duplicating authenticated route state.
- SEO template pages require unique useful content/data; do not mass-publish empty location/category combinations.

## 22. Analytics and product events

Event naming: `<domain>.<noun>_<past-tense-or-action>` with versioned schema, e.g. `listing.viewed.v1`, `registration.created.v1`.

Required common fields: `eventId`, `schemaVersion`, `occurredAt`, `anonymousId?`, `userId?` (pseudonymous policy), `sessionId?`, `sourceSurface`, `route`, `correlationId?`.

Prohibited payload: message text, exact address, child name/birthdate, safety report narrative, health-sensitive free text, payment credentials.

Server-authoritative events: order/payment/refund, registration/check-in, role/grant change, safety enforcement, privacy request, consent change. Client-only success events must never be used as transaction truth.

## 23. Security baseline

- Server-side authorization on every protected read and mutation.
- CSRF protection appropriate to chosen session/cookie patterns; secure, httpOnly, sameSite settings.
- Strict input validation and output encoding; no unsafe HTML without sanitization policy.
- SSRF-safe URL fetching; allowlists for feed/webhook integrations where possible.
- File upload allowlists, scanning/quarantine, no executable public uploads.
- Rate limits for auth/OTP, connection requests, messages, report abuse, search scraping and export generation.
- Secrets only in environment/secret manager; no service-role keys in browser bundles.
- Webhook signature verification and replay protection.
- Sensitive logs redacted. Request IDs/correlation IDs are safe; do not log access tokens or message content.
- Dependency and migration review gates before production deployment.

## 24. Testing strategy

| Layer | Required coverage |
|---|---|
| Unit | Pure domain transitions, policies, match filters, pricing snapshots, suppression logic |
| Integration | Prisma repositories, transactions, authorization scopes, outbox, provider adapters with fakes |
| Contract | API DTO/error schemas; webhook signature/idempotency |
| E2E | P0 canonical flows from set35/36/37/38/39/44/46/52/56/60 |
| Visual regression | Canonical screens/components across compact/medium/wide |
| Accessibility | Automated checks + manual keyboard/focus/screen-reader critical flows |
| Security | Authorization matrix, IDOR, upload abuse, rate limits, privacy leakage |
| Concurrency | Capacity registration, listing reservation, booking slots, checkout/order creation |
| Realtime | Reconnect, duplicate event, out-of-order delivery, gap recovery |
| Performance | Search/feed/list pages, message pagination, admin queues |
| Privacy | Municipality threshold/difference attack tests; child data DTO leakage tests |

### 24.1 Minimum PR gate

`format → lint → typecheck → unit/integration tests → build`. A feature with UI but no relevant authorization/error/empty/loading tests is incomplete.

## 25. Observability and operations

- Structured application logs with request/correlation id and redaction.
- Error tracking adapter; initial documented target may be Sentry when enabled.
- Metrics: HTTP latency/error, DB pool, job lag/failure, realtime delivery, notification failures, webhook processing, search latency, checkout failures.
- Alerts must point to runbook and owner; avoid alerting on raw user-sensitive content.
- Database backup/restore is an operational capability with tested restore procedure, not merely an admin screenshot.
- Migration strategy: forward-compatible deploy where possible; destructive migrations require backup/rollback plan.

## 26. Screen implementation contract

`Huddle_Screen_Implementation_Registry_v1.0.csv` contains **628 unique artifact rows**. Every implemented screen must create a local screen spec using this template:

```yaml
screen_id: HUD-VIS-...
canonical_name: ...
source_file: ...
route: ...
actors: [...]
required_capabilities: [...]
purpose: ...
entry_points: [...]
data_queries: [...]
mutations: [...]
states:
  - loading
  - populated
  - empty
  - validation_error
  - permission_denied_or_not_found
  - server_error
  - offline_or_retry
responsive:
  compact: ...
  medium: ...
  wide: ...
analytics_events: [...]
acceptance_criteria: [...]
```

### 26.1 Disposition rules

- `CANONICAL_CANDIDATE_IMPLEMENT`: primary visual candidate; implement after route/domain reconciliation.
- `SPECIALIST_CANONICAL_SUPPLEMENT`: specialist lifecycle/role surface that supplements primary flow.
- `IMPLEMENT_AS_STATE`: not standalone product route unless required; wire into owning screen flow.
- `REFERENCE_ONLY`: inspect for missing capability/state; do not implement duplicate route by default.
- `DESIGN_TOKEN_SOURCE` / `COMPONENT_REFERENCE`: implementation system reference, not product route.
- `ARCHITECTURE_REFERENCE`: flow/architecture, not UI.
- `ARCHIVE_DUPLICATE`: no implementation work.

## 27. Functional module implementation specifications

### 27.1 Auth & Onboarding

- **Visual sources:** set35 + set60
- **Routes:** `/signup, /login, /verify, /onboarding/*`
- **Actors:** Guest, authenticated incomplete user
- **Core data:** User, AuthIdentity, OnboardingState, ConsentRecord
- **Required behavior:** Signup/login/recovery; choose role context; verify phone; family profile; children optional; interests; location choice; guidelines; complete
- **Mandatory edge cases:** OTP expired/locked; duplicate account; denied location; resumable partial state; consent version changed
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.2 App Shell

- **Visual sources:** set39 + set61
- **Routes:** `/app, search, saved, notifications`
- **Actors:** Authenticated user
- **Core data:** UserPreference, role context
- **Required behavior:** Responsive shell; navigation; search entry; saved hub; notification center; account/location/role switchers
- **Mandatory edge cases:** No permissions after role switch; compact safe area; offline shell; unread count reconciliation
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.3 Family & Connections

- **Visual sources:** set46 + set2 reference
- **Routes:** `/app/family, /app/connections`
- **Actors:** Parent
- **Core data:** FamilyProfile, FamilyMember, ConnectionRequest, Connection, BlockRelation
- **Required behavior:** Profile edit; family settings; request/accept/decline; block; privacy
- **Mandatory edge cases:** Blocked relationships; stale request; hidden profile; child-safe DTO
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.4 Matching

- **Visual sources:** set2 + set55/555
- **Routes:** `/app/matching/*`
- **Actors:** Opted-in parent
- **Core data:** MatchPreference, MatchCandidateSnapshot, ConnectionRequest
- **Required behavior:** Preferences; candidate list/detail; privacy-safe rationale; connect request
- **Mandatory edge cases:** No candidates; consent withdrawn; geo unavailable; abuse/rate limit
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.5 Marketplace Listings

- **Visual sources:** set36 + set13
- **Routes:** `/marketplace/listings/*, /app/marketplace/*`
- **Actors:** Buyer/parent, seller
- **Core data:** Listing, ListingMedia, ListingReservation, ListingInquiry
- **Required behavior:** Discovery/filter/search; listing detail; seller profile; create photos/details/price/location; review/publish
- **Mandatory edge cases:** Upload fail; moderation rejection; reserved/sold; unavailable; ownership conflict
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.6 Catalog & Orders

- **Visual sources:** set49 + set43 + set12
- **Routes:** `/marketplace/products/*, /app/orders/*`
- **Actors:** Buyer, partner/seller
- **Core data:** Product, Cart, Order, Shipment, ReturnRequest
- **Required behavior:** Product discovery; cart; checkout; confirmation; orders; tracking; returns
- **Mandatory edge cases:** Price changed; inventory conflict; payment failed; delivery failed; return rejected
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.7 Events & Activities

- **Visual sources:** set37 + set18 + set16
- **Routes:** `/events, /activities, /app/events, /app/activities`
- **Actors:** Guest/user, organizer
- **Core data:** Experience, Occurrence, Registration, Ticket, CheckIn
- **Required behavior:** Discover/filter/detail; host; register/review; my events; reminder; QR check-in
- **Mandatory edge cases:** Capacity full/waitlist; cancelled occurrence; timezone; invalid/used QR
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.8 Community & Groups

- **Visual sources:** set38 + set53 + set48
- **Routes:** `/app/community, /app/groups/*`
- **Actors:** Authenticated user, group admin
- **Core data:** Group, Membership, Post, Comment, Reaction, Poll
- **Required behavior:** Feed; group directory/detail/feed/members/events/files/settings; create/share post
- **Mandatory edge cases:** Private membership; removed content; banned user; upload failure; empty feed
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.9 Messaging

- **Visual sources:** set44
- **Routes:** `/app/messages/*`
- **Actors:** Authorized participant
- **Core data:** Conversation, Participant, Message, Attachment, Mention
- **Required behavior:** Inbox; direct/group chat; voice/media; mentions; saved; search; settings
- **Mandatory edge cases:** Blocked user; removed participant; upload fail; reconnect; duplicate/out-of-order event
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.10 Services & Bookings

- **Visual sources:** set47 + set40 + set21
- **Routes:** `/services/*, /app/services/*, /app/bookings/*`
- **Actors:** Customer, expert
- **Core data:** ExpertProfile, ServiceOffering, AvailabilityRule, Booking, Review
- **Required behavior:** Discovery/category/list/detail; book; confirmation; bookings; reschedule/cancel; expert ops
- **Mandatory edge cases:** Slot conflict; provider declines; cancellation policy; timezone/DST
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.11 Trust & Safety

- **Visual sources:** set52 + set56
- **Routes:** `/app/safety/*, /admin/moderation/*`
- **Actors:** User, moderator/admin
- **Core data:** SafetyReport, ModerationCase, EnforcementAction, Appeal
- **Required behavior:** Report entity; block/mute; warnings; support; queues; decision; appeal; history
- **Mandatory edge cases:** Malicious reporting; reporter privacy; conflict of reviewer; legal hold
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.12 Privacy & Governance

- **Visual sources:** set60 + set63
- **Routes:** `/app/privacy/*, /admin/privacy/*`
- **Actors:** User, privacy admin
- **Core data:** ConsentRecord, DataRequest, RetentionPolicy, AnonymizationRule, ExportApproval, PrivacyIncident
- **Required behavior:** Consent; cookie preferences; download/delete request; status; governance/audit/retention/anonymization/export/incident
- **Mandatory edge cases:** Identity verification; retention exception; export expiry; incident restricted access
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.13 Municipality

- **Visual sources:** set23 + set63 + set55/560
- **Routes:** `/app/municipality/*`
- **Actors:** Scoped municipality user
- **Core data:** Organization, MunicipalityScope, PublicProgram, AggregateReport
- **Required behavior:** Onboarding/scope; programs; aggregate reporting
- **Mandatory edge cases:** Small cohort suppression; scope change; export approval; stale report
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.14 Admin Core

- **Visual sources:** set25
- **Routes:** `/admin/*`
- **Actors:** Authorized staff
- **Core data:** User, ScopedGrant, AuditLog + domain queues
- **Required behavior:** Dashboard; user management; approvals; audit; domain admin entry
- **Mandatory edge cases:** Least privilege; no bulk action without preview/audit; object disclosure policy
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.15 Finance Ops

- **Visual sources:** set62 + set31
- **Routes:** `/admin/finance/*`
- **Actors:** Scoped finance admin
- **Core data:** Refund, Dispute, Payout, Commission, Invoice
- **Required behavior:** Overview; refund queue; disputes; commission ledger; payout review; invoice; failed payments; tax/VAT report; revenue
- **Mandatory edge cases:** Provider mismatch; double refund; payout hold; reconciliation discrepancy
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

### 27.16 Public SEO

- **Visual sources:** set41 + set42 + set59
- **Routes:** `/{locale}/cities/* etc.`
- **Actors:** Guest
- **Core data:** SEO template data, public entities
- **Required behavior:** City/category/age/season landing pages, localized templates
- **Mandatory edge cases:** Thin/empty page noindex; canonical duplication; unavailable locale
- **Acceptance:** visible actions must map to real mutation/query; loading/empty/error/permission states; compact/medium/wide; keyboard/focus; analytics allowlist; server authorization.

## 28. Required system and negative states

Sets32 and 33 are **required state sources**, not optional polish. Every owning module must map relevant states:

- loading/skeleton and delayed response;
- empty result and first-use empty state;
- offline/retry;
- 404-safe not found;
- authorization denied without resource leakage;
- validation error and server conflict;
- upload failure/quarantine;
- payment failure/requires action;
- moderation rejected/suspended;
- expired invitation/session/OTP;
- full capacity/waitlist;
- stale/concurrent update;
- deleted/unavailable resource.

A happy-path-only screen is not Done.

## 29. Implementation roadmap

Roadmap includes **81 tasks**. Full dependency matrix: `Huddle_Implementation_Roadmap_v1.0.csv`.

| Phase | Task | Epic | Title | Priority | Dependencies |
|---|---|---|---|---|---|
| Phase 0 | S0-001 | Foundation | Initialize project repository | P0 | - |
| Phase 0 | S0-002 | Foundation | Create route group architecture | P0 | S0-001 |
| Phase 0 | S0-003 | Foundation | Add approved brand assets and logo components | P0 | S0-002 |
| Phase 0 | S0-004 | Foundation | Implement design token foundation | P0 | S0-003 |
| Phase 0 | S0-005 | Foundation | Create primitive UI components | P0 | S0-004 |
| Phase 0 | S0-006 | Foundation | Configure database and Prisma | P0 | S0-005 |
| Phase 0 | S0-007 | Foundation | Implement User / Role / UserRole models | P0 | S0-006 |
| Phase 0 | S0-008 | Foundation | Seed roles | P0 | S0-007 |
| Phase 0 | S0-009 | Foundation | Create Supabase Auth skeleton | P0 | S0-008 |
| Phase 0 | S0-010 | Foundation | Create permission helpers | P0 | S0-009 |
| Phase 0 | S0-011 | Foundation | Create route guards | P0 | S0-010 |
| Phase 0 | S0-012 | Foundation | Create API response and error helpers | P0 | S0-011 |
| Phase 0 | S0-013 | Foundation | Create validation pattern | P0 | S0-012 |
| Phase 0 | S0-014 | Foundation | Create audit helper and AuditLog base | P0 | S0-013 |
| Phase 0 | S0-015 | Foundation | Create base layouts | P0 | S0-014 |
| Phase 0 | S0-016 | Foundation | Create canonical placeholder pages | P0 | S0-015 |
| Phase 0 | S0-017 | Foundation | Create Sprint 0 QA checklist | P0 | S0-016 |
| Phase 0 | S0-018 | Foundation | Create developer README | P0 | S0-017 |
| Phase 1 | P1-001 | Identity | Implement User/AuthIdentity reconciliation | P0 | S0-018 |
| Phase 1 | P1-002 | Authorization | Implement Capability and ScopedGrant model | P0 | P1-001 |
| Phase 1 | P1-003 | Auth | Implement signup/login/recovery UI | P0 | P1-001 |
| Phase 1 | P1-004 | Auth | Implement phone verification and account linking | P0 | P1-003 |
| Phase 1 | P1-005 | Onboarding | Implement resumable onboarding state machine | P0 | P1-003 |
| Phase 1 | P1-006 | Family | Implement FamilyProfile/FamilyMember | P0 | P1-005 |
| Phase 1 | P1-007 | Consent | Implement consent records and policy versions | P0 | P1-005 |
| Phase 1 | P1-008 | App Shell | Implement canonical /app shell and role context | P0 | P1-002 |
| Phase 1 | P1-009 | Responsive | Implement responsive navigation contract | P0 | P1-008 |
| Phase 1 | P1-010 | Media | Implement secure media upload pipeline | P0 | P1-006 |
| Phase 2 | P2-001 | Discovery | Implement global search provider and endpoint | P0 | P1-008 |
| Phase 2 | P2-002 | Experiences | Implement Experience/Occurrence model | P0 | P1-010 |
| Phase 2 | P2-003 | Experiences | Implement public/app discovery | P0 | P2-002 |
| Phase 2 | P2-004 | Experiences | Implement registration/cancellation | P0 | P2-002 |
| Phase 2 | P2-005 | Listings | Implement Listing draft lifecycle | P0 | P1-010 |
| Phase 2 | P2-006 | Listings | Implement listing discovery/detail | P0 | P2-005 |
| Phase 2 | P2-007 | Community | Implement feed/post/comment/reaction core | P0 | P1-008 |
| Phase 2 | P2-008 | Connections | Implement connection request/block core | P0 | P1-006 |
| Phase 2 | P2-009 | Notifications | Implement in-app notification core | P0 | P1-008 |
| Phase 2 | P2-010 | Safety | Implement user report/block surfaces | P0 | P2-006,P2-007,P2-008 |
| Phase 2 | P2-011 | Admin Safety | Implement moderation case workflow | P0 | P2-010,P1-002 |
| Phase 2 | P2-012 | Audit | Enforce privileged mutation audit coverage | P0 | P2-011 |
| Phase 3 | P3-001 | Messaging | Implement Conversation/Participant core | P0 | P2-008,P1-002 |
| Phase 3 | P3-002 | Messaging | Implement message send/read/pagination | P0 | P3-001 |
| Phase 3 | P3-003 | Realtime | Implement RealtimeGateway adapter | P0 | P3-002 |
| Phase 3 | P3-004 | Messaging | Implement attachments/mentions/search/settings | P1 | P3-003,P1-010 |
| Phase 3 | P3-005 | Notifications | Implement delivery pipeline and preferences | P0 | P2-009 |
| Phase 3 | P3-006 | Notifications | Implement email/push template registry | P1 | P3-005 |
| Phase 4 | P4-001 | Groups | Implement Group/Membership model | P1 | P2-007 |
| Phase 4 | P4-002 | Groups | Implement group feed/members/files/settings | P1 | P4-001,P1-010 |
| Phase 4 | P4-003 | Content | Implement richer post/media lifecycle | P1 | P2-007,P1-010 |
| Phase 4 | P4-004 | Matching | Implement opt-in preferences | P1 | P1-006,P2-008 |
| Phase 4 | P4-005 | Matching | Implement candidate computation and explanation | P1 | P4-004 |
| Phase 4 | P4-006 | Matching | Implement match-to-connection flow | P1 | P4-005 |
| Phase 5 | P5-001 | Services | Implement ExpertProfile onboarding/state | P1 | P1-002,P1-010 |
| Phase 5 | P5-002 | Services | Implement ServiceOffering/availability | P1 | P5-001 |
| Phase 5 | P5-003 | Bookings | Implement booking request/confirm lifecycle | P1 | P5-002 |
| Phase 5 | P5-004 | Bookings | Implement reschedule/cancel/no-show | P1 | P5-003 |
| Phase 5 | P5-005 | Organizer | Implement experience creation operations | P1 | P2-002,P1-002 |
| Phase 5 | P5-006 | Organizer | Implement check-in/ticket operations | P1 | P2-004,P5-005 |
| Phase 6 | P6-001 | Catalog | Implement Partner/Store/Product core | P1 | P1-002 |
| Phase 6 | P6-002 | Catalog | Implement partner feed sync run model | P2 | P6-001 |
| Phase 6 | P6-003 | Cart | Implement cart and server pricing | P1 | P6-001 |
| Phase 6 | P6-004 | Orders | Implement Order/OrderItem lifecycle | P1 | P6-003 |
| Phase 6 | P6-005 | Payments | Implement provider-neutral payment interfaces | P1 | P6-004 |
| Phase 6 | P6-006 | Payments | Implement webhook inbox/idempotency | P1 | P6-005 |
| Phase 6 | P6-007 | Fulfillment | Implement shipment/pickup/tracking | P1 | P6-004 |
| Phase 6 | P6-008 | Returns | Implement return/refund request lifecycle | P1 | P6-004 |
| Phase 6 | P6-009 | Affiliate | Implement outbound attribution boundary | P2 | P6-001 |
| Phase 7 | P7-001 | Public Web | Implement localized public shell | P1 | P1-009 |
| Phase 7 | P7-002 | SEO | Implement city/category/age/season templates | P1 | P7-001,P2-001 |
| Phase 7 | P7-003 | SEO | Implement metadata/canonical/hreflang/sitemap | P1 | P7-002 |
| Phase 7 | P7-004 | Accessibility | Implement user accessibility preferences | P0 | P1-009 |
| Phase 7 | P7-005 | Privacy | Implement data request workflow | P0 | P1-007 |
| Phase 7 | P7-006 | Privacy | Implement delete-account orchestration | P0 | P7-005 |
| Phase 8 | P8-001 | Admin | Implement core admin dashboard/user management | P0 | P1-002,P2-012 |
| Phase 8 | P8-002 | Support | Implement ticket/helpdesk core | P2 | P1-002 |
| Phase 8 | P8-003 | Finance | Implement refund/dispute/payout operations | P2 | P6-006,P1-002 |
| Phase 8 | P8-004 | Privacy Ops | Implement governance dashboard/policies | P0 | P7-005,P1-002 |
| Phase 8 | P8-005 | Municipality | Implement org scopes/programs | P2 | P1-002 |
| Phase 8 | P8-006 | Municipality | Implement aggregate reporting pipeline | P2 | P8-005,P8-004 |
| Phase 8 | P8-007 | Analytics | Implement metric/report definitions | P2 | P2-001 |
| Phase 8 | P8-008 | Platform Ops | Implement real-backed settings/feature flags/jobs UI | P3 | P1-002 |

### 29.1 Release gates

- **Gate 0:** Sprint 0 foundation passes build/typecheck/lint and documented QA.
- **Gate 1:** Identity, authorization, app shell, family core, consent, media foundation.
- **Gate 2:** P0 discovery/listings/experiences/community/connections/notifications/safety + moderation.
- **Gate 3:** Messaging/realtime and delivery reliability.
- **Gate 4:** Privacy-reviewed matching/groups/content expansion.
- **Gate 5:** Services/bookings and organizer operations.
- **Gate 6:** Catalog/orders/payments; live payments require explicit commercial/legal gate.
- **Gate 7:** Localized public SEO, accessibility, privacy requests.
- **Gate 8:** Finance, municipality, analytics and platform operations according to P2/P3 readiness.

## 30. Codex-first execution protocol

Every Codex task must contain:

```text
Task ID
Objective
Why this task exists
Dependencies / prerequisite commit
Canonical visual artifact IDs
Allowed files/directories
Forbidden changes
Required domain entities
Required capabilities
API contracts
State transitions/invariants
UI states
Analytics allowlist
Tests
Migration plan
Definition of Done
```

### 30.1 Codex prohibitions

- Do not invent new routes, roles, colors, entities or provider dependencies without ADR/task approval.
- Do not refactor unrelated modules in a feature task.
- Do not bypass permission helpers for expediency.
- Do not create mock success controls in production routes.
- Do not use `any` to silence domain contract errors.
- Do not store raw provider payload as canonical business state.
- Do not generate a second implementation of messaging, orders, notifications or audit.

## 31. Definition of Done

A feature is Done only when all applicable items pass:

1. Canonical artifact/route/domain ownership identified.
2. UI matches canonical visual source within agreed responsive behavior.
3. All visible actions connect to real backend behavior or are intentionally removed.
4. Authentication, capability and object policy enforced server-side.
5. Input validation and business invariant validation implemented.
6. Loading, empty, error, conflict and permission-safe states implemented.
7. Required audit and outbox events written transactionally.
8. Analytics event payload passes privacy allowlist.
9. Unit/integration/E2E coverage appropriate to risk.
10. Accessibility keyboard/focus checks pass; critical flows manually reviewed.
11. Compact/medium/wide behavior verified against set61/current source.
12. No sensitive data in logs, client bundles or unauthorized DTOs.
13. Build, lint, typecheck and tests pass.
14. Migration has rollback/forward strategy where data shape changes.
15. Documentation and task traceability updated.

## 32. Immediate execution order from current repository state

Because GitHub is pre-Sprint-0, the developer must execute exactly this sequence:

1. `S0-001` — Initialize project repository.
2. `S0-002` — Create route group architecture.
3. `S0-003` — Add approved brand assets and logo components.
4. `S0-004` — Implement design token foundation.
5. `S0-005` — Create primitive UI components.
6. `S0-006` — Configure database and Prisma.
7. `S0-007` — Implement User / Role / UserRole models.
8. `S0-008` — Seed roles.
9. `S0-009` — Create Supabase Auth skeleton.
10. `S0-010` — Create permission helpers.
11. `S0-011` — Create route guards.
12. `S0-012` — Create API response and error helpers.
13. `S0-013` — Create validation pattern.
14. `S0-014` — Create audit helper and AuditLog base.
15. `S0-015` — Create base layouts.
16. `S0-016` — Create canonical placeholder pages.
17. `S0-017` — Create Sprint 0 QA checklist.
18. `S0-018` — Create developer README.

**Important supersession:** when executing `S0-003/S0-004`, use ADR-008/ADR-009 from this Bible: set50 tokens and set50 logo rules. Do not use deprecated Sprint 0 starter colors or old lockup prohibition.

After `S0-018`, begin `P1-001` from `Huddle_Implementation_Roadmap_v1.0.csv`; do not jump directly to Marketplace or Messaging.

## 33. Delivery package index

- `Huddle_Developer_Implementation_Bible_v1.0.md` — master implementation instruction.
- `Huddle_ADR_Register_v1.0.csv` — 30 architecture decisions.
- `Huddle_RBAC_Capability_Matrix_v1.0.csv` — capability model and role baselines.
- `Huddle_Domain_Entity_Catalog_v1.0.csv` — data/domain entity inventory.
- `Huddle_API_Contract_Map_v1.0.csv` — API contract baseline.
- `Huddle_Canonical_Route_Map_v1.0.csv` — 105 route rows.
- `Huddle_Screen_Implementation_Registry_v1.0.csv` — 628 unique artifact dispositions.
- `Huddle_Implementation_Roadmap_v1.0.csv` — ordered tasks and gates.
- `README.md` — package usage instructions.

---

**Implementation authority:** where this document explicitly resolves a prior conflict, this Bible v1.0 supersedes the conflicting starter instruction. Where legal/commercial approval is explicitly gated, developers must stop at the adapter/staging boundary and must not infer approval.
